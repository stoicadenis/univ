#include <stdio.h>
#include <stdlib.h>

// numarul maxim de octeti citit la fiecare apel al lui fread
#define SIZE 1024


int main(void)
{
    FILE *fin, *fout;
    // buffer de memorie pentru a citi octeti din fisierul sursa si a-i scrie in fisierul destinatie
    unsigned char buffer[SIZE];
    int rez;

    // deschidere fisier sursa pentru citire binara
    fin=fopen("a.dat", "rb");
    if(!fin)
    {
        perror("\nFisierul nu poate fi deschis!\n");
        exit(EXIT_FAILURE);
    }
    // deschidere fisier destinatie pentru scriere binara
    fout=fopen("b.dat", "wb");
    if(!fout)
    {
        perror("\nEroare deschidere fisier!\n");
        exit(1);
    }
    while((rez=fread(buffer, 1,SIZE, fin))>0)
        fwrite(buffer, 1, rez, fout);
    // inchidere fisiere
    fclose(fin);
    fclose(fout);
}

