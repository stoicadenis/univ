#include <stdio.h>
#include <stdlib.h>

#define SIZE 1000


int main(void)
{
    FILE *f;
    char line[SIZE];

    //deschidere fisier text pentru citire
    f=fopen("a.txt", "rt");
    if(!f)
    {
        perror("\nEroare deschidere fisier!\n");
        exit(1);
    }

    // citire si afisare text
    while(!feof(f))
    {
        fgets(line, SIZE, f);
        printf("%s", line);
    }

    // inchidere fisier
    fclose(f);
}
