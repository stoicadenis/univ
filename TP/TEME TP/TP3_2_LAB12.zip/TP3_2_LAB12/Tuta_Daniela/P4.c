#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *f;
    unsigned char c;
    int rez;
    // deschidere fisier pentru citire binara
    f=fopen("fbin.dat", "rb");
    if(!f)
    {
        printf("Eroare deschidere fisier!");
        exit(1);
    }

    // cat timp se poate citi 1 octet din fisier
    while((rez=fread(&c, sizeof(c), 1, f))==1)
        // afisare in baza 16 a octetului citit
        printf("%2X", c);
    printf("\n");
    // inchidere fisier
    fclose(f);
}
