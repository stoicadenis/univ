#include <stdio.h>
#include <stdlib.h>

// numarul maxim de octeti transferati deodata
#define MAX 500


int main(void)
{
    char nume_sursa[80], nume_destinatie[80];
    FILE *fs, *fd;
    char buf[MAX];
    int nr;

    printf("Intorduceti numele fisierului care se copiaza: ");
    fgets(nume_sursa, 80, stdin);
    printf("Introduceti numele fisierului in care se copiaza: ");
    fgets(nume_destinatie, 80, stdin);
    if((fs=fopen(nume_sursa, "rb"))==NULL)
    {
        printf("\nEroare la deschiderea fisierului %s!\n", nume_sursa);
        exit(1);
    }
    if((fd=fopen(nume_destinatie, "wb"))==NULL)
    {
        printf("\nEroare deschidere fisier %s!\n", nume_destinatie);
        exit(1);
    }

    while(!feof(fs))
    {
        nr=fread(buf, 1, MAX,fs);
        fwrite(buf, 1, nr, fd);
    }
    fclose(fs);
    fclose(fd);
}
