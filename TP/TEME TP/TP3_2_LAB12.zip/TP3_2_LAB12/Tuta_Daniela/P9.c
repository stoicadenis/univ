#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *f;
    unsigned char c;
    long int len;

    // deschidere fisier pentru citire binara
    f=fopen("a.dat", "rb");
    if(!f)
    {
        perror("\nFisierul nu poate fi deschis!\n");
        exit(EXIT_FAILURE);
    }
    printf("Pozitii pare:");
    // cat timp nu ajungem la sfarsitul fisierului (se poate citi 1 octet)
    while(1==fread(&c, 1, 1, f)) {
        // scriere octetul citit pe ecran
        printf("%02x", c);
        // se sare un octet pentru a ajunge la urmatoarea pozitie para
        fseek(f, 1, SEEK_CUR);
    }
    printf("\n");

    // sarim la ultimul octet din fisier (cu o pozitie inainte de sfarsitul fisierului)
    fseek(f, -1, SEEK_END);

    // verificare pozitie curenta si sarim 1 octet darca e pozitie para
    len=ftell(f);
    if(len%2==0)
        fseek(f, -1, SEEK_CUR);
    printf("Pozitii impare:");
    // bucla infinita
    while(1)
    {
        // pastrare pozitie curenta
        len=ftell(f);
        // citire un octet si afisare pe ecran
        fread(&c, 1, 1, f);
        printf("%02x", c);
        // daca pozitia curenta e 1, se reia de la inceputul fisierului, deci ne oprim
        if(len==1)
            break;

        // se sar 3 octeti pentru a ajunge la pozitia impara precedenta
        fseek(f, -3, SEEK_CUR);
    }
    printf("\n");

    // inchidere fisier
    fclose(f);
}
