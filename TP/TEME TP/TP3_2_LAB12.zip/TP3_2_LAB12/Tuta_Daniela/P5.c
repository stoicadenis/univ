#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *f;
    unsigned int k;
    int rez;
    // deschidere fisier pentru citire binara
    f=fopen("fbin.dat", "rb");
    if(!f){
        perror("\nEroare la deschiderea fisierului!\n");
        return -1;
    }

    // cat timp se citeste o inregistrare de 4 octeti (unsigned int) din fisier
    while((rez=fread(&k, sizeof(k), 1, f))==1)
        // afisare in hexazecimal a valorii intregi citite
        printf("%8X", k);
    printf("\n");
    // inchidere fisier
    fclose(f);
}
