#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(void)
{
    FILE *ft; // fisier text
    FILE *fb; // fisier binar
    int k=200011; // initializat cu o valoare oarecare
    char s[]="doua milioane unsprezece"; // sir de caractere initializat cu o valoare oarecare

    // deschidere fisier text pentru scriere
    ft=fopen("out.txt", "wt");
    if(!ft)
    {
        perror("\nEroare deschidere fisier text!\n");
        exit(1);
    }

    // deschidere fisier binar penru scriere
    fb=fopen("out.dat", "wb");
    if(!fb)
    {
        perror("\nEroare deschidere fisier binar!\n");
        exit(1);
    }

    // scriere numar si sir de caracter in fisier text
    fprintf(ft, "%d%s", k, s);
    // scriere numar in fisier binar
    fwrite(&k, sizeof(k), 1, fb);
    // scriere sir de caractere in fisierul binar
    fwrite(s, 1, strlen(s), fb);

    // inchidere fisiere
    fclose(ft);
    fclose(fb);
}
