#include <stdio.h>
#include <stdlib.h>


int main(void)
{
    FILE *f;
    int i;
    unsigned char c;
    // deschidere fisier pentru citire binara
    f=fopen("f02.dat", "wb");
    if(!f) {
        perror("\nEroare deschidere fisier!\n");
        exit(EXIT_FAILURE);
    }
    // parcurgere valori 0x00 -> 0x10 (0 - 16)
    for(i=0; i<17; i++)
    {
        // pastrare valoare curenta
        c=i;
        // scrierea unui octet din variabila de tip unsigned char
        fwrite(&c, 1, 1, f);
        fwrite(&c, 1, 1, f);
    }
    // inchidere fisier
    fclose(f);
}
