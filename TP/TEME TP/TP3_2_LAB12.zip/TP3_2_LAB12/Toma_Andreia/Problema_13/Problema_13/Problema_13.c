#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main()
{
	FILE *fout;


	fout = fopen("fout.dat", "rb");
	if (!fout) {
		perror("Eroare la deschiderea fisierului binar");
		exit(EXIT_FAILURE);
	}


	char s[257];
	unsigned char len, ch;
	int i;
	float pret;

	while (1 == fread(&len, 1, 1, fout)) {

		for (i = 0; i < len; i++)
		{
			fread(&ch, 1, 1, fout);
			s[i] = ch;
		}
		s[len] = '\0';

		fread(&pret, 1, 4, fout);

		printf("%s  %f\n", s, pret);
	}



	fclose(fout);
	return 0;
}