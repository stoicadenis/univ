#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char afisare(char p)
{
    if (p == 0)
        return ' ';
    else if (p == 255)
        return '#';
    else if (p <= 127)
        return '.';
    else
        return 'o';
}
int main()
{
    FILE *f;
    int i, j;
    char n,m,p;
    f = fopen("fbin.dat","rb");
    if (!f)
    {
        perror("Nu se poate deschide fisierul!");
        exit(EXIT_FAILURE);
    }
    fread(&n, sizeof(n), 1, f);
    fread(&m, sizeof(m), 1, f);
    for (i = 0; i < m; i++)
        {
            for (j = 0; j < n; j++)
        {
            fread(&p, 1, 1, f);
            printf("%c", afisare(p));
        }
        printf("\n");
    }
    fclose(f);
    return 0;
}

