#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char nume[255], buf[255];
    float pret;
    unsigned char len;
    FILE *fbin;
    fbin = fopen("produse.dat", "wt");
    if (!fbin)
    {
        printf("Nu se poate deschide fisierul!");
        exit(EXIT_FAILURE);
    }
    do {
        printf("Nume:");
        fgets(nume, 255, stdin);
        nume[strlen(nume) - 1] = '\0';
        if (strlen(nume))
        {
            printf("Pret:");
            fgets(buf,255, stdin);
            sscanf(buf, "%f", &pret);
            len = strlen(nume);
            fwrite(&len, 1, 1, fbin);
            fwrite(nume, strlen(nume), 1, fbin);
            fwrite(&pret, sizeof(pret), 1, fbin);
        }
    } while (strlen(nume));
    fclose(f);
    return 0;
}
