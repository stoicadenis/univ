#include <stdio.h>
#include <stdlib.h>

/*int main() {
	FILE* f;
	unsigned char c;
	unsigned short w, h;
	unsigned int count = 0;
	if ((f = fopen("myfile.dat", "rb")) == NULL) {
		perror("Eroare la deschiderea fisierului binar");
		exit(EXIT_FAILURE);
	}
	fread(&w, sizeof(unsigned short), 1, f);
	fread(&h, sizeof(unsigned short), 1, f);
	while (!feof(f)) {
		fread(&c, sizeof(char), 1, f);
		if (count < w) {
			if (c == 0)
				printf(" ");
			else if (c == 255)
				printf("#");
			else if (c <= 127) {
				printf(".");
			}
			else {
				printf("o");
			}
			count++;
		}
		else {
			printf("\n");
			count = 0;
		}
	}
	fclose(f);

	return 0;
}*/