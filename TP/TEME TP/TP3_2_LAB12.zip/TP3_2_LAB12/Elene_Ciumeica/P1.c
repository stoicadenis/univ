#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*int main() {
	char buf[500];
	const char s[4] = " \t\n";
	char* token;
	FILE* f;
	if ((f = fopen("p1.txt", "rt")) == NULL) {
		printf("Nu pot deschide fisierul \n");
		return -1;
	}
	while (!feof(f)) {
		fgets(buf, 500, f);
		printf("%s\n", buf);
		token = strtok(buf, s);
		while (token != NULL) {
			printf("%s\n", token);

			token = strtok(NULL, s);
		}
	}
	fclose(f);

	return 0;
}*/