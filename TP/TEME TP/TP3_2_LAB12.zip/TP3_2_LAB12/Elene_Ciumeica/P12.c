#include <stdio.h>
#include <stdlib.h>
#include<string.h>

/*int main()
{
	FILE* fbin;
	char nume_prod[255];
	unsigned char l;
	float pret;
	if ((fbin = fopen("p12out.dat", "wb")) == NULL) {
		perror("Eroare la deschiderea fisierului binar");
		exit(EXIT_FAILURE);
	}
	while (l = fgets(nume_prod, 255, stdin))
	{
		l = strlen(nume_prod);
		if (nume_prod[l - 1] == '\n')
			nume_prod[l - 1] = '\0';
		if (strcmp(nume_prod, "") == 0) {
			break;
		}
		scanf("%f", &pret);
		fwrite(&l, sizeof(char), 1, fbin);
		fwrite(nume_prod, sizeof(char), l, fbin);
		fwrite(&pret, sizeof(float), 1, fbin);
		getchar();
	}	
	fclose(fbin);

	fbin = fopen("p12out.dat", "rb");
	unsigned char k;
	int rez;
	while ((rez = fread(&k, sizeof(k), 1, fbin)) == 1) {
		printf("%08X ", k);
	}
	fclose(fbin);

	return 0;
}*/