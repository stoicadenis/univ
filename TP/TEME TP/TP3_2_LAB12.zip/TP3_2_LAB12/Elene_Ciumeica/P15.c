#include <stdio.h>
#include <stdlib.h>
#include<string.h>

void adaugare_file(FILE * fd, FILE * fs, FILE * fx, char nume_sursa[], char nume_dest[]) {
	unsigned char c, dim;
	int i, exista = 0;
	unsigned short size;
	char nume_file[80];
	if (fread(&c, sizeof(char), 1, fd)) {
		for (i = 0; i < c; i++) {
			fread(&dim, sizeof(char), 1, fd);
			fread(nume_file, sizeof(char), dim, fd);
			fwrite(&dim, sizeof(char), 1, fx);
			fwrite(nume_file, sizeof(char), dim, fx);
			if (strcmp(nume_file, nume_sursa) == 0) {
				printf("Fisierul %s e deja arhivat\n", nume_sursa);
				remove("tempfile.dat");
				return;
			}
		}
		dim = strlen(nume_sursa);
		fwrite(&dim, sizeof(char), 1, fx);
		fwrite(nume_sursa, sizeof(char), dim, fx);
	}
	while (!feof(fd)) {
		if (fread(&size, sizeof(unsigned short), 1, fd)) {
			fwrite(&size, sizeof(unsigned short), 1, fx);
			for (i = 0; i < size; i++) {
				fread(&c, sizeof(char), 1, fd);
				fwrite(&c, sizeof(char), 1, fx);
			}
		}
	}
	fread(&size, sizeof(unsigned short), 1, fs);
	fwrite(&size, sizeof(unsigned short), 1, fx);
	for (i = 0; i < size; i++) {
		fread(&c, sizeof(char), 1, fs);
		fwrite(&c, sizeof(char), 1, fx);
	}
	rename("tempfile.dat", nume_dest);
	remove("tempfile.dat");
}

void stergere_file(FILE* fd, FILE* fx, char nume_sursa[], char nume_dest[]) {
	unsigned char c, dim;
	int i, counter = -1;
	unsigned short size;
	char nume_file[80];
	if (fread(&c, sizeof(char), 1, fd)) {
		for (i = 0; i < c; i++) {
			fread(&dim, sizeof(char), 1, fd);
			fread(nume_file, sizeof(char), dim, fd);
			if (strcmp(nume_file, nume_sursa) == 0) {
				counter = i;
				continue;
			}
			fwrite(&dim, sizeof(char), 1, fx);
			fwrite(nume_file, sizeof(char), dim, fx);
		}
	}
	while (!feof(fd)) {
		for (i = 0; i < c; i++) {
			if (fread(&size, sizeof(unsigned short), 1, fd)) {
				if (i != counter)
					fwrite(&size, sizeof(unsigned short), 1, fx);
				for (i = 0; i < size; i++) {
					fread(&c, sizeof(char), 1, fd);
					if (i != counter)
						fwrite(&c, sizeof(char), 1, fx);
				}
			}
		}
	}
	rename("tempfile.dat", nume_dest);
	remove("tempfile.dat");
}

void extragere_file(FILE* fa, FILE* fx, char nume_sursa[], char nume_dest[]) {
	unsigned char c, dim;
	int i, counter = -1;
	unsigned short size;
	char nume_file[80];
	if (fread(&c, sizeof(char), 1, fa)) {
		for (i = 0; i < c; i++) {
			fread(&dim, sizeof(char), 1, fa);
			fread(nume_file, sizeof(char), dim, fa);
			if (strcmp(nume_file, nume_sursa) == 0) {
				counter = i;
				break;
			}
		}
	}
	while (!feof(fa)) {
		for (i = 0; i < c; i++) {
			if (fread(&size, sizeof(unsigned short), 1, fa)) {
				if (i == counter)
					fwrite(&size, sizeof(unsigned short), 1, fx);
				for (i = 0; i < size; i++) {
					fread(&c, sizeof(char), 1, fa);
					if (i == counter)
						fwrite(&c, sizeof(char), 1, fx);
				}
			}
		}
	}
	rename("tempfile.dat", nume_dest);
	remove("tempfile.dat");
}

void listare_arhiva(FILE* fd) {
	unsigned char c, dim;
	int i, counter = 0;
	unsigned short size;
	char nume_file[80];
	if (fread(&c, sizeof(char), 1, fd)) {
		for (i = 0; i < c; i++) {
			fread(&dim, sizeof(char), 1, fd);
			fread(nume_file, sizeof(char), dim, fd);
			printf("%d. %s\n", i, nume_file);
		}
	}
}

int main() {
	char nume_sursa[80], nume_dest[80];
	FILE* fs, * fd, * fx;

	printf("Introduceti numele fisierului care se arhiveaza \n");
	fgets(nume_sursa, 80, stdin);
	printf("Introduceti numele fisierului ahriva \n");
	fgets(nume_dest, 80, stdin);

	if ((fs = fopen(nume_sursa, "rb")) == NULL) {
		printf("Nu pot deschide fisierul %s \n", nume_sursa);
		return -1;
	}
	if ((fd = fopen(nume_dest, "wb")) == NULL) {
		printf("Nu pot deschide fisierul %s \n", nume_dest);
		exit(1);
	}
	if ((fx = fopen("tempfile.dat", "wb")) == NULL) {
		printf("Nu pot deschide fisierul nou \n");
		exit(1);
	}

	//listare_arhiva(fd);

	adaugare_file(fd, fs, fx, nume_sursa, nume_dest);

	//stergere_file(fd, fx, nume_sursa, nume_dest);

	//extragere_file(fd, fx, nume_sursa, nume_dest);
	
	fclose(fs);
	fclose(fd);
	fclose(fx);

	return 0;
}