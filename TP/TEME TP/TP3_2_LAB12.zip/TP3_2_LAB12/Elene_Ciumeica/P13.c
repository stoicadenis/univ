#include <stdio.h>
#include <stdlib.h>

/*int main()
{
	FILE* fbin;
	char nume_prod[255];
	unsigned char c;
	float pret;
	if ((fbin = fopen("p12out.dat", "rb")) == NULL) {
		perror("Eroare la deschiderea fisierului binar");
		exit(EXIT_FAILURE);
	}
	while (!feof(fbin))
	{
		if (fread(&c, sizeof(char), 1, fbin)) {
			//fread(&c, sizeof(char), 1, fbin);
			fread(nume_prod, sizeof(char), c, fbin);
			fread(&pret, sizeof(float), 1, fbin);
			printf("%d %s %.2f\n", c, nume_prod, pret);
		}
	}
	fclose(fbin);

	return 0;
}*/