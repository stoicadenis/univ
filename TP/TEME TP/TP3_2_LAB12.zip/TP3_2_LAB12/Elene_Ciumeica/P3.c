#include <stdio.h>
#include <stdlib.h>
/*#define MAX 500

int main() {
	char nume_sursa[80], nume_dest[80];
	FILE* fs, * fd;
	char buf[MAX];
	int nr;
	printf("Introduceti numele fisierului care se copiaza \n");
	fgets(nume_sursa, MAX, stdin);
	printf("Introduceti numele fisierului copie \n");
	fgets(nume_dest, MAX, stdin);  // gets() nu se recomanda, crash daca e mai mare de MAX
	if ((fs = fopen(nume_sursa, "rb")) == NULL) {
		printf("Nu pot deschide fisierul %s \n", nume_sursa);
		return -1;
	}
	if ((fd = fopen(nume_dest, "wb")) == NULL) {
		printf("Nu pot deschide fisierul %s \n", nume_dest);
		exit(1);
	}
	while (!feof(fs)) {
		nr = fread(buf, sizeof(char), MAX, fs);  // conteaza produsul 1*MAX <=>fread(buf, MAX, 1, fs)
		fwrite(buf, 1, nr, fd); // 1 - octet, MAX - nr de elem
	}
	fclose(fs);
	fclose(fd);
	return 0;
}*/