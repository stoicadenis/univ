#include<stdio.h>
#include<stdlib.h>

/*int main() {
	FILE* f;
	int nr, n1 = 0, n2 = 0, n3 = 0, n4 = 0;
	if ((f = fopen("p2.txt", "rt")) == NULL) {
		printf("Nu pot deschide fisierul \n");
		return -1;
	}
	while (!feof(f)) {
		fscanf(f, "%*s %*s %d", &nr);
		if (nr == 9 || nr == 10) {
			n1++;
		}
		else if (nr < 9 && nr >5) {
			n2++;
		}
		else if (nr == 5) {
			n3++;
		}
		else {
			n4++;
		}
	}
	printf("9 si 10: %d\n6-8: %d\n5: %d\n<5:%d\n", n1, n2, n3, n4);
	fclose(f);

	return 0;
}*/