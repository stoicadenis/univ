#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f;
    unsigned char c;
    int rez;
    /* Deschidem fisierul pentru citire binara. */
    f = fopen("fbin.txt", "rb");
    if (!f)
    {
        perror("\nEroare la deschiderea fisierului!\n");
        exit(EXIT_FAILURE);
    }
    /* Cat timp reusim sa citim o inregistrare de 1 octet din fisier... */
    while ((rez = fread(&c, sizeof(c), 1, f)) == 1)
    {
        /* ... afisam in hexazecimal octetul citit.  Specificatorul de format %02X se traduce prin:  afisare in hexazecimal, cu litere mari pentru cifrele hexa A-F, pe o latime de doua caractere, completat cu 0 la stanga daca e cazul. */
        printf("%02X ", c);
    }
    printf("\n");
    /* Inchidem fisierul. */
    fclose(f);

    system("pause");
    return 0;
}
