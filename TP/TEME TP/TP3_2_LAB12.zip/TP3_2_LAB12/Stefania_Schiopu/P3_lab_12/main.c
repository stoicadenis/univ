#include <stdio.h>
#include <stdlib.h>

#define MAX 500

int main()
{
    //char nume_sursa[80], nume_dest[80];
    FILE *fs,*fd;
    char buf[MAX];
    int nr;
    /*printf("Introduceti numele fisierului care se copiaza:\n");
    fgets(nume_sursa,80,stdin);
    printf("Introduceti numele fisierului copie:\n");
    fgets(nume_dest,80,stdin);*/

    if ((fs=fopen("sursa.txt", "rb"))==NULL)
    {
        printf("Eroare la deschidere fisier!\n");
        return -1;
    }
    if ((fd=fopen("destinatie.txt", "wb"))==NULL)
    {
        printf("Eroare la deschidere fisier!\n");
        exit(1);
    }
    while (!feof(fs))
    {
        nr=fread(buf, 1, MAX, fs);
        fwrite(buf, 1, nr, fd);
    }
    fclose(fs);
    fclose(fd);

    system("pause");
    return 0;
}

