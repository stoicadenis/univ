#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void)
{ /* Doua variabile: una pentru fisier text si una pentru   fisier binar. */
    FILE *ftxt, *fbin;
    /* O variabila de tip int, initializata cu o valoare  oarecare. */
    int k = 2000011;
    /* Un sir de caractere initializat cu o valoare  oarecare. */
    char s[] = "doua milioane unsprezece";
    /* Deschidem un fisier text pentru scriere. */
    ftxt = fopen("out_wt.txt", "wt");
    if (!ftxt) {
        perror("\nEroare la deschiderea fisierului text!\n");
        exit(EXIT_FAILURE);
    }
    /* Deschidem si un fisier binar pentru scriere. */
    fbin = fopen("out_wb.txt", "wb");
    if (!fbin)
    {
        perror("\nEroare la deschiderea fisierului binar!\n");
        exit(EXIT_FAILURE);
    }
    /* Scriem numarul si sirul de caractere in fisierul  text. Folosim scriere formatata cu fprintf. */
    fprintf(ftxt, "%d%s", k, s);
    /* Scriem numarul in fisierul binar. Folosim fwrite cu   1 inregistrare de dimensiune sizeof(k). */
    fwrite(&k, sizeof(k), 1, fbin);
    /* Scriem sirul de caractere in fisierul binar. Folosim fwrite cu strlen(s) inregistrari de dimensiune 1.      Atentie la faptul ca s e deja pointer. */
    fwrite(s, 1, strlen(s), fbin);
    /* Inchidem fisierele. */
    fclose(ftxt);
    fclose(fbin);

    system("pause");
    return 0;
}
