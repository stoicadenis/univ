#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f;
    unsigned int k;
    int rez; /* Deschidem fisierul pentru citire binara. */
    f = fopen("fbin.txt", "rb");
    if (!f)
    {
        perror("\nEroare la deschiderea fisierului!\n");
        exit(EXIT_FAILURE);
    }  /* Cat timp reusim sa citim o inregistrare de 4 octeti (adica un unsigned int) din fisier... */
    while ((rez = fread(&k, sizeof(k), 1, f)) == 1)
    {
        /* ... afisam in hexazecimal valoarea intreaga  citita. */
        printf("%08X ", k);
    }
    printf("\n");
    /* Inchidem fisierul. */
    fclose(f);

    system("pause");
    return 0;
}
