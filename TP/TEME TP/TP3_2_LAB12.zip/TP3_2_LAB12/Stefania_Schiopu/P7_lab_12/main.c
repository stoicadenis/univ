#include <stdio.h>
#include <stdlib.h>

/* Numarul de octeti cititi la fiecare apel al lui fread. */

#define SIZE 1024

int main(void)
{
    /* Doua fisiere, unul va fi sursa si unul va fi  destinatia. */
    FILE *fin, *fout;
    /* Buffer de memorie folosit pentru a citi octeti din  fisierul sursa si a-i scrie in fisierul destinatie. */
    unsigned char buffer[SIZE];
    int rez;/* Deschidem fisierul sursa pentru citire binara. */
    fin = fopen("a.txt", "rb");
    if (!fin)
    {
        perror("\nNu pot deschide fisierul sursa!\n");
        exit(EXIT_FAILURE);
    } /* Deschidem fisierul destinatie pentru scriere binara.  */
    fout = fopen("b.txt", "wb");
    if (!fout)
    {
        perror("\nNu pot deschide fisierul destinatie!\n");
        exit(EXIT_FAILURE);
    } /* Copierea se face atat timp cat pot citi cel putin un octet din fisierul sursa. Este important sa citim blocuri de dimensiune 1, pentru a sti exact numarul de octeti cititi. Functia fread returneaza numarul de inregistrari citite. Daca inregistrarea are 1  octet, acest numar va fi chiar numarul de octeti cititi. */
    while ((rez = fread(buffer, 1, SIZE, fin)) > 0)
    {
        /* Scriu in fisierul destinatie octetii cititi. La ultima citire din fisierul sursa este posibil sa   citim mai putin de SIZE octeti, de aceea folosim   variabila rez. */
        fwrite(buffer, 1, rez, fout);
    }

    /* Inchidem cele doua fisiere. */

    fclose(fin);
    fclose(fout);

    system("pause");
    return 0;
    }
