#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f;
    int i;
    unsigned char c;
    /* Deschidem fisierul pentru scriere binara. */
    f = fopen("f02.txt", "wb");
    if (!f) {
        perror("\nEroare la deschiderea fisierului!\n");
        exit(EXIT_FAILURE);
    }
    /* Parcurgem valorile de la 0x00 pana la 0x10 (adica de la 0 la 16). */
    for (i = 0; i < 17; i++)
    {
        /* Pastram valoarea curenta intr-o variabila de tip unsigned char. */
        c = i;
        /* Scriem o inregistrare de un octet din variabila de tip unsigned char in fisier. */
        fwrite(&c, 1, 1, f);
        /* Mai Scriem o data acelasi lucru. */
        fwrite(&c, 1, 1, f);
    }
    /* Inchidem fisierul. */
    fclose(f);

    system("pause");
    return 0;
}
