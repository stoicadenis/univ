#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE *f;
    unsigned char c;
    long int len;
    /* Deschid fisierul pentru citire binara. */
    f = fopen("a.txt", "rb");
    if (!f) {
        perror("\nEroare deschidere fisier!\n");
        exit(EXIT_FAILURE);
    }
    printf("Pozitii pare: ");
    /* Cat timp putem citi 1 octet din fisier (adica nu am ajuns la sfarsitul fisierului) ... */
    while (1 == fread(&c, 1, 1, f))
    {
        /* ... scriem octetul citit pe ecran. */
        printf("%02x ", c);
        /* Si sarim peste 1 octet, pentru a ajunge la urmatoarea pozitie para. E nevoie doar de 1 sinu de 2 deoarece fread-ul de mai sus ne-a deplasat deja cu o pozitie spre dreapta. */
        fseek(f, 1, SEEK_CUR);
    }
    printf("\n");
    /* Sarim la ultimul octet din fisier (cu o pozitie  inainte de sfarsitul fisierului). */
    fseek(f, -1, SEEK_END);
    /* Verificam la ce pozitie suntem, si daca e pozitie para, sarim 1 octet inapoi pentru a ajunge la pozitie impara. */
    len = ftell(f);
    if (len % 2 == 0)
        fseek(f, -1, SEEK_CUR);
    printf("Pozitii impare: ");
    /* Bucla infinita. Iesirea se face cu o conditie mai  jos. */
    while (1)
    {
        /* Pastram pozitia curenta intr-o variabila. */
        len = ftell(f);
        /* Citim un octet si il afisam pe ecran. */
        fread(&c, 1, 1, f);
        printf("%02x ", c);
        /* Daca pozitia curenta era 1, ne oprim (am ajuns inapoi la inceputul fisierului. */
        if (len == 1)
            break;
        /* Sarim inapoi 3 octeti, pentru a ajunge la pozitia impara precedenta. E nevoie de 3 si nu
           de 2 deoarece fread-ul facut ne-a deplasat cu 1 pozitie spre dreapta. */
        fseek(f, -3, SEEK_CUR);
    }
    printf("\n");
    /* Inchidem fisierul. */

    fclose(f);

    system("pause");
    return 0;
    }
