#include <stdio.h>
#include <stdlib.h>
#define MAX 500
int main() {
char nume_sursa[80], nume_dest [80];
FILE *fs,*fd;
char buf[MAX];
int nr;
printf("Introduceti numele fisierului care se copiaza \n");
gets(nume_sursa);
printf("Introduceti numele fisierului copie \n");
gets(nume_dest);
if ((fs=fopen(nume_sursa, "rb"))==NULL) {
printf("Nu pot deschide fisierul %s \n", nume_sursa);
return -1;
}
if ((fd=fopen(nume_dest, "wb"))==NULL) {
printf("Nu pot deschide fisierul %s \n", nume_dest);
exit(1);
}
while (!feof(fs)) {
nr=fread(buf, 1, MAX, fs);
fwrite(buf, 1, nr, fd);
}
fclose(fs);
 fclose(fd);
return 0;
 }

