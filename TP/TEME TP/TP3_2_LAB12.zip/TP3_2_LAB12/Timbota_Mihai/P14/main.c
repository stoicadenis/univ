#include <stdio.h>
#include <stdlib.h>

int main()
{
      FILE *f;
      unsigned short w,h;
      unsigned char c;
      int **a,i,j;

    f = fopen("f.dat", "rb");
    if (!f) {
        perror("Eroare la deschiderea fisierului binar");
        exit(EXIT_FAILURE);
    }

    fread(&w, 1, 2, f);
    fread(&h, 1, 2, f);

    a = malloc(h * sizeof(int *));   // Alocare pentru vector de pointeri

  for (i = 0; i < h; i++) {
    a[i] = calloc(w, sizeof(int)); // Alocare pentru o linie si initializare la zero
  }


 for(i=0;i<h;i++)
    for(j=0;j<w;j++)
 {
     fread(&c,1,1,f);
     if(c==0)
        a[i][j]=' ';
     else if(c<=127)
        a[i][j]='.';
        else if(c<=254)
            a[i][j]='o';
        else if(c==255)
            a[i][j]='#';

 }

 for(i=0;i<h;i++)
    {for(j=0;j<w;j++)
    printf("%c",a[i][j]);
    printf("\n");
    }




  for (i = 0; i < h; i++)
     free(a[i]);
  free(a);


    fclose(f);

    return 0;
}
