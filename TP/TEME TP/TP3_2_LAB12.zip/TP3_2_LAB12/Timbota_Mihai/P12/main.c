#include <stdio.h>
#include <stdlib.h>



int main()
{
    FILE *fout;


    fout = fopen("fout.dat", "wb");
    if (!fout) {
        perror("Eroare la deschiderea fisierului binar");
        exit(EXIT_FAILURE);
    }



    char s[257];
    unsigned char len;
    int i;
    float pret;

    while(1)
    {
        printf("nume produs:\n");

        fgets(s,255,stdin);
        if(strcmp(s,"\n")==0)
        {
            printf("datele au fost scrise in fisier");
            getch();
            exit(0);
        }
        s[strlen(s)-1]='\0';
        len=strlen(s);

        printf("pret:\n");


        scanf("%f", &pret);
        getchar();

        fwrite(&len,1,1, fout);
        for(i=0;i<len;i++)
            fwrite(&s[i],1,1, fout);
        fwrite(&pret,1,4,fout);
    }

    fclose(fout);


    return 0;
}
