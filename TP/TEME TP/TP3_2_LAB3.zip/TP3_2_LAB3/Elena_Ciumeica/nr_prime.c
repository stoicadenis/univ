#include<stdio.h>
#include<stdlib.h>

//construirea unui vector cu numerele prime (aici si recursiva de nr prim)
/*int isPrime(int n, int d) {
	if (n < 2) {
		return 0;
	}
	if (n % 2 == 0 && n != 2) {
		return 0;
	}
	if (n % d == 0 && n != d) {
		return 0;
	}
	if (d * d > n) {
		return 1;
	}
	isPrime(n, d + 2);
}

void construire(int* a, int n, int i, int val)
{
	int again = 1;
	if (i == n)
		return;
	while (again) {
		if (isPrime(val, 3)) {
			a[i] = val;
			again = 0;
		}
		else {
			val++;
		}
	}
	construire(a, n, i + 1, val + 1);
}

void afisare(int* v, int n) {
	if (n > 0) {
		printf("%d\n", v[0]);
		afisare(v + 1, n - 1);
	}
}

int main() {
	int* v, n;
	scanf("%d", &n);
	v = malloc(n * sizeof(n));
	construire(v, n, 0, 1);
	afisare(v, n);

	return 0;
}*/