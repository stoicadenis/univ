#include<stdio.h>
#include<stdlib.h>

/*void afisare(int* v, int n) {
	int* x = v;
	while ((x - v) < n) {
		printf("%5d", v[x - v]);
		x++;
	}
	printf("\n");
}

void inscriere(int* v, int*v2, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		v2[2 * (x - v)] = (-1) * v[x - v];
		v2[2 * (x - v) + 1] = v[x - v];
		x++;
	}
}

int main() {
	int v[] = { 7,-5,4,3,2,-9,-8 };
	int* v2, n = 7;
	v2 = malloc(n * 2 * sizeof(int));
	afisare(v, n);
	inscriere(v, v2, &n);
	afisare(v2, n * 2);

	return 0;
}*/