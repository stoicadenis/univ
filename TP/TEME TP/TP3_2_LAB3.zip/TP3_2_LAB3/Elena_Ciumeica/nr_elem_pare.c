#include<stdio.h>
#include<stdlib.h>

/*int nrEven(int* v, int n)
{
	if (n == 0)
		return 0;

	return (v[0] % 2 == 0) + nrEven(v + 1, n - 1);
}

int main() {
	int* v[] = { 8, 4, 3, 2, 5 };
	printf("%d\n", nrEven(v, 5));

	return 0;
}*/