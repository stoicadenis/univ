#include<stdio.h>
#include<stdlib.h>
#define getName(var)  #var

/*int main() {
	double a, b, *c;
	scanf("%lf", &a);
	scanf("%lf", &b);
	if (&a < &b) {
		c = &a;
	}
	else {
		c = &b;
	}
	printf("%s %g %p", getName(c), *c, c);

	return 0;
}*/