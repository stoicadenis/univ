#include<stdio.h>
#include<stdlib.h>

/*void citire(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		scanf("%d", &v[x - v]);
		x++;
	}
}

void afisare(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		printf("%5d", v[x - v]);
		x++;
	}
	printf("\n");
}

void stergeDuplicat(int* v, int* n) {
	int* x = &v[1], * c = v;
	while ((x - v) < *n) {
		if (v[x - v] == v[x - v - 1]) {
			c = &v[x - v];
			while ((c - v) < (*n - 1)) {
				v[c - v] = v[c - v + 1];
				c++;
			}
			x--;
			(*n)--;
		}
		x++;
	}
}

void afisareDuplicat(int* v, int* n) {
	int* x = v, * c = v, counter = 0, * m;
	m = malloc((*n) * sizeof(int));
	while ((x - v) < (*n) - 1) {
		c = &v[x - v + 1];
		while ((c - v) < *n) {
			if (v[x - v] == v[c - v]) {
				m[counter] = v[x - v];
				counter++;
				break;
			}
			c++;
		}
		x++;
	}
	stergeDuplicat(m, &counter);
	afisare(m, &counter);
	free(m);
}

int main() {
	int* v, n;
	printf("Citire n: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int));
	printf("Citire tabel:\n");
	citire(v, &n);
	afisare(v, &n);
	afisareDuplicat(v, &n);

	return 0;
}*/