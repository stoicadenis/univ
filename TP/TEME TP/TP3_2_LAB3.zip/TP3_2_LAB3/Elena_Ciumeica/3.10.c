#include<stdio.h>
#include<stdlib.h>
#define MAX 100

/*void add(float* v, int* n) {
	scanf("%f", &v[*n]);
	(*n)++;
}

void afisare(float* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		printf("%5.2f", v[x - v]);
		x++;
	}
	printf("\n");
}

void sterge(float* v, int* n) {
	float* x = v, * c = v, val;
	printf("Citire duplicat: ");
	scanf("%f", &val);
	while ((x - v) < *n) {
		if (v[x - v] == val) {
			c = &v[x - v];
			while ((c - v) < (*n - 1)) {
				v[c - v] = v[c - v + 1];
				c++;
			}
			x--;
			(*n)--;
		}
		x++;
	}
}

int main() {
	float v[MAX];
	int n = 0, opt;
	while (1) {
		printf("\n1.Adaugare\n2.Afisare\n3.Stergere\n4.Iesire\nAlege optiune: ");
		scanf("%d", &opt);
		switch (opt)
		{
		case 1:
			add(v, &n);
			break;
		case 2:
			afisare(v, &n);
			break;
		case 3:
			sterge(v, &n);
			break;
		case 4:
			exit(0);
		default:
			printf("Alege varianta corecta\n");
			break;
		}
	}

	return 0;
}*/