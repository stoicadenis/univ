#include<stdio.h>
#include<stdlib.h>

/*void afisare(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		printf("%5d", v[x - v]);
		x++;
	}
	printf("\n");
}

void stergere(int* v, int* n) {
	int* x = v, * c = v, aux;
	while ((x - v) < *n) {
		if (v[x - v] % 2 == 0) {
			c = &v[x - v];
			while ((c - v) < (*n - 1)) {
				v[c - v] = v[c - v + 1];
				c++;
			}
			x--;
			(*n)--;
		}
		x++;
	}
}

int main() {
	int v[] = { 5,8,1,4,2,6,9 };
	int n = 7;
	afisare(v, &n);
	stergere(v, &n);
	afisare(v, &n);

	return 0;
}*/