#include<stdio.h>
#include<stdlib.h>

/*void citire(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		scanf("%d", &v[x - v]);
		x++;
	}
}

void afisare(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		printf("%5d", v[x - v]);
		x++;
	}
	printf("\n");
}

void sortare(int* v, int* n) {
	int* x, again, aux;
	do {
		again = 0;
		x = &v[1];
		while ((x - v) < *n) {
			if (v[x - v - 1] < v[x - v]) {
				aux = v[x - v - 1];
				v[x - v - 1] = v[x - v];
				v[x - v] = aux;
				again = 1;
			}
			x++;
		}
	} while (again);
}

int main() {
	int n, * v;
	printf("Citire n: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int));
	printf("Citire vector:\n");
	citire(v, &n);
	afisare(v, &n);
	sortare(v, &n);
	afisare(v, &n);

	return 0;
}*/