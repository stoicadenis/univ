#include<stdio.h>
#include<stdlib.h>

/*int main() {
	int v[] = { 7,-5,4,3,2,-9,-8 };
	int* x = &v[1], min = v[0];
	while ((x - v) < 7) {
		if (v[x - v] < min) {
			min = v[x - v];
		}
		x++;
	}
	printf("Min %d", min);

	return 0;
}*/