#include<stdio.h>
#include<stdlib.h>

/*int main() {
	int v[] = { 7,-5,4,3,-9,2,-8 };
	int* i = v, counter = 0;
	while ((i - v) < 7) {
		if (v[i - v] < 0) {
			counter++;
		}
		i++;
	}
	printf("%d", counter);

	return 0;
}*/