#include<stdio.h>
#include<stdlib.h>

/*void afisare(int* v[], int n) {
	if (n > 0) {
		printf("%d\n", v[0]);
		afisare(v + 1, n - 1);
	}
}

int main() {
	int* v[] = { 8, 4, 6, 2, 5 };
	afisare(v, 5);

	return 0;
}*/