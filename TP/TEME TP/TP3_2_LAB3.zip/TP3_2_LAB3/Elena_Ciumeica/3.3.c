#include<stdio.h>
#include<stdlib.h>

/*void interschimbare(int* a, int* b) {
	*a += *b;
	*b = *a - *b;
	*a -= *b;
}

int main() {
	int a, b;
	scanf("%d%d", &a, &b);
	printf("%d %d\n", a, b);
	interschimbare(&a, &b);
	printf("%d %d\n", a, b);

	return 0;
}*/