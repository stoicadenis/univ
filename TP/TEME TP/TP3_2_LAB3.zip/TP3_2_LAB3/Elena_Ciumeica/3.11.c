#include<stdio.h>
#include<stdlib.h>
#define MAX 100

/*void afisare(int* v, int* n) {
	int* x = v;
	while ((x - v) < *n) {
		printf("%5d", v[x - v]);
		x++;
	}
	printf("\n");
}

void sortare(int* v, int* n) {
	int* x, again, aux;
	do {
		again = 0;
		x = &v[1];
		while ((x - v) < *n) {
			if (v[x - v - 1] > v[x - v]) {
				aux = v[x - v - 1];
				v[x - v - 1] = v[x - v];
				v[x - v] = aux;
				again = 1;
			}
			x++;
		}
	} while (again);
}

void citire(int* v, int* n) {
	int nr;
	while (1) {
		scanf("%d", &nr);
		if (nr == 0) break;
		v[*n] = nr;
		(*n)++;
		sortare(v, n);
		afisare(v, n);
	}
}

int main() {
	int v[MAX];
	int n = 0;
	citire(v, &n);

	return 0;
}*/