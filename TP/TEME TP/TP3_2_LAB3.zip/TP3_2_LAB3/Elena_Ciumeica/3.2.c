#include<stdio.h>
#include<stdlib.h>

/*int main() {
	int a, b, * c;
	scanf("%d%d", &a, &b);
	if (a > b) {
		c = &a;
	}
	else {
		c = &b;
	}
	printf("%d", *c);

	return 0;
}*/