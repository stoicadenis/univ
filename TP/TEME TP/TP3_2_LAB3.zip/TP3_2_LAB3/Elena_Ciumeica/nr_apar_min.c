#include<stdio.h>
#include<stdlib.h>

//nr de aparitii a cifrei minime din fiecare element si depunerea acestui nr de aparitii in alt vector
/*int minNr(int n, int min) {
	if (n == 0)
		return min;
	return minNr(n / 10, min < (n % 10) ? min : (n % 10));
}

int nrAparitie(int n, int i) {
	if (n == 0) {
		if (i == 0)
			return 1;
		else
			return 0;
	}
	return (n % 10 == i) + nrAparitie(n / 10, i);
}

void suprapunere(int* v, int* a, int n) {
	if (n > 0) {
		a[0] = nrAparitie(v[0], minNr(v[0], v[0]));
		suprapunere(v + 1, a + 1, n - 1);
	}
}

void citire(int* a, int n, int i)
{
	if (i < n)
	{
		if (scanf("%d", &a[i]) == 1)
		{
			citire(a, n, i + 1);
		}
	}
}

void afisare(int* v, int n) {
	if (n > 0) {
		printf("%d\n", v[0]);
		afisare(v + 1, n - 1);
	}
}

int main() {
	int* v, * a, n;
	scanf("%d", &n);
	v = malloc(n * sizeof(int));
	a = malloc(n * sizeof(int));
	citire(v, n, 0);
	suprapunere(v, a, n);
	afisare(a, n);

	return 0;
}*/