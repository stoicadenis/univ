#include <stdio.h>
#include <stdlib.h>

void citire(int v[], int n)
{
    printf("v[%d]= ", n);
    scanf("%d", &v[n]);
    if(n>1) citire(v,n-1);
}

void afisare(int v[], int n)
{
    printf("v[%d]= %d\n", n, v[n]);
    if(n>1) afisare(v,n-1);
}

int pare(int v[], int n, int cont)
{
    int k=-1;
    if(n<=k) return 0;
    k++;
    if(v[n-k]%2==0)
    {
        cont++;
    }
    if(n>1) pare(v,n-1,cont);
    else return cont;
}

int det(int v,int min, int k)  // min=9, k=1;
{
    if(v==0)
        return k;

    if(v%10<min)
    {
        k=1;
        min=v%10;
    }
    else if(min==v%10)
        k++;

    det(v/10,min,k);

}

void func(int v[],int a[], int n, int i)
{
    if (i <= n)
    {
       a[i]=det(v[i],9,1);
       func(v,a,n,i+1);

    }
}

int main()
{
    int v[20], a[20], n, min, cont=0;
    printf("n= ");
    scanf("%d", &n);
    printf("\nCitire\n");
    citire(v,n);
    printf("\nAfisare\n");
    afisare(v,n);
    printf("\nNr de elemente pare: %d\n", pare(v,n,cont));
    func(v,a,n,0);
    printf("numarul de aparatii a cifrei minime din fiecare element:\n");
    afisare(a,n);
    return 0;
}
