#include <stdio.h>
#include <stdlib.h>

int main()
{
    double x1,x2;
    double *px1=&x1; double *px2=&x2;
    printf("x1="); scanf("%lf",&x1);
    printf("x2="); scanf("%lf",&x2);
    printf("%d\n",px1);
    printf("%d\n",px2);
    if(px1<px2)
        printf("x1");
    else
        printf("x2");
    return 0;
}
