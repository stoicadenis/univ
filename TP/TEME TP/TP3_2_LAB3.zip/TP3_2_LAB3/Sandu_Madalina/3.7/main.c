#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[]= {5, 8, 1, 4, 2, 6, 9},*end,*p,*j;
    end=v;
    while((end-v)!=7)
        end++;
        for (p=v; p<end; p++)
        if(*p%2==0)
           {for(j=p+1;j<end;j++)
             *(j-1)=*j;
              end--;
              p--;
           }
     printf("Vectorul fara elementele pare:\n");
     for (p=v; p<end; p++)
        printf("%d ",*p);
    return 0;
}


