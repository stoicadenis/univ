#include <stdio.h>
#include <stdlib.h>
void citire(int v[], int n)
{
    if(n>0)
   {
        printf("v[%d]=",n);
        scanf("%d",&v[n]);
        citire(v,n-1);
    }
}

void afisare(int v[], int n)
{
    if(n>0)
      {
          printf("%d ",v[n]);
          afisare(v,n-1);
      }
}
int a(int v[], int n)
{
    if(n==0)
        return 0;
    if(v[n]%2==0)
        return a(v,n-1)+1;
    return a(v,n-1);

}
int main()
{
    int v[10],n;
    printf("n="); scanf("%d",&n);
    citire(v,n);
    afisare(v,n);
    printf("\n");
    printf("Sunt %d elemente pare in vector",a(v,n));
    return 0;
}


