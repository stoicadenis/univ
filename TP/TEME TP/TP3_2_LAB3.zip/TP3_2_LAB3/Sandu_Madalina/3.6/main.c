#include <stdio.h>
#include <stdlib.h>
int main()
{
    int v[10],n,*end,*p,*i, *j,aux;
    printf("n="); scanf("%d",&n);
    end=v;
    while((end-v)!=n)
    {
        printf("v[%d]=",end-v);
        scanf("%d",end);
        end++;
    }
    printf("Elementele tabloului:\n");
    for (p=v; p<end; p++)
    printf("%d ",*p);
    for(i=v;i<end-1;i++)
        for(j=i+1;j<end;j++)
        if(*j>*i)
    {
        aux=*j;
        *j=*i;
        *i=aux;
    }
    printf("\n");
    printf("Vectorul ordonat \n");
    for (p=v; p<end; p++)
    printf("%d ",*p);
    return 0;
}

