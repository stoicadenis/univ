#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x1,x2;
    int *px1,*px2;
    printf("x1="); scanf("%d",&x1);
    printf("x2="); scanf("%d",&x2);
    px1=&x1;
    px2=&x2;
    int aux=*px1;
    *px1=*px2;
    *px2=aux;
    printf("Noul x1 este %d\n",*px1);
    printf("Noul x2 este %d",*px2);
    return 0;
}
