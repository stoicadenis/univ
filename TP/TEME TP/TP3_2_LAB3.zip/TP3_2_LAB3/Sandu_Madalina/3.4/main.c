#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[]={7,-5,4,3,-9,2,-9},c=0,i;
    int *p;
    p=v;
    while((p-v)!=7)
    {
        if(*p<0)
            c++;
        p++;
    }
    printf("Avem %d numere negative",c);
    return 0;
}

