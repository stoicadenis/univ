#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[]={7,-5,4,3,-9,2,-8},c=0,i;
    int *p;
    p=v;
    int mini=*p;
    p++;
    while((p-v)!=7)
    {
        if(*p<mini)
            mini=*p;
        p++;
    }
    printf("Minimul este %d",mini);
    return 0;
}


