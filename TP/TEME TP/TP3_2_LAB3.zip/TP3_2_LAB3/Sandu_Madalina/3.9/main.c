#include <stdio.h>
#include <stdlib.h>
int main()
{
    int v[10],n,*end,*p,*i, *j,aux,c;
    printf("n="); scanf("%d",&n);
    end=v;
    while((end-v)!=n)
    {
        printf("v[%d]=",end-v);
        scanf("%d",end);
        end++;
    }
    printf("Elementele tabloului:\n");
    for (p=v; p<end; p++)
    printf("%d ",*p);
    printf("\n");
    for (i=v; i<end; i++)
     {   c=0;
        for(j=i+1;j<end;j++)
            if(*i==*j)
            c=c+1;
        if(c>0)
            printf("%d apare duplicat\n",*i);
     }
    return 0;
}

