#include <stdio.h>

void citire(int *nr, int N)
{
    int *p;
    printf("Introduceti cele %d numere: ", N);
    for(p=nr; p<nr+N; p++)
        scanf("%d", &(*p));
}
void afisare(int *nr, int N)
{
    int *p;
    for(p=nr; p<nr+N; p++)
        printf("%4d", *p);
    printf("\n\n");
}
void sortare(int *nr, int N)
{
    int *p, *aux;
    int k;
    do{
        k=1;
        for(p=nr; p<nr+N; p++)
        if(*p>*(p+1)) {
            *aux=*p;
            *p=*(p+1);
            *(p+1)=*aux;
            k=0;
        }
    }while(!k);
}

int main(void)
{
    int nr, n;
    printf("n=");
    scanf("%d", &n);
    citire(&nr, n);
    afisare(&nr, n);
    sortare(&nr, n);
    afisare(&nr, n);
    system("pause");
}
