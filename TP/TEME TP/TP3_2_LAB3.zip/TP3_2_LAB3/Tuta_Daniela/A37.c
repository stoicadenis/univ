#include <stdio.h>

void afisare(int *vec, int n)
{
	int *i;
	printf("\n");
	for (i = vec; i < vec + n; i++)
		printf("%4d", *i);
	printf("\n\n");
}
void stergere(int *vec, int n)
{
	int *i, *j, *aux;
	int k = 0;
	for (i = vec; i < vec + n - k; i++)
		if (*i % 2 == 0) {
			k++;
			for (j = i; j < vec + n - k; j++)
				*j = *(j + 1);
			*i--;
		}
	n = n - k;
	for (aux = vec; aux < vec + n; aux++)
		printf("%4d", *aux);
	printf("\n\n");
}

int main(void)
{
	int n, vec[7] = { 5,8,1,4,2,6,9 };
	afisare(&vec, 7);
	stergere(&vec, 7);
	system("pause");
}
