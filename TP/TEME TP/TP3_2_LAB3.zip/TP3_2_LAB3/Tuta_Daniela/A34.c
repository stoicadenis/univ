#include <stdio.h>

void afisare(int *tab, int N)
{

    int i;
    for(i=0; i<N; i++, tab++)
        printf("%4d", *tab);
    printf("\n\n");
}
int negative(int *tab, int N)
{
    int i, k=0;
    for(i=0; i<N; i++, tab++)
        if((*tab)<0)
            k++;
        else continue;
    return k;
}

int main(void)
{
    int a[7]={7,-5,4,3,-9,2,-8};
    afisare(a, 7);
    printf(" Vectorul a[7] contine %d elemente negative.\n\n", negative(a, 7));
    system("pause");
}
