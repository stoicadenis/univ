#include <stdio.h>

void afisare(int *tab, int n)
{
    int *ptr;
    for(ptr=tab; ptr<tab+n; ptr++)
        printf("%4d", *ptr);
    printf("\n\n");
}
int minim(int *tab, int n)
{
    int *ptr;
    int min;
    min=*(tab+0);
    for(ptr=tab+1; ptr<tab+n; ptr++)
        if(*ptr<min)
            min=*ptr;
    return min;
}

int main(void)
{
    int a[7]={7,-5,4,3,-9,2,-8};
    afisare(a, 7);
    printf("Minimul elementelor din vectorul a[7] este %d.\n\n", minim(a, 7));
    system("pause");
}
