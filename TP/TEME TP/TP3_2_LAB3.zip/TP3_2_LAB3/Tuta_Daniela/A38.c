#include <stdio.h>

void afisare(int *v, int n)
{
	int *ptr;
	printf("\n");
	for (ptr = v; ptr < v + n; ptr++)
		printf("%4d", *ptr);
	printf("\n\n");
}
void insert(int *v, int n)
{
	int *ptr;
	for (ptr = v; ptr < v + n; ptr++)
		printf("%4d%4d", -(*ptr), *ptr);
	printf("\n\n");
}

int main(void)
{
	int a[7] = { 7,-5,4,3,-9,2,-8 };
	afisare(&a, 7);
	insert(&a, 7);
	system("pause");
}
