// indecsi
#include <stdio.h>

int main()
{
    int v[10];
    int i, j, n , tmp;
    n=0;
    for(;;) {
        printf("v[%d]=", n);
        scanf("%d", &v[n]);
        if(v[n]==0) break;
        n++;
    }
    for(i=0, j=n-1; i<j; i++, j--) {
        tmp=v[i];
        v[i]=v[j];
        v[j]=tmp;
    }
    for(i=0; i<n ;i++)
        printf("%d\n", v[i]);
    return 0;
}
