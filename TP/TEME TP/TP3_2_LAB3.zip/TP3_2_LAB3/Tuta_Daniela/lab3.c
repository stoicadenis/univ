#include <stdio.h>

int main()
{
    int x=10, y=7;
    int *p=&x;
    printf("%d\n", *p);
    p=&y;
    *p=*p-2;
    printf("%d\n", y);
    y=1;
    printf("%d\n", *p);
    printf("%d\n", p);
    scanf("%d", p);
    system("pause");
    return 0;
}
