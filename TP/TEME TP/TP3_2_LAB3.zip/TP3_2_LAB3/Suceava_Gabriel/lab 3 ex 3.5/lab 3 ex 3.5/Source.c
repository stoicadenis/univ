#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include<stdio.h>
#define SIZE (7)

int main()
{

	int v[8] = { 7, -5, 4, 3, -9, 2, -8 };
	int *p = NULL;
	int min = 99;

	for (p = v; p < v + SIZE; ++p)
	{
		if (*p < min)
		{
			min = *p;
		}
	}

	printf("In v minimul este %d\n\n", min);

	system("pause");
	return 0;
}