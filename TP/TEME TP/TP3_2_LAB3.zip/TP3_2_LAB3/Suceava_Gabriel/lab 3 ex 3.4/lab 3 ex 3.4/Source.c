#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include<stdio.h>
#define SIZE (7)

int main()
{
	
	int k = 0, v[8] = { 7, -5, 4, 3, -9, 2, -8 };
	int *p = NULL;

	for (p = v; p < v + SIZE; ++p)
	{
		if (*p < 0)
		{
			k++;
		}
	}

	printf("In v sunt %d elemente negative", k);

	system("pause");
	return 0;
}