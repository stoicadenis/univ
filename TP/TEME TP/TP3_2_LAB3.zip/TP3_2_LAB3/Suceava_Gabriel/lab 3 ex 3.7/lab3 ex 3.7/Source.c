#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#define SIZE (7)

int main()
{
	int v[7] = { 5, 8, 1, 4, 2, 6, 9 };
	int *p = NULL;
	int counter = 0;

	for (p = v; p < v + SIZE; ++p)
	{
		if (*p % 2 == 0)
		{
			*p = *p + 1;
			counter++;
		}
	}

	for (p = v; p < v + (SIZE - counter); ++p)
	{
		printf("%d  ", *p);
	}

	getch();
	return 0;
}