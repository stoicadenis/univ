#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>


int main()
{
	int n, aux;
	int *p = NULL;
	int v[10];

	printf("Cate numere sunt?");
	scanf("%d", &n);

	for (p = v; p < v + n; ++p)
	{
		printf("Elemente:");
		scanf("%d", &v[*p]);
	}

	for (p = v; p < v + n; ++p)
	{
		if (*p == *(p + 1))
		{
			printf("%d  ", *p);
		}
	}



	return 0;
}