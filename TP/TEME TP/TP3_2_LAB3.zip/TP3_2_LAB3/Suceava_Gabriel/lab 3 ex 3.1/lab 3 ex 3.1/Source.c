#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

int main()
{
	double a, b;
	int *p, *r;
	printf("a="); scanf("%lf", &a);
	printf("b="); scanf("%lf", &b);

	printf("%lf %lf\n", a, b);

	p = &a;
	r = &b;

	if (&p < &r)
	{
		printf("a\n");
	}
	else
	{
		printf("b\n");
	}
	system("pause");
	return 0;
}