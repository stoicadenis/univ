#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int main()
{
	int a, b;
	int *p;

	printf("a="); scanf("%d", &a);
	printf("b="); scanf("%d", &b);

	if (a > b)
	{
		p = &a;
	}
	else
	{
		p = &b;
	}

	printf("%d", *p);

	system("pause");
	return 0;
}