#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>


int main()
{
	int v[7], n;
	int *p = NULL;
	int aux;

	printf("Cate numere sunt?");
	scanf("%d", &n);

	for (p = v; p < v + n; ++p)
	{
		printf("Elemente:");
		scanf("%d", &v[p]);
	}

	for (p = v; p < v + n; ++p)
	{
		if (*p > *(p + 1))
		{
			aux = *p;
			*p = *(p + 1);
			*(p + 1) = aux;
		}
	}

	for (p = v; p < v + n; ++p)
	{
		printf("%d  ", v[*p]);
	}

	return 0;
}