#define _CRRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

void interschimba(int *a, int *b)
{
	int aux;
	aux = *a;
	*a = *b;
	*b = aux;
}

int main()
{
	int x = 10, y = 5;
	interschimba(&x, &y);
	printf("%d %d\n", x, y);

	system("pause");
	return 0;
}