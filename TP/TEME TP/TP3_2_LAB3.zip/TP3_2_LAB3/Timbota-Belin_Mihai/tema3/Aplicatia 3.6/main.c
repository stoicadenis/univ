#include <stdio.h>
#include <stdlib.h>

void citire(int v[], int n)
{
    int *p=v;
    while(p-v<n)
          {
            scanf("%d",p);
            p++;
          }


}

void sortare(int v[],int n)
{
    int *p, *q;
  for(p=v;p<v+n-1;p++)
    for(q=p;q<v+n;q++)
    if(*p<*q)
  {
      int aux=*p;
      *p=*q;
      *q=aux;
      q--;
  }
}

void afisare(int v[], int n)
{
     int *p=v;
    while(p-v<n)
        printf("%d ",*p++);
}

int main()
{
    int v[10], n;

    printf("n=");
    scanf("%d",&n);

    citire(v,n);
    sortare(v,n);
    afisare(v,n);

    return 0;
}
