#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b, *p;


    printf("a=");
    scanf("%d",&a);
    printf("b=");
    scanf("%d",&b);

    if(a>b)
        p=&a;
    else
        p=&b;

    printf("valoarea mai mare este %d",*p);

    return 0;
}
