#include <stdio.h>
#include <stdlib.h>

void afisare(int v[], int n)
{
    int *p=v;
    while(p-v<n)
        printf("%d ",*p++);
}

void inserare(int v[],int *n)
{
    int *p,*q;
    for(p=v+*n-1; p>=v; p--)
    {
        for(q=v+*n; q>p; q--)
            *q=*(q-1);
        *(p)=(-1)**(p+1);
        (*n)++;

    }

}

int main()
{
  int v[]={7,-5,4,3,-9,2,8},n;

   n=sizeof(v)/sizeof(int);

inserare(v,&n);
afisare(v,n);
    return 0;
}
