#include <stdio.h>
#include <stdlib.h>

void afisare(int v[], int n)
{
     int *p=v;
    while(p-v<n)
        printf("%d ",*p++);
}

void stergere(int v[],int *n)
{
    int *p,*q;
    for(p=v;p<v+*n;p++)
    {

        if(*p%2==0)
        {
            for(q=p;q<v+*n-1;q++)
                *q=*(q+1);
            p--;
            (*n)--;
        }
   }

}


int main()
{
   int v[]={5,8,1,4,2,6,9},n;

   n=sizeof(v)/sizeof(int);

stergere(v,&n);
afisare(v,n);



    return 0;
}
