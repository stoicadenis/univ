#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[]= {7, -5, 4, 3, -9, 2, -8}, n;
    int *p,c=0;

    p=v;
    n=sizeof(v)/sizeof(int);
    while(p<=v+n)

    {
        if(*p<0)
            c++;
        p++;
    }
    printf("%d", c);
    return 0;
}
