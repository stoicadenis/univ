#include <stdio.h>
#include <stdlib.h>


void citire(int v[], int n)
{
    int *p=v;
    while(p-v<n)
    {
        scanf("%d",p);
        p++;
    }
}

void func(int v[], int n)
{
    int v2[10],k=0,flag;
    int *p, *q, *r;

    for(p=v; p<v+n; p++)
        for(q=v; q<v+n; q++)
        {
            flag=0;
            if(p!=q && *p==*q)
            {
                printf("da ");
                printf("%d %d\n",*p,*q);
                for(r=v2; r<v2+k; r++)
                    if(*r==*p)
                        flag=1;


                if(!flag)
                {
                    *(v2+k)=*q;
                    k++;
                }

            }

        }
    if(k==0)
        printf("nu exista");
    else
        for(r=v2; r<v2+k; r++)
            printf("%d ",*r);


}

int main()
{
    int v[10], n;

    printf("n=");
    scanf("%d",&n);

    citire(v,n);
    func(v,n);


    return 0;
}
