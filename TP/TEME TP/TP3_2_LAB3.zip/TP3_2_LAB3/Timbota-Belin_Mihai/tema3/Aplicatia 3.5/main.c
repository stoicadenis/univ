#include <stdio.h>
#include <stdlib.h>

int main()
{
    int v[]= {7, -5, 4, 3, -9, 2, -8},n;
    int *p,min;

    p=v;
    min=*p;
    n=sizeof(v)/sizeof(int);
    while(p<=v+n)
    {
        if(*p<min)
            min=*p;
        p++;
    }
    printf("min = %d", min);
    return 0;
}
