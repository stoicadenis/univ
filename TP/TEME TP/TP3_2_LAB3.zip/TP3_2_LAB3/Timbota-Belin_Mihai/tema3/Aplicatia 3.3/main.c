#include <stdio.h>
#include <stdlib.h>

void func(int *pa, int *pb)
{
    int aux=*pa;
    *pa=*pb;
    *pb=aux;
}


int main()
{
    int a,b;

    printf("a=");
    scanf("%d",&a);
    printf("b=");
    scanf("%d",&b);

    func(&a, &b);
    printf("a=%d\n",a);
    printf("b=%d",b);


    return 0;
}
