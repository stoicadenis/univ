#include <stdio.h>
#include <stdlib.h>



void citire(int a[], int n, int i)
{
    if (i < n)
    {
        if(scanf("%d", &a[i]) == 1)
        {
            citire(a, n, i+1);
        }
    }
}

void afisare(int a[], int n, int i)
{
    if(i<n)
    {
        printf("%d ",a[i]);
        afisare(a, n, i+1);
    }

}

int nr_pare(int a[],int n, int i)
{
    if(i<n)
        return (a[i]+1)%2 + nr_pare(a,n,i+1);
    return 0;
}


int det(int a,int min, int k)  // min=9, k=1;
{
    if(a==0)
        return k;

    if(a%10<min)
    {
        k=1;
        min=a%10;
    }
    else if(min==a%10)
        k++;

    det(a/10,min,k);

}

void func(int a[],int b[], int n, int i)
{
    if (i < n)
    {
       b[i]=det(a[i],9,1);
       func(a,b,n,i+1);

    }
}


int main()
{
    int a[100], b[100], n, min;

    printf("n=");
    scanf("%d",&n);

    citire(a,n,0);
    afisare(a,n,0);



    printf("\nnumarul elementelor pare este = %d\n", nr_pare(a,n,0));

    func(a,b,n,0);

    printf("numarul de aparatii a cifrei minime din fiecare element:\n");

    afisare(b,n,0);


    return 0;
}
