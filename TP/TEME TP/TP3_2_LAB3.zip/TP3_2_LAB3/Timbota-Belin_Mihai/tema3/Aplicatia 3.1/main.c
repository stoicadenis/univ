#include <stdio.h>
#include <stdlib.h>

int main()
{
   double a,b, *pa, *pb;

   pa=&a;
   pb=&b;

   printf("a=");
   scanf("%lf",pa);
   printf("b=");
   scanf("%lf",pb);

   if(pa<pb)
    printf("a se afla la adresa mai mica");
   else
     printf("b se afla la adresa mai mica");


    return 0;
}
