#include <stdio.h>
#include <stdlib.h>

int main()
{
int a[100], aux;
int *p=a, *q;

do{
    printf("x= ");
    scanf("%d",p);

    if(*p==0)
        break;

    for(q=a;q<p;q++)
        if(*p<*q)
    {
        aux=*p;
        *p=*q;
        *q=aux;
    }

p++;

    for(q=a;q<p;q++)
        printf("%d ",*q);
          printf("\n");

}
while(1);


    return 0;
}
