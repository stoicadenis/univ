#include <stdio.h>
#include <stdlib.h>

int main()
{
    int opt;
    float a[100],x,*p,*q,*r;

    p=a;

    printf("1) citire valoare reala\n");
    printf("2) afisare\n");
    printf("3) stergere\n");
    printf("4) iesire\n");


    do
    {
        printf("\noptiunea dvs este: ");
        scanf("%d",&opt);

        switch(opt)
        {
        case 1:

            printf("x= ");
            scanf("%f",p++);
            break;

        case 2:

            for(q=a; q<p; q++)
                printf("%f ",*q);
            break;

        case 3:

            printf("x= ");
            scanf("%f",&x);

            for(q=a; q<p; q++)
            {
                if(*q==x)
                {
                    for(r=q; r<p-1; r++)
                        *r=*(r+1);
                    p--;
                }
            }
            printf("numarul a fost sters\n");
            break;

        case 4:
            exit(0);
            break;
        default:
            printf("ati introdus o optiune gresita\n");
        }
    }
    while(1);

    return 0;
}
