#include <stdio.h>
#include <stdlib.h>

int prim(int n, int i)
{
    if (n <= 2)
        return (n == 2) ? 1 : 0;
    if (n % i == 0)
        return 0;
    if (i * i > n)
        return 1;

         return prim(n, i + 1);
}

void afisare(int a[], int n, int i)
{
    if(i<n)
    {
        printf("%d ",a[i]);
        afisare(a, n, i+1);
    }

}

void generare(int a[], int n, int i, int j)
{
    if (i < n)
    {
        if(prim(j,2) == 1)
        {
            a[i]=j;
            generare(a,n,i+1,j+1);
        }
        else
        generare(a,n,i,j+1);
    }
}



int main()
{
    int a[100], n;

    printf("n=");
    scanf("%d",&n);

    generare(a,n,0,0);
    afisare(a,n,0);

    return 0;
}
