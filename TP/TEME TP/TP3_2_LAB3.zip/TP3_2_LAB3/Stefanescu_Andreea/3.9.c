#include<stdio.h>
#include<stdlib.h>
void citire(int n, int* v)
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("v[%d]= ", i);
		scanf("%d", v + i);
	}
}

void afisare(int n, int* v)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", *(v + i));
}

void duplicat(int n, int* v)
{
	int i,j,nr;
	for (i = 0; i < n; i++)
	{
		nr = 0;
		for (j = i; j < n; j++)
			if (*(v + i) == *(v + j))
                nr = nr + 1;
			if (nr > 1) printf("Elementul %d are duplicat \n", *(v+i));
	}

}

int main()
{
	int v[10], n;
	printf("Dati nr de elemente=");
	scanf("%d", &n);
	citire(n, v);
	afisare(n, v);
	printf("\n");
	duplicat(n, v);
	return 0;
}
