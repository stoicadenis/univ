#include<stdio.h>
#include<stdlib.h>

void citire( int v[],int n)
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("v[%d]= ",i);
		scanf("%d", v + i);
	}
}

void afisare( int v[],int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", *(v + i));
		printf("\n");
}

void sortare(int v[],int n)
{
	int i,j,aux,k;
		do
		{
			k = 0;
			for (i = 0; i < n; i++)
                for(j=0;j<n;j++)
            {

			if (*(v + i) > *(v + j))
			{
				aux = *(v + i);
				*(v + i) = *(v + j);
				*(v + j) = aux;
			}
				k = 1;
			}

		}
		while (!k);

}

int main()
{
	int v[10], n;
	printf("n= ");
	scanf("%d", &n);
	citire(v,n);
	afisare(v,n);
	sortare(v,n);
	afisare(v,n);
	return 0;
}
