
#include<stdio.h>
void tiparire(int *tab, int n)
{
int * ptr;
for (ptr=tab; ptr<tab + n; ptr++)
printf("%d  ", *ptr);
 }
 void negativ(int *tab,int n)
 {
     int *ptr,nr=0;
     for(ptr=tab;ptr<tab+n;ptr++)
     {
         if(*ptr<0)
         {
             nr=nr+1;
         }

     }
     printf("Nr de nr negative este %d",nr);
 }
 int main()
 {
 int v[7]={7,-5,4,3,-9,2,-8};
 tiparire(v,7);
 printf("\n");
 negativ(v,7);
 }
