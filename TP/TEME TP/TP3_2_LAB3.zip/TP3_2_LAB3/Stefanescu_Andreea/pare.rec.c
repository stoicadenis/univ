#include <stdio.h>
#include <stdlib.h>
void citire(int v[], int n)
{
	if (n == 1)
	{
		printf("v[%d]= ", n);
		scanf("%d", &v[n]);
	}
	else
	{
		printf("v[%d]= ", n);
		scanf("%d", &v[n]);
		citire(v,n-1);
	}
}

void afisare(int v[], int n)
{
	if (n == 1)
		printf("%d ", v[n]);
	else
	{
		printf("%d ", v[n]);
			afisare(v,n-1);
	}
}


int pare(int v[],int n,int nr)
{
if (n == 1)
	{
		if (v[n] % 2 == 0)
            nr = nr + 1;
	}
	else
		{
		if (v[n] % 2 == 0)
            nr = nr + 1;
		pare(v,n-1,nr);
		}


}

int main()
{
    int v[10], n,nr=0;
    printf("n=");
    scanf("%d",&n);
    citire(v,n);
    afisare(v,n);
    printf("Vectorul are %d nr pare", pare(v,n,nr));
    return 0;
}
