#include <stdio.h>
#include <stdlib.h>
void adresa(double x,double y)
{
double *p,*q;
p=&x;
q=&y;
if(p<q) printf("Variabila care se afla la adresa cea mai mica de memorie e 'x'");
else
    printf("Variabila care se afla la cea mai mica adresa e 'y'");

}

int main()
{
    double x,y;
    printf("x=");
    scanf("%lf",&x);
     printf("y=");
    scanf("%lf",&y);
    adresa(x,y);

    return 0;
}
