
#include<stdio.h>
void tiparire(int *tab, int n)
{
int * ptr;
for (ptr=tab; ptr<tab + n; ptr++)
printf("%d  ", *ptr);
 }
 void minim(int *tab,int n)
 {
     int *ptr,min=*tab;
     for(ptr=tab;ptr<tab+n;ptr++)
     {
         if(*ptr<min)
         {
             min=*ptr;
         }

     }
     printf("Minimul este %d",min);
 }
 int main()
 {
 int v[7]={7,-5,4,3,-9,2,-8};
 tiparire(v,7);
 printf("\n");
 minim(v,7);
 }
