#include <stdio.h>
#include <stdlib.h>


void afisare(int v[], int n)
{
	if (n == 1)
		printf("%d ", v[n]);
	else
	{
		printf("%d ", v[n]);
			afisare(v,n-1);
	}
}

int prim(int v[],int n,int d)
{
if(d==1) return 1;
if(v[n]%d==0) return 0;
else return prim(v,n-1,d-1);
}
int main()
{

int n,d,v[10];
printf("n=");
scanf("%d",&n);
prim(v,n,d);
afisare(v,n);
return 0;
}
