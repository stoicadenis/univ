/*Se citesc doua variabile a si b, de tip intreg. Sa se stocheze intr-un pointer
adresa variabilei care contine valoarea maxima si apoi sa se afiseze valoarea pointata.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,*p;
    printf("a="); scanf("%d",&a);
    printf("b="); scanf("%d",&b);
    if(a>b) p=&a;
    else p=&b;
    printf("%d\n",*p);
    printf("%p\n",p);

    system("pause");
    return 0;
}
