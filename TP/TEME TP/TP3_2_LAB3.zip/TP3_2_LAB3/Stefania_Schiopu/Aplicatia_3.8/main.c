/*Se da vectorul {7,-5,4,3,-9,2,-8}. Sa se insereze inainte de fiecare valoare din vectorul original
negativul ei. Utilizati pointeri, fara indecsi.*/

//imi afiseaza 0 peste tot...

#include <stdio.h>
#include <stdlib.h>

#define MAX 30

void Inserare(int *p,int *n)
{
    int i,j,k=0;
    for(i=0;i<(*n+k);i++)
        if((*(p+i))>0)
        {
            k++;
            for(j=(*n+k-1);j>i;j--)
            {
                *(p+j-1)=*(p+j);
            }
            *(p+i)=-(*(p+i));
            i++;
        }
    *n=*n+k;
}

void Afisare(int *p,int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%2d",*(p+i));
    printf("\n");
}

int main()
{
    int v[MAX]={7,-5,4,3,-9,2,-8},n=7;
    int *p=v;
    Inserare(p,&n);
    Afisare(p,n);



    system("pause");
    return 0;
}
