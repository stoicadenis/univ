/*Se citesc n<=10 valori intregi. Folosind doar pointeri, fara niciun fel de indexare,
sa se afle toate valorile care au cel putin un duplicat. (Inclusiv citirea se va face cu pointeri.)*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 20

void Citire(int *p,int n)
{
    int i;
    for(i=0;i<n;i++)
        scanf("%d",(p+i));
}

void Duplicat(int *p,int n,int vect[MAX])
{
    int i,k=0,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if((*(p+i)==*(p+j)) && (i!=j))
//trebuie puse in vector doar o singura data!
            {
                vect[k]=*(p+i);
                k++;
            }
    for(i=0;i<k;i++)
    {
        printf("%d ",vect[i]);
    }
    printf("\n");
} //functia Duplicat contine si afisarea vectorului in care elementele reprezinta acele valori care au cel putin un duplicat


int main()
{
    int nr,v[MAX],*p,vect[MAX];
    p=v;
    printf("Introduceti numarul de elemente pe care doriti sa il cititi (nr<=10) nr=");
    scanf("%d",&nr);
    Citire(p,nr);
    Duplicat(p,nr,vect);




    system("pause");
    return 0;
}
