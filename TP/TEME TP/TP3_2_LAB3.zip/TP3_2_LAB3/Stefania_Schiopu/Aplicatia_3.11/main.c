/*Sa se implementeze, fara a se folosi indecsi, urmatorul program:
se citeste pe rand cate o valoare intreaga si se insereaza intr-un vector astfel incat
vectorul sa fie mereu sortat crescator. Dupa fiecare inserare se va afisa noul vector.
Programul se termina la citirea valorii 0. Presupunem ca vectorul va avea maximum 100 de elemente.*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 100

void Insereaza(int *p,int *n)
{
    (*n)++;
    printf("x[%d]=",*n);
    scanf("%d",(p+(*n)));
}

void Sortare(int *p,int n)
{
    int i,aux,k;
    do
    {
        k=1;
        for(i=1;i<=n;i++)
            if(*(p+i-1)>*(p+i))
            {
                aux=*(p+i-1);
                *(p+i-1)=*(p+i);
                *(p+i)=aux;
                k=0;
            }
    }while(!k);
}

void Afisare(int *p,int n)
{
    int i;
    for(i=0;i<=n;i++)
        printf("%d ",*(p+i));
    printf("\n");
}


int main()
{
    int v[MAX],*p,n=-1;
    p=v;
    do
    {
            Insereaza(p,&n);
            if(*(p+n)==0)
                break;
            else
            {
                Sortare(p,n);
                Afisare(p,n);
            }

    }while(1);



    system("pause");
    return 0;
}
