/*Sa se implementeze fara a se folosi variabile index, un program cu urmatorul meniu:
1. Citire (citeste o valoare reala si o adauga intr-un vector cu maximum 100 de elemente);
2. Afisare (afiseaza toate valorile din vector);
3. Stergere (citeste o valoare si sterge toate elementele egale cu valoarea citita);
4. Iesire.*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 30

void Citire(int *p,int *n)
{
    (*n)++;
    printf("v[%d]=",(*n));
    scanf("%d",(p+(*n)));
}

void Afisare(int *p,int n)
{
    int i;
    for(i=0;i<=n;i++)
        printf("%d ",*(p+i));
    printf("\n");
}

void Stergere(int *p,int *n,int x)
{
    int i,j,k=0;
    for(i=0;i<=(*n-k);i++)
        if(*(p+i)==x)
        {
            k++;
            for(j=i;j<=(*n-k);j++)
                *(p+j)=*(p+j+1);
            i--;
        }
        *n=*n-k;
}



int main()
{
    int n=-1,*p,v[MAX],x;
    p=v;
    enum meniu {liber, citire, afisare, stergere, iesire} opt;

    do
    {
        printf("\n1.Citire\n");
        printf("2.Afisare\n");
        printf("3.Stergere\n");
        printf("4.Iesire\n");
        printf("Optiunea dumneavoastra este: ");
        scanf("%d",&opt);
        switch(opt)
        {
        case citire:
            Citire(p,&n);
            break;
        case afisare:
            Afisare(p,n);
            break;
        case stergere:
            printf("Introduceti elementul pe care doriti sa il stergeti: ");
            scanf("%d",&x);
            Stergere(p,&n,x);
            break;
        case iesire:
            exit(0);
            break;

        default:
            printf("\nOptiune inexistenta! Te rugam sa alegi o optiune valida.\n");
            break;
        }

    }while(1);



    system("pause");
    return 0;
}
