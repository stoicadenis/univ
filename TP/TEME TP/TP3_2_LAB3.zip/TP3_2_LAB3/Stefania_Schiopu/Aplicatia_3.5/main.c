/*Sa se afiseze minimul elementelor din vectorul {7, -5, 4,3, -9, 2, -8} utilizand pointeri,
fara indecsi. (Fara indecsi inseamna ca in cod nu va exista niciun v[i])*/
#include <stdio.h>
#include <stdlib.h>

#define MAX 20

int main()
{
    int v[MAX]={7,-5,4,3,-9,2,-8},*p,min;
    p=v;
    min=*(p+0);
    for(int i=0;i<7;i++)
        if((*(p+i))<min)
            min=*(p+i);
    printf("Minimul dintre elementele vectorului este %d.\n",min);

    system("pause");
    return 0;
}

