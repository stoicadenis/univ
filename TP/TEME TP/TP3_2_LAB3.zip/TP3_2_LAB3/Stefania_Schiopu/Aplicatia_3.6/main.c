/*Se citeste un numar n (n<=10) si apoi n numere intregi. Se cere sa se sorteze aceste numere in ordine
descrescatoare utilizand pointeri, fara indecsi. (Inclusiv citirea se va face cu pointeri.)*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 20

void Sortare(int *p,int n)
{
    int i,k,aux;
    do
    {
        k=1;
        for(i=1;i<n;i++)
            if((*(p+i-1))<(*(p+i)))
            {
                aux=*(p+i-1);
                *(p+i-1)=*(p+i);
                *(p+i)=aux;
                k=0;
            }
    }while(!k);
}

void Afisare(int *p,int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d ",*(p+i));
}

int main()
{
    int n,v[MAX],*p,i;
    p=v;
    printf("n=");
    scanf("%d",&n);
    if(n>10)
        printf("Numarul introdus trebuie sa fie mai mic sau egal decat 10.\n");
    else
    {
        for(i=0;i<n;i++)
            scanf("%d",(p+i));
    Sortare(p,n);
    Afisare(p,n);
    }

    system("pause");
    return 0;
}
