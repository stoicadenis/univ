/*Sa se afiseze cate elemente negative sunt in vectorul {7, -5, 4,3, -9, 2, -8} utilizand pointeri,
fara indecsi. (Fara indecsi inseamna ca in cod nu va exista niciun v[i])*/
#include <stdio.h>
#include <stdlib.h>

#define MAX 20

int main()
{
    int v[MAX]={7,-5,4,3,-9,2,-8},i,k=0,*p;
    p=v;
    for(i=0;i<7;i++)
        if((*(p+i))<0)
            k++;
    printf("In vector sunt %d elemente negative.\n",k);

    system("pause");
    return 0;
}
