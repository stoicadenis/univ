/*Sa se stearga din vectorul {5,8,1,4,2,6,9} toate elementele pare, pastrand neschimbata
ordinea elementelor, dupa care sa se afiseze noul vector. Utilizati pointeri, fara indecsi.*/

//nu imi afiseaza ultimul element care e 9...

#include <stdio.h>
#include <stdlib.h>

#define MAX 10

void Stergere (int *p,int *n)
{
    int i,j,k=0;
    for(i=0;i<=(*n-k);i++)
        if((*(p+i))%2==0)
        {
            k++;
            for(j=i;j<=(*n-k);j++)
                *(p+j)=*(p+j+1);
            i--;
        }
    *n=*n-k;
}

void Afisare(int *p,int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d ",*(p+i));
    printf("\n");
}

int main()
{
    int v[MAX]={5,8,1,4,2,6,9},n=7;
    int *p;
    p=v;
    Stergere(p,&n);
    Afisare(p,n);

    system("pause");
    return 0;
}
