#include <stdio.h>
#include <stdlib.h>

void incercare(int a,int b)
{
    int aux=a;
    a=b;
    b=aux;
}

void interschimba(int *pa,int *pb)
{
    int aux=*pa;
    *pa=*pb;
    *pb=aux;
}

int main()
{
    int x=10,y=7;
    incercare(x,y);
    printf("%d %d\n",x,y);
    interschimba(&x,&y);
    printf("%d %d\n",x,y);

    system("pause");
    return 0;
}
