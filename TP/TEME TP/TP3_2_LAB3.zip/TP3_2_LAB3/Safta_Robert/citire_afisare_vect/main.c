#include <stdio.h>
#include <stdlib.h>
void citire(int v[10],int n)
{
    if(n==1)
    {
        scanf("%d",&v[n]);
    }
    else
    {
        scanf("%d",&v[n]);
        citire(v,n-1);
    }
}

void afisare(int v[10],int n)
{
    if(n==1)
    {
        printf("%d ",v[n]);
    }
        else
        {
            printf("%d ",v[n]);
            afisare(v,n-1);
        }

}
    int main()
    {
       int n,v[10];
scanf("%d",&n);
citire(v,n);
afisare(v,n);
        return 0;
    }
