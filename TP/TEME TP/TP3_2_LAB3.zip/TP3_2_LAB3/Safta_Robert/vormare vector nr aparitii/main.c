#include <stdio.h>
#include <stdlib.h>
int minim(int n)
{  if ( n <= 9 ) return n;
   else
   {
       int m = minim(n/10);
       if ( m < n%10 )
          return m;
       else
           return n%10;
   }
}
int main()
{
  int v[10],p[10],i,k,m,t;
  scanf("%d",&t);
  for(i=0;i<t;i++)
  {
      scanf("%d",&v[i]);
  }
  for(i=0;i<t;i++)
  {
      k=0;
     m= minim(v[i]);
      while(v[i])
      {
          if(v[i]%10==m) k++;
          v[i]=v[i] /10;
      }
      p[i]=k;
  }
   for(i=0;i<t;i++)
    printf("%d ",p[i]);
    return 0;
}
