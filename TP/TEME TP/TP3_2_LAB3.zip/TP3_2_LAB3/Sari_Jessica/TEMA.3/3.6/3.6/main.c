#include <stdio.h>
#include <stdlib.h>
void citire(int *v, int n)
{
    int i;
    for (i=0; i<n; i++)
    scanf("%d", (i+v));
}
void afisare(int *v, int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d  ", *v++);
    printf("\n");
}
void sortare(int *v,int n )
{
    int i, aux=0;
    for(i=0;i<n;i++)
    {
        for(int j = 1; j < n-i; j++)
        {
            if((*(v+j-1))<(*(v+j)))
        {
            aux=*(v+j-1);
            *(v+j-1)=*(v+j);
            *(v+j)=aux;
        }
        }
    }
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int v[n];
    citire(v, n);
    afisare(v, n);
    sortare(v, n);
    printf("\nelementele sortate descrescator: \n");
    afisare(v, n);
    return 0;
}
