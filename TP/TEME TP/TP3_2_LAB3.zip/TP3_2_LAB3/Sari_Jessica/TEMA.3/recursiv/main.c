#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#include<conio.h>
void citire(int* v, int n) {
  if (n > 0) {
    scanf("%d", v);
    citire(v + 1, n - 1);
  }
}
void afisare(int v[], int n, int i)
{
    if (i == n)
    {
        printf("\n");
        return;
    }
    printf("%d ", v[i]);
    i++;
    afisare(v, n, i);
}
void pare(int v[], int n, int i)
{
    if(i == n)
    {
        printf("\n");
        return;
    }
    if(v[i]%2 == 0)
    {
        printf("%d  ", v[i]);
    }
    i++;
    pare(v, n, i);
}
/*
int minim(int a[],int n)
{
    int min;

    if(n==1)
        return a[0];

    else {
        min=minim(a,n-1);

        if(min<a[n-1])
            return min;
        else
            return a[n-1];
    }

} */
int min(int a, int b)
{
    if (a==0)
        return b;
    if (b>a%10)
        b=a%10;

    min(a/10,b);
}
int counter(int a, int c)
{
    int count=0;
    if (a==0)
        count=0;
    else if ((a%10)==c)
    {
        count++;
        count=count+counter(a/10, c);
    }
    else
    {
        count=count+counter(a/10, c);
    }
    return count;
}

void cifraMinima(int v[], int n, int i, int a[])
{
    if(i == n)
    {
        printf("\n");
        return;
    }
    int d=min(v[i], 9);
    a[i]=counter(v[i], d);
    i++;
    cifraMinima(v, n, i, a);

}
int isPrime(int num,int i)
{
    if(i==1)
    {
        return 1;
    }
    else
    {
       if(num%i==0)
         return 0;
       else
         isPrime(num,i-1);
    }
}
int prime(int v[],int n, int i, int counterr)
{
    if(i == n)
    {
        printf("\n");
        return counterr;
        system("pause");
    }

    if(isPrime(i, i/2)==1)
    {
       v[counterr]=i;
       counterr++;
    }
    i++;
    prime(v, n, i++, counterr);

}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int v[n], a[n], p[n];
    citire(v, n);
    printf("Elementele vectorului sunt: ");
    afisare(v, n, 0);
    printf("Numerele pare sunt: ");
    pare(v, n, 0);
    printf("find the number of occurrences of the smallest digit of each element of an array \nand adding this number of occurrences inside another array: ");
    cifraMinima(v, n, 0, a);
    afisare(a, n, 0);
    printf("create an array of prime numbers from 3 to n: ");
    prime(p, n, 3, 0);
    afisare(p, n, 0);
    return 0;
}
