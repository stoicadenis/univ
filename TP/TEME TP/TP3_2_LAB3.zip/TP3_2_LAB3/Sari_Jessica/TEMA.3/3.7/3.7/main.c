#include <stdio.h>
#include <stdlib.h>
void citire(int *v, int n)
{
    int i;
    for (i=0; i<n; i++)
    scanf("%d", (i+v));
}
void afisare(int *v, int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d  ", *v++);
    printf("\n");
}
int deleteElement(int *v, int n)
{
   int i, m=0;
   for (i=0; i<n; i++)
    {
        if(*(v+i)%2!=0)
        {
            if(i!=m)
                *(v+m)=*(v+i);
            ++m;
        }
    }
    return m;
}

int main()
{
    int n, x;
    printf("n=");

    scanf("%d", &n);
        printf("elements of the array are: ");
    int v[n];
    citire(v, n);
    afisare(v, n);
    printf("the uneven elements of the array are:\n ");
    int m=deleteElement(v, n);
    afisare(v, m);
    for ( int i = 0; i < m; i++ ) printf( "%d ", *(v+i));
    printf( "\n" );
    return 0;
}
