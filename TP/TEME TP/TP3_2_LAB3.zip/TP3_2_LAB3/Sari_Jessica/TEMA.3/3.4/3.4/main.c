#include <stdio.h>
#include <stdlib.h>
void citire(int *v, int n)
{
    int i;
    for (i=0; i<n; i++)
    scanf("%d", (i+v));
}
void afisare(int *v, int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d  ", *v++);
    printf("\n");
}
void negative(int *v, int n)
{
    int i, counter=0;
    for(i=0;i<n;i++)
    {
        if((*v++)<0)
            counter++;
    }
    printf("sunt %d elemente negative\n", counter);
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int v[n];
    citire(v, n);
    afisare(v, n);
    negative(v, n);
    return 0;
}
