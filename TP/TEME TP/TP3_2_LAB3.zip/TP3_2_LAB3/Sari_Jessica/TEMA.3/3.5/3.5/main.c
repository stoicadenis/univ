#include <stdio.h>
#include <stdlib.h>
void citire(int *v, int n)
{
    int i;
    for (i=0; i<n; i++)
    scanf("%d", (i+v));
}
void afisare(int *v, int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d  ", *v++);
    printf("\n");
}
void minim(int *v, int n)
{
    int i, mini=0;
    for(i=0;i<n-1;i++)
    {
        if(*(v+i)<mini)
        {
            mini=*(v+i);
        }
    }
    printf("minimul este %d", mini);
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int v[n];
    citire(v, n);
    afisare(v, n);
    minim(v, n);
    return 0;
}
