#include<stdio.h>

//Citirea recursiva a vectorului
void citire(int n, int v[])
{
	if (n == 1)
	{
		printf("v[%d]= ", n);
		scanf("%d", &v[n]);
	}
	else
	{
		printf("v[%d]= ", n);
		scanf("%d", &v[n]);
		citire(n - 1,v);
	}
}

//Afisarea recursiva a vectorului
void afisare(int n, int v[])
{
	if (n == 1)
		printf("%d ", v[n]);
	else
	{
		printf("%d ", v[n]);
			afisare(n - 1,v);
	}
}

//Aflarea elementelor pare dintr-un vector utilizand recursivitatea
int pare(int n, int v[], int nr)
{

	if (n == 1)
	{
		if (v[n] % 2 == 0) nr = nr + 1;
	}
	else
		{
		if (v[n] % 2 == 0) nr = nr + 1;
		pare(n - 1, v,nr);
		}

}



int main()
{
	int n, v[10],nr=0;
	printf("Dati dimensiunea vectorului");
	scanf("%d", &n);
	citire(n,v);
	afisare(n,v);
	printf("Vectorul are %d nr pare", pare(n, v,nr));
	return 0;
}

