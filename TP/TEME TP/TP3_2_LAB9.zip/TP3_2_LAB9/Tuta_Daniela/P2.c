#include <stdio.h>
#include <stdlib.h>

int main()
{

    FILE *fisier;
    fisier = fopen("/stud/lab/mess ", "w");
    if(!fisier) {
        perror("Eroare la deschiderea fisierului!\n");
        exit(EXIT_FAILURE);
    }
    fclose(fisier);
    return 0;
}
