#include <stdio.h>


int main()
{
    FILE *fin;
    FILE *fout;
    float salar;
    if((fin=fopen("in.txt", "r"))==NULL) {
        printf("Eroare deschidere fisier in.txt!\n");
        return -1;
    }
    if((fout=fopen("indexate.txt", "w"))==NULL) {
        printf("Eroare deschidere fisier indexate.txt!\n");
        return -1;
    }
    while(!feof(fin)) {
        fscanf(fin, "%g\n", &salar);
        if(salar<1000) {
            salar=salar+0.15;
            fprintf(fout, "%g\n", salar);
        }
        else fprintf(fout, "%g\n", salar);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
