#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 100


int main(void)
{
    char nume_fisier[MAX_LEN];
    FILE *fisier;
    int c;
    printf("Nume fisier: ");
    fgets(nume_fisier, MAX_LEN, stdin);
    nume_fisier[strlen(nume_fisier)-1]=0;
    fisier=fopen(nume_fisier, "w");
    if(!fisier) {
        perror("Eroare deschidere fisier!\n");
        exit(EXIT_FAILURE);
    }
    while((c=getchar())!=EOF&&!isspace(c))
    fputc(c, fisier);
    fclose(fisier);
    return 0;
}
