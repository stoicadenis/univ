#include <stdio.h>

int main()
{
    FILE *fisier;
    int n, i, j;
    printf("n=");
    scanf("%d", &n);
    if((fisier=fopen("P1.txt", "w"))==NULL) {
        printf("Fisierul P1.txt nu poate fi deschis!\n");
        return -1;
    }
    for(i=0; i<n; i++) {
    for(j=0; j<n; j++) {
        if(i>j) fprintf(fisier, "+");
        else if(i<j) fprintf(fisier, "-");
        else fprintf(fisier, "0");
        }
        fprintf(fisier, "\n");
    }
}
