#include <stdio.h>
#include <math.h>


int main()
{
    FILE *fisier;
    float x[10], y[10];
    double distanta[10];
    float min;
    int i=0, n, aux;
    if((fisier=fopen("P3.txt", "r"))==NULL) {
        printf("Eroare deschidere fisier!\n");
        return -1;
    }
    while(!feof(fisier)) {
        fscanf(fisier, "%g %g", &x[i], &y[i]);
        distanta[i]=sqrt(x[i]*x[i]+y[i]*y[i]);
        i++;
    }
    n=i;
    min=distanta[0];
    for(i=0; i<(n-1); i++) {
        if(min>distanta[i]) {
            min=distanta[i];
            aux=i;
        }
    }
    printf(" %g %g\n", x[aux], y[aux]);
    fclose(fisier);
    return 0;
}
