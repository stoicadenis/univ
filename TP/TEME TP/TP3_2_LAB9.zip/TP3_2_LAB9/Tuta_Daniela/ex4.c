#include <stdio.h>
#include <ctype.h>


int main()
{
    FILE *fisin;
    FILE *fisout;
    char nume[100];
    char ch;
    printf("Fisier de intrare: ");
    gets(nume);
    if((fisin=fopen(nume, "r"))==NULL) {
        printf("Eroare deschidere fisier %s!\n", nume);
        return -1;
    }
    if((fisout=fopen("e4.txt", "w"))==NULL) {
        printf("Eroare deschidere fisier e4.txt!\n");
        fclose(fisin);
        return -1;
    }
    while((ch=fgetc(fisin))!=EOF) {
        ch=toupper(ch);
        fputc(ch, fisout);
    }
    fclose(fisin);
    fclose(fisout);
    return 0;
}
