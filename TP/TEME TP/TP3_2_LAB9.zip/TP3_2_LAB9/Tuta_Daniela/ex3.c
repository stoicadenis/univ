#include <stdio.h>


int main()
{
    FILE *fisier;
    int n=0;
    float k, s=0;
    if((fisier=fopen("e3.txt", "r"))==NULL) {
        printf("Eroare la deschidere fisier!\n");
        return -1;
    }
    while(!feof(fisier)) {
        fscanf(fisier, "%g", &k);
        s+=k;
        n++;
    }
    printf("Media numerelor reale din fisier este: %g\n", s/n);
    fclose(fisier);
    return 0;
}
