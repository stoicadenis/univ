#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LEN 100
#define CATE 10

int main(void)
{
    FILE *fisier;
    char nume_fisier[MAX_LEN];
    int i, c;
    printf("Nume fisier: ");
    fgets(nume_fisier, MAX_LEN, stdin);
    nume_fisier[strlen(nume_fisier)-1]=0;
    if((fisier=fopen(nume_fisier, "rt"))==NULL)
        printf("Eroare deschidere fisier!\n");
    for(i=0; i<CATE; i++) {
        c=fgetc(fisier);
        if(c==EOF) break;
        else putchar(c);
    }
    putchar("\n");
    fclose(fisier);
    return 0;
}
