#include <stdio.h>
#include <string.h>


int main()
{
    FILE *fisier;
    char nume[100];
    char ch[100];
    int i=0, k;
    printf("Nume fisier: ");
    fgets(nume, 100, stdin);
    if((fisier=fopen(nume, "w"))==NULL) {
       printf("Eroare deschidere fisier %s!\n", nume);
       return -1;
       }
    while((ch[i]=fgetc(nume))!=EOF) {
        if (ch[i]==ch[i + 1]) {
            k++;
            continue;
        }
        else {
            printf("%c%d", ch[i], k + 1);
            k = 0;
        }
    }
    fclose(fisier);
    return 0;
}
