#include <stdio.h>


int main()
{
    FILE *fisier;
    int n, i;
    float nr1, nr2;
    if((fisier=fopen("e2.txt", "r"))==NULL) {
        printf("Eroare la deschidere fisier!\n");
        return -1;
    }
    //fprintf(fisier, "n=");
    fscanf(fisier, "%d", &n);
    for(i=0; i<n; i++) {
        fscanf(fisier, "%g %g", &nr1, &nr2);
        printf(" %g/2 = %g\n", nr1+nr2, (nr1+nr2)/2);
    }
    fclose(fisier);
    return 0;
}
