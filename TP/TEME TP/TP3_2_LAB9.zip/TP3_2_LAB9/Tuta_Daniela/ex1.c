#include <stdio.h>

int main()
{
    FILE *f;
    int n, x, y;
    printf("n=");
    scanf("%d", &n);
    if((f=fopen("e1.txt", "w"))==NULL) {
        printf("Fisierul e1.txt nu a  putut fi deschis!");
        return -1;
    }
    for(x=0; x<=n; x++)
        for(y=0; y<=n; y++)
            if(x*y==n)
                fprintf(f, "%d*%d\n", x, y);
    fclose(f);
    return 0;
}
