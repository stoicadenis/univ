#include<stdio.h>

/*int main() {
	FILE* fis;
	int n = 0;
	float k, s = 0;
	if ((fis = fopen("e3.txt", "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul");
		return -1;
	}
	while (!feof(fis)) {
		fscanf(fis, "%g", &k);
		s += k;
		n++;
	}
	printf("media=%g", s / n);
	fclose(fis);

	return 0;
}*/