#include <stdio.h>
#include <stdlib.h>
#define NAME "p3.txt"

/*int main(void) {
	FILE* f;
	int c;
	f = fopen(NAME, "r");
	if (!f) {
		perror("Eroare la deschiderea fisierului");
		exit(EXIT_FAILURE);
	}
	// Citim un caracter din fisier. 
	c = fgetc(f);
	// Daca citirea a reusit 
	if (c != EOF) {
		// il afisam pe ecran. 
		putchar(c);
		// Punem caracterul inapoi in fisier. 
		ungetc(c, f);
		// Citim din nou un caracter din fisier. 
		c = fgetc(f);
		// Afisam caracterul citit pe ecran. *
		if (c != EOF)
			putchar(c);
	}
	fclose(f);

	return 0;
}*/