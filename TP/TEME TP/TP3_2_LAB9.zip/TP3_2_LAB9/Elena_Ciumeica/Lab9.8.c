#include<stdio.h>
#include<stdlib.h>

/*int main() {
	FILE* fin, * fout;
	char nume[100];
	char str[60];
	printf("Nume fisier de intrare: ");
	gets(nume);
	if ((fin = fopen(nume, "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul r");
		return -1;
	}
	if ((fout = fopen("p8.txt", "w")) == NULL) {
		printf("Nu s-a putut deschide fisierul w");
		fclose(fin);
		return -1;
	}
	while (fgets(str, 60, fin) != NULL) {
		fputs("\"", fout);
		if (str[strlen(str) - 1] == '\n') {
			str[strlen(str)] = '\0';
			str[strlen(str) - 1] = '"';
		}
		else {
			str[strlen(str)] = '"';
		}
		fputs(str, fout);
		fprintf(fout, "\n");
	}
	fclose(fout);
	fclose(fin);

	return 0;
}*/