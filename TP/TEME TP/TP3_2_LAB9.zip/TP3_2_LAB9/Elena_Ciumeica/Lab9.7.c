#include<stdio.h>
#include<ctype.h>

/*int main() {
	FILE* f;
	char nume[100];
	char c;
	char v[26] = { 0 };
	int i;
	printf("Nume fisier de intrare: ");
	gets(nume);
	if ((f = fopen(nume, "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul");
		return -1;
	}
	while ((c = fgetc(f)) != EOF) {
		if (isalpha(c)) {
			v[tolower(c) - 'a']++;
		}
	}
	for (i = 0; i < 26; i++) {
		printf("%c is met %d times\n", i + 'a', v[i]);
	}
	fclose(f);

	return 0;
}*/