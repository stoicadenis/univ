#include<stdio.h>
#include<math.h>
#define MAX 50

float dist(float x, float y) {
	return sqrt(x * x + y * y);
}

void sortare(float* x, float* y, int n) {
	int i, j, k;
	float t, aux;
	for (i = 0; i < n; i++) {
		t = dist(x[i], y[i]);
		for (j = i + 1; j < n; j++) {
			if (t > dist(x[j], y[j])) {
				t = dist(x[j], y[j]);
				aux = x[i];
				x[i] = x[j];
				x[j] = aux;
				aux = y[i];
				y[i] = y[j];
				y[j] = aux;
			}
		}
	}
}

int main() {
	FILE* f;
	float x[MAX], y[MAX];
	char nume[100];
	int n = 0, i;
	printf("Nume fisier de intrare: ");
	gets(nume);
	if ((f = fopen(nume, "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul r");
		return -1;
	}
	while (!feof(f)) {
		fscanf(f, "%g %g", &x[n], &y[n]);
		n++;
	}
	sortare(x, y, n);
	for (i = 0; i < n; i++) {
		printf("%d punct: [%g,%g]\n", i + 1, x[i], y[i]);
	}
	fclose(f);

	return 0;
}