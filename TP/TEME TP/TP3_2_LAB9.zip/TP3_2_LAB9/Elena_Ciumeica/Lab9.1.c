#include<stdio.h>

/*int main() {
	FILE* f;
	int n, x, y;
	printf("n: ");
	scanf("%d", &n);
	if ((f = fopen("p1.txt", "w")) == NULL) {
		printf("Nu s-a putut dechide fisierul");
		return -1;
	}
	for (x = 0; x < n; x++) {
		for (y = 0; y < n; y++) {
			if (x == y) {
				fprintf(f, "0");
			}
			else if (x > y) {
				fprintf(f, "+");
			} else { 
				fprintf(f, "-"); 
			}
		}
		fprintf(f, "\n");
	}
	fclose(f);

	return 0;
}*/