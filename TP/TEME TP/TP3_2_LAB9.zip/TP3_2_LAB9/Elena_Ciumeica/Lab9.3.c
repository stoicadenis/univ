#include<stdio.h>
#include<math.h>

/*float dist(float x, float y)
{
	return sqrt(x * x + y * y);
}

int main() {
	FILE* f;
	float min = 0;
	float x0, y0, x, y;
	x0 = x = y0 = y = 0;
	if ((f = fopen("p3.txt", "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul");
		return -1;
	}
	while (!feof(f)) {
		fscanf(f, "%g %g", &x, &y);
		if (min == 0 || (min != 0 && min > dist(x, y))) {
			min = dist(x, y);
			x0 = x;
			y0 = y;
		}
	}
	printf("cel mai apropiat punct=[%g,%g]", x0, y0);
	fclose(f);

	return 0;
}*/