#include<stdio.h>

/*int main() {
	FILE* fis;
	int n, i;
	float x, y;
	if ((fis = fopen("e2.txt", "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul");
		return -1;
	}
	fscanf(fis, "%d", &n);
	for (i = 0; i < n; i++) {
		fscanf(fis, "%g %g", &x, &y);
		printf("%g, %g => %g\n", x, y, (x + y) / 2);
	}
	fclose(fis);

	return 0;
}*/