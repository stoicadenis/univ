#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Lungimea maxima pentru numele fisierului. 
#define MAX_LEN 100
// Numarul de caractere pe care le vom citi din fisier. 
#define CATE 10

/*int main(void)
{
	char nume_fisier[MAX_LEN];
	FILE* f;
	int i, c;
	// Citim numele fisierului. 
	printf("Numele fisierului? ");
	fgets(nume_fisier, MAX_LEN, stdin);
	// Eliminam '\n' care a fost citit de fgets. 
	nume_fisier[strlen(nume_fisier) - 1] = 0;
	// Deschidem fisierul pentru citire, cu verificarea de
	//rigoare. 
	f = fopen(nume_fisier, "rt");
	if (!f) {
		perror("Eroare la deschiderea fisierului");
		exit(EXIT_FAILURE);
	}
	for (i = 0; i < CATE; i++) {
		// Citim un caracter din fisier. 
		c = fgetc(f);
		if (c == EOF) {
			// Daca a fost sfarsit de fisier sau eroare,
			//intrerupem citirea. 
			break;
		}
		else {
			// Afisam caracterul citit pe ecran. 
			putchar(c);
		}
	}
	// Afisam un '\n' pe ecran. 
	putchar('\n');
	// Inchidem fisierul. 
	fclose(f);

	return 0;
}*/