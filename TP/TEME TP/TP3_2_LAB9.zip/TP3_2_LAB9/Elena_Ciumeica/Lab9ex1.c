#include<stdio.h>

/*int main() {
	FILE* fis;
	int n, x, y;
	printf("n: ");
	scanf("%d", &n);
	if ((fis = fopen("e1.txt", "w")) == NULL) {
		printf("Nu s-a putut dechide fisierul");
		return -1;
	}
	for (x = 0; x <= n; x++) {
		for (y = 0; y <= n; y++) {
			if (x*y == n) {
				fprintf(fis, "%d*%d\n", x, y);
			}
		}
	}
	fclose(fis);
	return 0;
}*/