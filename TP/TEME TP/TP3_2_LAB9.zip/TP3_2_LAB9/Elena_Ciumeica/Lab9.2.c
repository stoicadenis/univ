#include <stdio.h>
#include <stdlib.h>

/*int main(void) {
	FILE* f;
	// Incercam sa deschidem fisierul text /stud/lab/mess. 
	//Este un fisier protejat la scriere, din care putem 
	//doar citi continutul. Totusi incercam sa il deschidem 
	//pentru scriere.
	f = fopen("/stud/lab/mess ", "w");
	// Verificam daca a reusit deschiderea. 
	if (!f) {// Daca deschiderea a esuat, folosim functia 
	//perror pentru a afisa ultimul mesaj de eroare generat,
	//precedat de un prefix ales de noi. 
		perror("Eroare la deschiderea fisierului");
		// Pe urma incheiem executia. 
		exit(EXIT_FAILURE);
	} // Daca deschiderea fisierului ar fi reusit, aici 
	//am fi inchis fisierul. In practica s-ar ajunge la 
	//acest cod doar daca am rula programul cu un utilizator 
	//privilegiat. NU faceti acest lucru, pentru ca se va
	//sterge continutul fisierului de useri si parole. 
	fclose(f);
	return 0;
}*/