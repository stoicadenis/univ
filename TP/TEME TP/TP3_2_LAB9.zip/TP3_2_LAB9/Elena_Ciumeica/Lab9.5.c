#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX_LEN 100

/*int main(void)
{
	char nume_fisier[MAX_LEN];
	FILE* f;
	int c;
	printf("Numele fisierului? ");
	fgets(nume_fisier, MAX_LEN, stdin);
	nume_fisier[strlen(nume_fisier) - 1] = 0;
	// Deschidem fisierul pentru scriere, cu verificarea de
	//rigoare. 
	f = fopen(nume_fisier, "w");
	if (!f) {
		perror("Eroare la deschiderea fisierului");
		exit(EXIT_FAILURE);
	}
	// Citim cate un caracter de la tastatura, pana la EOF
	//sau pana la spatiu. 
	while ((c = getchar()) != EOF && !isspace(c)) {
		// Scriem caracterul citit in fisier. 
		fputc(c, f);
	}
	fclose(f);

	return 0;
}*/