#include<stdio.h>

/*int main() {
	FILE* fin, * fout;
	float s;
	if ((fin = fopen("in.txt", "r")) == NULL) {
		printf("Nu s-a putut deschide fisierul in.txt");
		return -1;
	}
	if ((fout = fopen("indexate.txt", "w")) == NULL) {
		printf("nu s-a putut deschide fisierul indexate.txt");
		fclose(fin);
		return -1;
	}
	while (!feof(fin)) {
		fscanf(fin, "%g", &s);
		if (s < 1000) {
			s *= 1.15;
		}
		fprintf(fout, "%g\n", s);
	}
	fclose(fin);
	fclose(fout);

	return 0;
}*/