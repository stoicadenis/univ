#include <stdio.h>
#include <stdlib.h>
void afisare(int n)
{
    int i,j;
    FILE *f;
    if((f=fopen("fis.out","w"))==NULL)
        {
            printf("Fisierul nu poate fi deschis!");
            return -1;
        }
        else
        {
          for(i=0;i<n;i++)
            { for(j=0;j<n;j++)
                if(i>j)
                fprintf(f,"+ ");
                else
                    if(i==j)
                    fprintf(f,"0 ");
                    else
                        fprintf(f,"- ");
              fprintf(f,"\n");
            }
        }
    fclose(f);
}
int main()
{
    int n;
    printf("n="); scanf("%d",&n);
    afisare(n);
    return 0;
}
