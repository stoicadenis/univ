#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void afisare()
{
    int a,b,c1,c2,d,min=9999;
    FILE *f;
    if((f=fopen("fis.in","r"))==NULL)
        {
            printf("Fisierul nu poate fi deschis!");
            return -1;
        }
        else
        while(!feof(f))
        {
            fscanf(f,"%d %d",&a,&b);
            /*calculam distanta de la origine (0,0) la punctul de coordonate (a,b)
               distanta se calculeaza sqrt((a-0)*(a-0)+(b-0)*(b-0))
            */
            d=sqrt(a*a+b*b);
            //cautam distanta minina de la origine la punct
            if(min>d)
                {min=d;
                //retinem coordonatele punctului apropiat de origine
                c1=a;
                c2=b;
                }
        }
    printf("Punctul de coordonate (%d,%d) este mai apropiat de origine",c1,c2);
    fclose(f);
}
int main()
{
    afisare();
    return 0;
}
