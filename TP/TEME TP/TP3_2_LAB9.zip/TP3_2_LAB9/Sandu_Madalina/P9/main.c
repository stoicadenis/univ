#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct{
    float x,y;
}P;
int citire(P *p)
{
    FILE *f;
    int n=0;
    if((f=fopen("fis.in","r"))==NULL)
    {
        printf("Fisierul nu poate fi deschis!");
        return -1;
    }
    else
    {
        while(!feof(f))
        {
            fscanf(f,"%f %f",&p[n].x,&p[n].y);
            n++;
        }
        fclose(f);
    }
    return n;
}
float distanta(float x, float y)
{
	float d;
	d = sqrt(x*x + y*y);
	return d;
}
void sortare(P *p, int n)
{
    P aux;
    int i,k;
    do
    {
       k=1;
       for(i=1;i<=n;i++)
       if(distanta(p[i].x,p[i].y)<distanta(p[i-1].x,p[i-1].y))
       {
           aux=*(p+i-1);
           *(p+i-1)=*(p+i);
           *(p+i)=aux;
           k=0;
       }

    } while (!k);

    for(i=1;i<=n;i++)
    printf("%f %f\n",p[i].x,p[i].y);
}
int main()
{
	P p[50];
    int n,i;
    n=citire(p);
    sortare(p,n);
    return 0;
}
