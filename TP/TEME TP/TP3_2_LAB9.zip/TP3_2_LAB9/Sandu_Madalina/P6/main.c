#include <stdio.h>
#include <stdlib.h>
int citire(float x[])
{
	FILE *fin;
	int n = 0;
	if ((fin = fopen("fis.in", "r")) == NULL)
	{
		printf("Fisierul nu poate fi deschis!");
		return -1;
	}
	else
	{
		while (!feof(fin))
		{
			fscanf(fin, "%f", &x[n]);
			if (x[n] < 1000)
				x[n] = x[n] + (x[n] * 0.15);
			n++;
		}
		fclose(fin);
	}
	return n;
}
void afisare(float x[], int n)
{
	FILE *fout;
	int i;
	if ((fout = fopen("fis.out", "w")) == NULL)
	{
		printf("Fisierul nu se poate deschide!");
		return -1;
	}
	else
	{
		for (i = 0; i < n; i++)
			fprintf(fout, "%.2f\n", x[i]);
	}
	fclose(fout);
}
int main()
{
	float x[10];
	int n;
	n = citire(x);
	afisare(x, n);
	return 0;
}
