#include<stdio.h>
#include<stdlib.h>
#include<math.h>

typedef struct coordonate
{
    int x,y;
}P;

int citire(P *p)
{
    FILE *f;
    int i=0;
    if((f=fopen("3.txt","rt"))==NULL)
        printf("Fisierul nu poate fi deschis!");
        else
        while(!feof(f))
        {
            fscanf(f,"%d %d",&p[i].x,&p[i].y);
            printf("%d %d ",p[i].x,&p[i].y);
            printf("\n");
            i++;
        }
    fclose(f);
    return i;
}

void minim(int i,P *p)
{
    int j,l=0;
    float min;
    min=sqrt(pow(p[0].x,2)+pow(p[0].y,2));
    for(j=1;j<i;j++)
    {
        if((sqrt(pow(p[j].x,2)+pow(p[j].y,2)))<min)
        {
        min=sqrt(pow(p[j].x,2)+pow(p[j].y,2));
        l=j;
        }
    }
     printf("Punctul care este cel mai apropiat de originea axelor se gaseste pe linia %d",l);

}

int main()
{
    P p[20];
    int i;
    i=citire(p);
    minim(i,p);
    return 0;
}
