#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

    FILE *fisin;
    char nume[100];
    char ch;
    int lit[26];
    int i;

    printf("fisier de intrare: ");
    fgets(nume, 100, stdin);
    nume[strlen(nume)-1]='\0';


    if((fisin = fopen(nume, "r"))==NULL)
    {
        printf("nu s-a putut deschide fisierul %s\n", nume);
        return -1;
    }

    for(i=0; i<26; i++)  // initializare vector de aparitii
        lit[i]=0;


    while((ch = fgetc(fisin))!=EOF)

    {
        if(ch>='a' && ch<='z')
            lit[ch-97]++;
        else if(ch>='A' && ch<='Z')
            lit[ch-65]++;
    }

    for(i=0;i<26;i++)
        printf("%c - %d\n", i+97 ,lit[i]);

    fclose(fisin);



    return 0;
}
