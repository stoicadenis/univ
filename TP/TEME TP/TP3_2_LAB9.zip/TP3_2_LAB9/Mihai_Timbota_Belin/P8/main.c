#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fisin, *fisout;
    char ch;

    if((fisin = fopen("in.txt", "r"))==NULL)
    {
        printf("nu s-a putut deschide fisierul in.txt\n");
        return -1;
    }

    if((fisout = fopen("out.txt", "w"))==NULL)
    {
        printf("nu s-a putut deschide fisierul indexate.txt\n");
        return -1;
    }


    while((ch = fgetc(fisin))!=EOF)
    {
        fputc('"', fisout);

        while((ch = fgetc(fisin))!='\n')
            fputc(ch, fisout);

        fputc('"', fisout);
        fputc('\n', fisout);
    }

    fclose(fisin);
    fclose(fisout);
    return 0;
}
