#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct punct{
    float x, y, dist;
} punct;

int main()
{
      FILE *fisin;
      punct punct[50], aux;
      int i,j,n;


       if((fisin = fopen("in.txt", "r"))==NULL)
    {
        printf("nu s-a putut deschide fisierul in.txt\n");
        return -1;
    }

    i=0;
    while(fscanf(fisin, "%f", &punct[i].x)!=EOF )
    {
        fscanf(fisin, "%f", &punct[i].y);
        punct[i].dist = sqrt(punct[i].x*punct[i].x + punct[i].y*punct[i].y);
        i++;
    }
    n=i;

    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if(punct[i].dist>punct[j].dist)
    {
        aux = punct[i];
        punct[i] = punct[j];
        punct[j] = aux;
    }

for(i=0;i<n;i++)
    printf("punct %d:   %f\n",i, punct[i].dist);

    return 0;
}
