#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fisin, *fisout;
    float salariu;

    if((fisin = fopen("in.txt", "r"))==NULL)
    {
        printf("nu s-a putut deschide fisierul in.txt\n");
        return -1;
    }
    if((fisout = fopen("indexate.txt", "w"))==NULL)
    {
        printf("nu s-a putut deschide fisierul indexate.txt\n");
        return -1;
    }

    while(fscanf(fisin, "%f", &salariu)!=EOF)
    {
        if(salariu < 1000)
            fprintf(fisout,"%f\n", salariu*1.15);
        else
            fprintf(fisout,"%f\n", salariu);
    }

    fclose(fisin);
    fclose(fisout);


    return 0;
}
