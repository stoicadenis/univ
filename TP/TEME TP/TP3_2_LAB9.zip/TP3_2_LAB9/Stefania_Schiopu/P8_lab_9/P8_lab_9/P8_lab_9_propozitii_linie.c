/*Un fisier are cate o propozitie pe fiecare linie.Se cere sa se scrie intr-un fisier destinatie fiecare propozitie tot
pe cate o linie dar pusa intre ghilimele.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 200

int main()
{
	FILE *f; //declaram 2 fisiere, unul din care citim si unul destinatie in care vom scrie
	FILE *g;
	char f1[MAX];
	char f2[MAX];
	int i;

	if ((f = fopen("fisier_P8_lab_9.txt", "rt")) == NULL || (g = fopen("fisier_destinatie_P8_lab_9.txt", "wt")) == NULL)
		printf("\nEroare la deschiderea unuia dintre fisiere!\n");
	else
		while (!feof(f))
		{
			fgets(f1, MAX, f);
			strcpy(f2, f1);
			for (i = 0; f1[i] != '\0'; i++);
			f1[i - 1] = '"';
			for (i = 0; f1[i] != '\0'; i++)
				f2[i + 1] = f1[i];
			f2[0] = '"';
			fprintf(g, "%s\n", f2);
		}
	fclose(f);

	system("pause");
	return 0;
}