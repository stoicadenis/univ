/*Se cere un n pozitiv. Sa se scrie intr-un fisier un careu de n*n litere care contine la fiecare pozitie �+�
daca indexul liniei este mai mare decat al coloanei, �0� daca sunt egale si �-� in caz contrar.
Exemplu pentru n==3:
0 - -
+ 0 -
+ + 0*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
	FILE *f;
	int n, i, j;
	printf("Introduceti numarul de elemente: ");
	scanf("%d", &n);
	if ((f = fopen("fisier_P1.txt", "w")) == NULL)
	{
		printf("\nEroare deschidere fisier!\n");
		return -1;
	}
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
		{
			if (i < j)
				fprintf(f, "%c ", '-');
			else
				if (i == j)
					fprintf(f, "%c ", '0');
				else
					fprintf(f, "%c ", '+');
		}
		fprintf(f, "\n");
	}
	fclose(f);

	system("pause");
	return 0;
}