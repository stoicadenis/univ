/*In fisierul �in.txt� pe fiecare linie este cate un numar real ce semnifica salariul unei persoane. Se cere sa se citeasca
toate aceste numere si cele care sunt mai mici decat 1000 sa se indexeze cu 15%. Toate numerele rezultate (si cele ramase identice)
se vor scrie in fisierul �indexate.txt�, cate unul pe linie.  
Cu titlu informativ, pe langa functiile descrise mai sus mai exista functii pentru stergere fisier, returnare pozitie curenta,
repozitionare in fisier, citire/scriere blocuri de octeti,� */

#include<stdio.h>
#include<stdlib.h>

int Citire(float v[])
{
	FILE *f;
	int i = 0;
	if ((f = fopen("in.txt", "rt")) == NULL)
	{
		printf("\nEroare la deschidere fisier!\n");
		return -1;
	}
	else
	{
		while (!feof(f))
		{
			fscanf(f, "%f", &v[i]);
			if (v[i] < 1000)
				v[i] = v[i] + v[i] * 0.15;
			i++;
		}
		fclose(f);
	}
	return i;
}

void Scriere(float v[], int i)
{
	FILE *f;
	int n;
	if ((f = fopen("indexate.txt", "wt")) == NULL)
		printf("\nEroare la deschidere fisier pentru scriere!\n");
	else
	{
		for (n = 0; n < i; n++)
			fprintf(f, "%f\n", v[n]);
	}
	fclose(f);
}

int main()
{
	int n;
	float v[20];
	n = Citire(v);
	Scriere(v, n);

	system("pause");
	return 0;
}