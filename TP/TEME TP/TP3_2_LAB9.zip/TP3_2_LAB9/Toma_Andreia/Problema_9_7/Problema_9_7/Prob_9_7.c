#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main()
{
	FILE*fisin;
	char nume[100];
	int count[256] = { 0 };
	int k, c;

	printf("Fisier de intrare:");
	gets(nume);

	if ((fisin = fopen(nume, "r")) == NULL)
	{
		printf("Nu s-a putut deschide fiserul %s", nume);
		return -1;
	}

	while ((c = fgetc(fisin)))
	{
		if (c == EOF)
			break;
		count[c] += 1;
	}

	for (k = 0; k < 256; k++)
	{
		if (count[k] > 0)
		{
			printf("\nCaracterul %c apare de %d ori\n", k, count[k]);
		}
	}
	fclose(fisin);

	_getch();
	return 0;
}