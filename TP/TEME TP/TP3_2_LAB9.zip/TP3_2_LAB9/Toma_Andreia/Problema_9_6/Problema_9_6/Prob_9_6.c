#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main()
{
	FILE *fisin;
	FILE *fisout;
	float salariu;

	if ((fisin = fopen("in.txt", "r")) == NULL)
	{
		printf("Nu s-a putut deschide fisierul in.txt");
		return -1;
	}

	if ((fisout = fopen("indexare.txt", "w")) == NULL)
	{
		printf("Nu s-a putut deschide fisierul indexare.txt");
		fclose(fisin);
		return -1;
	}

	while (fscanf(fisin, "%f", &salariu) != EOF)
	{
		if (salariu < 1000)
			fprintf(fisout, "%f\n", salariu * 1.15);
		else
			fprintf(fisout, "%f\n", salariu);
	}

	fclose(fisin);
	fclose(fisout);

	_getch();
	return 0;
}