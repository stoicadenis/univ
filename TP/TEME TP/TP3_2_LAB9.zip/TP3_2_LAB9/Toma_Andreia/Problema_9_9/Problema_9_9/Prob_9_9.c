#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct punct 
{
	float a, b, distanta;
} punct;

int main()
{
	FILE *fisin;
	punct punct[50], aux;
	int i, j, n;


	if ((fisin = fopen("axa.txt", "r")) == NULL)
	{
		printf("Nu s-a putut deschide fisierul axa.txt\n");
		return -1;
	}

	i = 0;
	while (fscanf(fisin, "%f", &punct[i].a) != EOF)
	{
		fscanf(fisin, "%f", &punct[i].b);
		punct[i].distanta = sqrt(punct[i].a*punct[i].a + punct[i].b*punct[i].b);
		i++;
	}
	n = i;

	for (i = 0; i < n - 1; i++)
		for (j = i + 1; j < n; j++)
			if (punct[i].distanta > punct[j].distanta)
			{
				aux = punct[i];
				punct[i] = punct[j];
				punct[j] = aux;
			}


	for (i = 0; i < n; i++)
		printf("punct %d:   %f\n", i, punct[i].distanta);

	_getch();
	return 0;
}