#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main()
{
	FILE *fisin;
	FILE *fisout;
	char ch;
	if ((fisin = fopen("original.txt", "r")) == NULL)
	{
		printf("Nu s-a putut deschide fisierul original.txt");
		return -1;
	}

	if ((fisout = fopen("modificat.txt", "w")) == NULL)
	{
		printf("Nu s-a putut deschide fisierul modificat.txt");
		fclose(fisin);
		return -1;
	}

	while ((ch = fgetc(fisin)) != EOF)
	{
		fputc('""', fisout);
			fputc(ch, fisout);

	}

	fclose(fisin);
	fclose(fisout);

	_getch();
	return 0;
}