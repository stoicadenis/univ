#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main()
{
    char text[100],cuv[10][10],a[10][10],*p,separator[]=" .";
    int i,j,n=0,max;
    printf("Introduceti textul:\n");
    fgets(text,100,stdin);
    text[strlen(text)-1]=NULL;
     p=strtok(text,separator);
     max=strlen(p);
     while(p)
     {
            if(max<strlen(p))
                max=strlen(p);
         strcpy(cuv[n++],p);
         p=strtok(NULL,separator);
     }

        for(i=0;i<max;i++)
            for(j=0;j<max;j++)
                    if(i<n && j<strlen(cuv[i]))
                            a[i][j]=cuv[i][j];
                        else
                            a[i][j]='*';

     for(i=0;i<max;i++)
        {
            printf("\n");
            for(j=0;j<max;j++)
        printf("%c ",a[i][j]);
        }

    return 0;
}


