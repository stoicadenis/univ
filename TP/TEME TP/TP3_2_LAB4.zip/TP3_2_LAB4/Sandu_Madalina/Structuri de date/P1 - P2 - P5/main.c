#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct{
    char nume[50];
    float pret;
}Produs;

int main()
{
    Produs produse[100];
    int i,opt,n=0,aux,k,j;
    float pret;
    char nume[10];
    while(1)
    {
        printf("\t1.Introducere\n");
        printf("\t2.Afisare\n");
        printf("\t3.Cautare\n");
        printf("\t4.Stergere\n");
        printf("\t5.Ordonare dupa pret\n");
        printf("Introduceti opt:");
        scanf("%d",&opt);
        switch(opt)
        {
        case 1:
            getchar();
                    printf("Nume:");
                    fgets(produse[n].nume,50,stdin);
                    printf("Pret:");
                    scanf("%f",&produse[n].pret);

                     for(i=0;i<n;i++)
                if(strcmp(produse[n].nume,produse[i].nume)==0)
                {
                    printf("Produsul deja exista.Modificati pretul: ");
                    scanf("%f",&pret);
                    produse[i].pret=pret;
                    n--;
                }

            n++;
                break;
        case 2:
            for(i=0;i<n;i++)
                    printf("%s %f\n",produse[i].nume,produse[i].pret);
                break;
        case 3:
            getchar();
            printf("Introduceti numele:");
            fgets(nume,10,stdin);
            for(i=0;i<n;i++)
                if(strcmp(nume,produse[i].nume)==0)
                    printf("Pretul sau este %f \n",produse[i].pret);
                break;
        case 4:
            getchar();
            printf("Introduceti numele:");
            fgets(nume,10,stdin);
            for(i=0;i<n;i++)
            {
                if(strcmp(nume,produse[i].nume)==0)
                {
                    for(j=i+1;j<n;j++)
                        produse[j-1]=produse[j];
                    n--;
                    i--;
                }
            }
                break;
        case 5:
            do
            {
                k=1;
                for(i=1;i<n;i++)
                    if(produse[i-1].pret<produse[i].pret)
                    {
                        aux=produse[i-1].pret;
                        produse[i-1].pret=produse[i].pret;
                        produse[i].pret=aux;
                        k=0;
                    }
            }while(!k);
            for(i=0;i<n;i++)
                    printf("%s %f\n",produse[i].nume,produse[i].pret);

                    break;
        }
    }
    return 0;
}
