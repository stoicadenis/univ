#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<ctype.h>
typedef struct{
    char nume[10];
    int zi,luna,an;
}Elev;

int main()
{
    Elev e[10];
    int n=0,i,opt,k;
    char aux[10];
    while(1)
    {
        printf("\t1.Introducere elevi\n");
        printf("\t2.Afisare elevi\n");
        printf("\t3.Ordonare lexicografica\n");
        printf("\t0.Iesire\n");

        printf("Introduceti opt:");
        scanf("%d",&opt);
        switch(opt)
        {
        case 1:
            getchar();
            printf("Nume:");
            fgets(e[n].nume,10,stdin);
            printf("Data nasterii:\n");
            printf("zi-");scanf("%d",&e[n].zi);
            printf("luna-");scanf("%d",&e[n].luna);
            printf("an-");scanf("%d",&e[n].an);
            n++;
                break;
        case 2:
            for(i=0;i<n;i++)
            {
                printf("Nume:%s",e[i].nume);
                printf("Data nasterii:%d.%d.%d \n",e[i].zi,e[i].luna,e[i].an);
            }
                break;
        case 3:
            do
            {
                k=1;
                for(i=1;i<n;i++)
                    if(strcmp(e[i].nume,e[i-1].nume)<0)
                {
                    strcpy(aux,e[i].nume);
                    strcpy(e[i].nume,e[i-1].nume);
                    strcpy(e[i-1].nume,aux);
                    k=0;
                }
            }while(!k);

                for(i=0;i<n;i++)
            {
                printf("Nume:%s",e[i].nume);
                printf("Data nasterii:%d.%d.%d \n",e[i].zi,e[i].luna,e[i].an);
            }
                break;
        case 0: exit(0);
                break;
        default: printf("Opt gresita!");
                break;
        }
    }
    return 0;
}
