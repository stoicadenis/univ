#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int l,h;
}Drept;

void citire(Drept *d, int nr)
{
    int i;
    for(i=1;i<=nr;i++)
    {
        printf("Lungime: ");
        scanf("%d",&d[i].l);
        printf("Inaltime: ");
        scanf("%d",&d[i].h);
    }
}
void afisare(Drept *d, int nr)
{
    int i;
    for(i=1;i<=nr;i++)
    {
        printf("Date despre dreptunghiul %d -> ",i);
        printf("l=%d ",d[i].l);
        printf("h=%d ",d[i].h);
        printf("\n");
    }
}
void arie(Drept *d, int nr)
{
    int i,Amax,A;
    Amax=d[1].l*d[1].h;
    for(i=2;i<=nr;i++)
    {
        A=d[i].l*d[i].h;
        if(Amax<A)
            Amax=A;
    }

    for(i=1;i<=nr;i++)
    {
        A=d[i].l*d[i].h;
        if(Amax==A)
               printf("Dreptunghiul %d de latura %d si inaltime %d are aria maxima egala cu %d -> ",i,d[i].l,d[i].h,Amax);
    }
}
int main()
{
    Drept d[10];
    int nr;
    printf("nr=");
    scanf("%d",&nr);
    citire(d,nr);
    printf("\n");
    afisare(d,nr);
    printf("\n");
    arie(d,nr);

    return 0;
}
