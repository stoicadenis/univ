#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int ora;
    float temp;
}T;

void citire(T *t, int n)
{
    int i;
    for(i=1;i<=n;i++)
    {
        printf("Ora:"); scanf("%d",&t[i].ora);
        printf("Temperatura:"); scanf("%f",&t[i].temp);
    }
}
void afisare(T *t, int n)
{
    int i;
    for(i=1;i<=n;i++)
        printf("La ora %d s-au inregistrat %.1f  grade\n",t[i].ora,t[i].temp);
}
void temp(T *t, int n,int oi, int os)
{
    int i,c=0,s=0,media;
    for(i=1;i<=n;i++)
        if(t[i].ora>=oi && t[i].ora<=os)
           c=c+1;
    for(i=1;i<=n;i++)
        if(t[i].ora>=oi && t[i].ora<=os)
           s=s+t[i].temp;
    media=s/c;
    printf("Media temp intre ora %d si ora %d este %d \n",oi,os,media);
}
int main()
{
    T t[10];
    int n,oi,os;
    printf("n="); scanf("%d",&n);
    printf("Ora de inceput:"); scanf("%d",&oi);
    printf("Ora de sfarsit:"); scanf("%d",&os);
    citire(t,n);
    afisare(t,n);
    temp(t,n,oi,os);
    return 0;
}
