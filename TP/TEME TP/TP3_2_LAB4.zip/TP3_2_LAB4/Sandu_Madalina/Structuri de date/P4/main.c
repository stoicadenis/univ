#include <stdio.h>
#include <stdlib.h>
#include<math.h>

typedef struct{
    float a,b;
}Punct;

void citire(Punct *p, int v)
{
    int i;
    for(i=1;i<=v;i++)
    {
        printf("a="); scanf("%f",&p[i].a);
        printf("b="); scanf("%f",&p[i].b);
    }
}
void afisare(Punct *p, int v)
{
    int i;
    for(i=1;i<=v;i++)
        printf("Punctul %d e de coordonate (%.2f,%.2f)\n",i,p[i].a,p[i].b);
}

void distanta(Punct *p, int v)
{
    int d,i,j;
    for(i=1;i<=v;i++)
      for(j=i+1;j<=v;j++)
    {
        d=sqrt((p[i].a-p[i].b)*(p[i].a-p[i].b)+(p[j].a-p[j].b)*(p[i].a-p[j].b));
        printf("Distanta dintre punctul %d si %d este %d\n",i,j,d);
    }
}
int main()
{
    Punct p[10];
    int v;
    printf("v=");
    scanf("%d",&v);
    citire(p,v);
    afisare(p,v);
    distanta(p,v);
    return 0;
}
