#include <stdio.h>
#include <stdlib.h>
#include<string.h>
int lungime(char *s3,int c)
{
    c=strlen(s3);
    printf("Lungimea sirului este %d",c);
}
int main()
{
   char s3[50];
   int c;
   printf("Introduceti sirul s3= ");
   gets(s3);
   printf("Ati tastat:%s \n",s3);
   lungime(&s3,c);
   return 0;
}
