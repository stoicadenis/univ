#include <stdio.h>
#include <math.h>

typedef struct {
    float a,
        b;
} punct;



void adaugare(punct * v, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("\n a si b= ");
        scanf("%f %f",&v[i].a, &v[i].b);
    }
}

void afisare(punct * v, int n) {
    printf("\n%f %f",
        v[n].a,
         v[n].b
    );
}

int patrat (a, b) {
    return (a-b) * (a-b);
}

int distanta(punct * v, int n) {
    int min = patrat(v[0].a, v[1].a) + patrat(v[0].b, v[1].b),
        p = min,
        i;
    for(i = 1; i < n-1; i++) {
        p = patrat(v[i].a, v[i+1].a) + patrat(v[i].b, v[i+1].b);
        if ( p < min) {
            min = p;
        }
    }
    return min;
}

int main() {

    int n,
    i;

    punct v[10];
    printf("n= ");
    scanf("%d", & n);

    adaugare( &v[0], n);

    printf("Coordonatele sunt: ");
    for (i = 0; i < n; i++) {
        afisare(v, i);
    }

    printf("\nDistanta minima e: %2.2f", sqrt(distanta(v, n)) );

    return 0;
}
