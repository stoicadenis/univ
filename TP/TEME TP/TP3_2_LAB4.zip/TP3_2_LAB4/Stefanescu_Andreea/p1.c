#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main()
{
   char s2[50];
   int n;
   printf("Introduceti sirul s2= ");
   gets(s2);
   printf("Ati tastat:%s \n",s2);
   n=strlen(s2);
   printf("Lungimea sirului este %d",n);
   return 0;
}
