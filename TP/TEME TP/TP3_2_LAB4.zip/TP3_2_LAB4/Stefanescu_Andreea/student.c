
#include <stdio.h>
#include <string.h>

typedef struct {
    int day,
        month,
        year;
} time;

typedef struct {
    char name[20];
    time date;
} student;



void adaugare(student * st, int *n) {
    ( *n) ++;
    printf("\nDati valori\n");
    while (getchar() != '\n')
    ;
    printf("Nume: ");
    gets(st[*n].name);
    printf("Ziua: ");
    scanf("%d", & st[*n].date.day);
    printf("Luna: ");
    scanf("%d", & st[*n].date.month);
    printf("An: ");
    scanf("%d", & st[*n].date.year);
}
void afisare(student * st, int n) {
    printf("\n%s \t %d \t %d \t %d",
        st[n].name,
        st[n].date.day,
        st[n].date.month,
        st[n].date.year
    );
}
void sortare(student * st, int n) {
    int i, sorted;
    student clone;
    do {
        sorted = 1;
        for (i = 0; i < n; i++) {
            if ( strcmp(st[i].name, st[i + 1].name) > 0) {
                sorted = 0;
                clone = st[i];
                st[i] = st[i + 1];
                st[i + 1] = clone;
            }
        }
    } while (!sorted);

    for (i = 0; i <= n; i++) {
        afisare(st, i);
    }
}

int main(void) {

    int opt = !0,
        n = -1, i, j,
        _date;
    char _name[20];
    student st[10];


    while(1) {
        printf("\nOptiuni:");
        printf("\n0. iesire");
        printf("\n1. adaugare");
        printf("\n2. afisare");
        printf("\n3. sortare");
        printf("\nOpt dvs: ");
        scanf("%d", & opt);
        switch (opt) {
            case 0:
                return 0;
            case 1:
                adaugare( & st[0], & n);
                break;
            case 2:
                for (i = 0; i <= n; i++) {
                    afisare(st, i);
                }
                break;
            case 3:
                sortare(st, n);
                break;
            default:
                printf("\nOptiune invalida");
                break;
        }
    }
}
