#include <stdio.h>

#include <stdlib.h>

typedef struct {
    int value,
    power;
}
factors;

int prim(int nr) {
    int i;
    for (i = 2; i < nr / 2 + 1; i++) {
        if (nr % i == 0) {
            return 0;
        }
    }

    return 1;
}

int descompunere(factors * set, int nr, int * n) {
    int i,
    k = 0;
    float root;
    for (i = 2; i < abs(nr) / 2 + 1; i++) {
        if (nr % i == 0) {
            if (prim(i)) set[( * n) ++].value = i;
        }
    }

    return ( * n);
}

void afisare(factors * set, int n) {
    printf("\n%d",
        set[n].value
    );
}

int main() {

    int nr,
    n = 0,
        i;

    factors set[10];

    printf("Numar= ");
    scanf("%d", & nr);

    if (descompunere(set, nr, & n)) {
        printf("\nDivizorii primi sunt: \n");
        for (i = 0; i < n; i++) {
            afisare(set, i);
        }
    } else {
        printf("\n%d E un numar prim", nr);
    }

    return 0;

}
