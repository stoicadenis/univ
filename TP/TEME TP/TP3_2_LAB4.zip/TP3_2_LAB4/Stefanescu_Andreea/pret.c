#include <stdio.h>
#include <string.h>

typedef struct {
	char nume[50];
	float pret;
} produs;

int exista(char str[50], produs *v, int n) {
    int i;
    for(i = 0; i < n; i++) {
       if( strcmp(v[i].nume, str) == 0) {
           return i;
       }
    }
    return -1;
}

int main()
{
	produs v[100];
	int i,
        opt, n=0,
        index;
    char nume[50];

	while(1) {
        printf("\n1.Adaugare");
        printf("\n2.Afisare");
        printf("\n0.Iesire");
		printf("\nAdaugare optiune: ");
        scanf("%d", &opt);
		switch (opt){
            case 1:
                getchar();
                printf("nume: ");
                scanf("%s", nume);
                index = exista(nume, v, n);
                if(index >= 0) {
                    printf("Pret nou: "); scanf("%g", &v[index].pret);
                    n--;
                } else {
                    strcpy(v[n].nume, nume);
                    printf("pret: "); scanf("%g", &v[n].pret);
                }
                n++;
                break;
            case 2:
                for(i = 0; i < n; i++) {
                    printf("%s %g\n", v[i].nume,v[i].pret);
                }
                break;
            case 0: return 0;
            default:
                printf("\nOptiune invalida");
            break;
		}
	}
}
