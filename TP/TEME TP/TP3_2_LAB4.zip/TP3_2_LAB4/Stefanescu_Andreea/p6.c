#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
 char t[100],*p,separator[]=",.!;";
 printf("Introduceti sirul= ");
 fgets(t,100,stdin);
 p=strtok(t,separator);
 while(p)
 {


     printf("%s",p);
     p=strtok(NULL,separator);


 }

 getch();
    return 0;
}
