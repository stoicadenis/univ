#include <stdio.h>
#include <stdlib.h>
int comparare(char *s1, char *s2,int n)
{
   n=strcmp(s1,s2);
   if (n<0)
    printf("s1 este mai mic decat s2");
   else if (n>0)
    printf("s2 este mai mic decat s1");
   else if(n==0)
    printf("s1 este egal cu s2");
}
int main()
{
   char s1[50],s2[50];
   int n;
   printf("Introduceti sirul s1= ");
   gets(s1);
    printf("Introduceti sirul s2= ");
   gets(s2);
   printf("Ati tastat s1:%s si s2 :%s \n",s1,s2);
   comparare(&s1,&s2,n);
   return 0;
}
