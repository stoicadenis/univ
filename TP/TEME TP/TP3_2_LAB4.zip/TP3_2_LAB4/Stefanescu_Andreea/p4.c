#include <stdio.h>
#include <stdlib.h>

int main()
{
    char sir [80], subsir [80];
    char p;
    printf ("Introduceti sirul: ");
    gets (sir);
    printf ("Introduceti subsirul cautat: ");
    gets (subsir);
    p = strstr (sir, subsir);
    if (p != 0)
    printf ("%s contine %s \n", sir, subsir);
        else
    printf ("%s nu contine %s \n", sir, subsir);
    return 0;
}
