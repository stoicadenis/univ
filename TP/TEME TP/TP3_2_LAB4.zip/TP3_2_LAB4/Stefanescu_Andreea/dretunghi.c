#include <stdio.h>
#include <string.h>

typedef struct {
    int l,h;
} drept;


void quit() {
    printf("\n iesire");
}
void adaugare(drept * d, int *nr) {
    ( *nr) ++;
    printf("\nDati valori\n");
    while (getchar() != '\n')
    ;
    printf("Latime: ");
    scanf("%d", & d[*nr].l);
    printf("Inaltime: ");
    scanf("%d", & d[*nr].h);
}
void afisare(drept * d, int nr) {
    printf("\n %d: l = %d h = %d",
        nr+1,
        d[nr].l,
        d[nr].h
    );
}
int max (drept *d, int nr) {
    int i = 0,
        k = 0,
        aria = d[i].l * d[i].h,
        max = aria;
    for(i = 1; i <= nr; i++)
        {
        aria = d[i].l * d[i].h;
        if (aria > max) {
            k++;
            max = aria;
        }
    }

    return k;
}

int main( )
{

    int opt = !0,
        nr = -1,
        i, j;
    drept d[5];


    do {

        printf("\n Optiunile sunt:");
        printf("\n0. iesire");
        printf("\n1. adaugare");
        printf("\n2. afisare");
        printf("\n Optiune: ");
        scanf("%d", & opt);
        switch (opt) {
            case 0:
                quit();
                break;
            case 1:
                adaugare( & d[0], & nr);
                break;
            case 2:
                afisare(d, max(d, nr));
                break;
            default:
                printf("\nNu exista optiunea");
                break;
        }
    } while (opt);
}
