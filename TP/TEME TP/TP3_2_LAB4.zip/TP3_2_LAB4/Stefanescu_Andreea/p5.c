#include <stdio.h>
#include <stdlib.h>
void vocale(char *t1,char *t2)
{
    int i,j,max=0;
    char vocale[]="aeiouAEIOU";
    int v[10];
    for(i=0;i<10;i++)
        v[i]=0;
    for(i=0;i<strlen(t1);i++)
        for(j=0;j<10;j++)
        if(t1[i]==vocale[j])
        v[j]++;
   for(i=0;i<strlen(t2);i++)
            for(j=0;j<10;j++)
            if(t1[i]==vocale[j])
        v[j]++;
    for(i=0;i<10;i++)
   if(v[i]>max)
   max=v[i];
       for(i=0;i<10;i++)
 if(max==v[i])
    printf("Vocala %c se gaseste de %d ori \n ",vocale[i],v[i]);
}
int main()
{
 char t1[50],t2[50];
 printf("Introduceti primul sir= ");
 fgets(t1,50,stdin);
 printf("Introduceti al doilea sir=");
 fflush(stdin);
 gets(t2);
 vocale(t1,t2);
 getch();
    return 0;
}
