#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
typedef struct date
{
	int ora;
	float temp;
}d;
void citire(d *c, int *nr)
{
	(*nr)++;
	scanf("%d", &(c + *nr)->ora);
	scanf("%f", &(c + *nr)->temp);
}
void calcul(d *c, int *nr, int x, int y)
{
	int  k = 0,i;
	float p,s=0;
	for (i = 0; i < *nr; i++)
	{
		if ((c + i)->ora >= x && (c + i)->ora <= y) {
			k++; s = s + (c + i)->temp;
		}
	}
	p = s / k;
	printf("%f", p);
}
int main()
{
	d c[30];
	int nr = -1,x,y;
	citire(c, &nr);
	scanf("%d", &x);
	scanf("%d", &y);
	calcul(c, &nr, x,y);
	return 0;
}
