#include <stdio.h>
#include <string.h>

typedef struct {
    char nume[20];
    float pret;
} produse;


void iesire() {
    printf("\n iesire");
}
void adauga(produse * p, int *counter) {
    ( *counter) ++;
    printf("\nAdauga\n");
    while (getchar() != '\n')
    ;
    printf("Nume: ");
    gets(p[*counter].nume);
    printf("Pret: ");
    scanf("%f", & p[*counter].pret);
}
void afiseaza(produse * p, int counter) {
    printf("\n%10s \t %5.2f",
        p[counter].nume,
        p[counter].pret
    );
}
void cauta(produse * p, int counter, char _nume[20]) {
    int i, k = 0;
    for (i = 0; i <= (counter); i++) {
        if (strcmp(p[i].nume, _nume) == 0) {
            k++;
            afiseaza(p, i);
        }
    }
    if(!k) {
        printf("\nNu exista");
    }
}

void sorteaza(produse * p, int counter) {
    int i, sorted;
    produse clone;
    do {
        sorted = 1;
        for (i = 0; i < (counter); i++) {
            if (p[i].pret < p[i + 1].pret) {
                sorted = 0;
                clone =p[i];
                p[i] = p[i + 1];
                p[i + 1] = clone;
            }
        }
    } while (!sorted);

    for (i = 0; i <= counter; i++) {
        afiseaza(p, i);
    }
}

void stergere(produse *p, int *counter, char dorit[]) {
    int i, j;
    for (i = 0; i <= *counter; i++) {
        if (strcmp(p[i].nume, dorit) == 0) {
            (*counter)--;
            for (j = i++; j <= *counter; j++) {
                p[j] = p[j + 1];
            }
            i--;
        }
    }
}

int main(void) {

    int opt = !0,
        n = -1, i, j,
        _pret;
    char _nume[20];
    produse p[10];


    do {

        printf("\n0. Iesire");
        printf("\n1. Adaugare");
        printf("\n2. Afiseaza");
        printf("\n3. Cauta");
        printf("\n4. Sorteaza");
        printf("\n5. Stergere");
        printf("\n Optiunea este: ");
        scanf("%d", & opt);
        switch (opt) {
            case 0:
                iesire();
                break;
            case 1:
                adauga( & p[0], & n);
                break;
            case 2:
                for (i = 0; i <= n; i++) {
                    afiseaza(p, i);
                }
                break;
            case 3:
                printf("\n Dati numele : ");
                while (getchar() != '\n')
                ;
                gets(_nume);
                cauta(p, n, _nume);
                break;
            case 4:
                sorteaza(p, n);
                break;
            case 5:
                printf("\nDati numele pe crae doriti sa l stergeti: ");
                while (getchar() != '\n')
                ;
                gets(_nume);
                stergere(p, &n, _nume);
                break;
            default:
                printf("\nOptiune invalida");
                break;
        }
    } while (opt);
}
