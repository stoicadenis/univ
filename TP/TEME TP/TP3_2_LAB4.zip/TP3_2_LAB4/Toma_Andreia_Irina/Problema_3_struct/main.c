#include <stdio.h>
#include <string.h>

typedef struct {
    int inaltime,
        lungime;
} forma;


void iesire() {
    printf("\n iesire");
}
void adauga(forma * dreptunghi, int *counter) {
    ( *counter) ++;
    printf("\nDati valori\n");
    while (getchar() != '\n')
    ;
    printf("Inaltime: ");
    scanf("%d", & dreptunghi[*counter].inaltime);
    printf("Lungime: ");
    scanf("%d", & dreptunghi[*counter].lungime);
}
void afiseaza(forma * dreptunghi, int counter) {
    printf("\nDreptunghi %d: inaltime = %d lungime=%d",
        counter+1,
        dreptunghi[counter].inaltime,
        dreptunghi[counter].lungime
    );
}
int max (forma *dreptunghi, int counter) {
    int i = 0,
        k = 0,
        aria = dreptunghi[i].inaltime * dreptunghi[i].lungime,
        max = aria;
    for(i = 1; i <= counter; i++) {
        aria = dreptunghi[i].inaltime * dreptunghi[i].lungime;
        if (aria > max) {
            k++;
            max = aria;
        }
    }

    return k;
}

int main(void) {

    int opt = !0,
        n = -1,
        i, j;
    forma dreptunghi[10];


    do {

        printf("\n0. Iesire");
        printf("\n1. Adaugare");
        printf("\n2. Afisare");
        printf("\n Optiunea este:: ");
        scanf("%d", & opt);
        switch (opt) {
            case 0:
                iesire();
                break;
            case 1:
                adauga( & dreptunghi[0], & n);
                break;
            case 2:
                afiseaza(dreptunghi, max(dreptunghi, n));
                break;
            default:
                printf("\nOptiune invalida");
                break;
        }
    } while (opt);
}
