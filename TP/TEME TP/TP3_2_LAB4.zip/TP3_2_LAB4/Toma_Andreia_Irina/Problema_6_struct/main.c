#include <stdio.h>
#include <string.h>

typedef struct {
	int ora;
	float grade;
} meteo;


void adauga(meteo * zi, int *counter) {
    ( *counter) ++;
    printf("\nDati valori\n");
    printf("Timp: ");
    scanf("%d", & zi[*counter].ora);
    printf("Temperatura: ");
    scanf("%f", & zi[*counter].grade);
}
void afiseaza(meteo * zi, int counter) {
    printf("\n%2d:00 - %4.1f�C",
        zi[counter].ora,
        zi[counter].grade
    );
}

void selecteaza(meteo *zi, int counter) {
    int start, end,
        i;
    printf("\nDati timpul de inceput: ");
    scanf("%d", &start);
    printf("Dati timpul de terminare: ");
    scanf("%d",&end);
    for(i = 0; i <= counter; i++) {
        if (zi[i].ora >= start && zi[i].ora <= end) {
            afiseaza(zi, i);
        }
    }
}

int main() {
	meteo azi[10];
	int i,
        opt, n=-1,
        index;

	while(1) {
        printf("\n1.Adauga");
        printf("\n2.Afiseaza");
        printf("\n3.Selecteaza");
        printf("\n0.Iesire");
		printf("\nDati optiunea: ");
        scanf("%d", &opt);
		switch (opt){
            case 1:
                adauga(& azi[0], & n);
                break;
            case 2:
                for(i = 0; i <= n; i++) {
                    afiseaza(azi, i);
                }
                break;
            case 3:
                selecteaza(azi, n);
                break;
            case 0:
                return 0;
            default:
                printf("\nOptiune invalida");
            break;
		}
	}
}
