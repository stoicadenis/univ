#include <stdio.h>
#include <string.h>

typedef struct {
	char nume[50];
	float pret;
} produs;

int exista(char str[50], produs *stoc, int n) {
    int i;
    for(i = 0; i < n; i++) {
       if( strcmp(stoc[i].nume, str) == 0) {
           return i;
       }
    }
    return -1;
}

int main()
{
	produs stoc[100];
	int i,
        opt, n=0,
        index;
    char nume[50];

	while(1) {
        printf("\n1.Adauga");
        printf("\n2.Afiseaza");
        printf("\n0.Iesire");
		printf("\nDati optiunea: ");
        scanf("%d", &opt);
		switch (opt){
            case 1:
                getchar();
                printf("nume: ");
                scanf("%s", nume);
                index = exista(nume, stoc, n);
                if(index >= 0) {
                    printf("Pret nou: "); scanf("%g", &stoc[index].pret);
                    n--;
                } else {
                    strcpy(stoc[n].nume, nume);
                    printf("Pret: "); scanf("%g", &stoc[n].pret);
                }
                n++;
                break;
            case 2:
                for(i = 0; i < n; i++) {
                    printf("%s %g\n", stoc[i].nume, stoc[i].pret);
                }
                break;
            case 0: return 0;
            default:
                printf("\nOptiunea invalida");
            break;
		}
	}
}
