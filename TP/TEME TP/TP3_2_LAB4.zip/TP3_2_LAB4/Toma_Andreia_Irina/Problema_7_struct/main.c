#include <stdio.h>

#include <stdlib.h>

typedef struct {
    int valoare,
    putere;
}
factori;

int isPrime(int nr) {
    int i;
    for (i = 2; i < nr / 2 + 1; i++) {
        if (nr % i == 0) {
            return 0;
        }
    }

    return 1;
}

int descompune(factori * set, int nr, int * count) {
    int i,
    k = 0;
    float root;
    for (i = 2; i < abs(nr) / 2 + 1; i++) {
        if (nr % i == 0) {
            if (isPrime(i)) set[( * count) ++].valoare = i;
        }
    }

    return ( * count);
}

void afiseaza(factori * set, int counter) {
    printf("\n%d",
        set[counter].valoare
    );
}

int main() {

    int numar,
    n = 0,
        i;

    factori set[10];

    printf("Dati numarul: ");
    scanf("%d", & numar);

    if (descompune(set, numar, & n)) {
        printf("\nDivizorii primi sunt: \n");
        for (i = 0; i < n; i++) {
            afiseaza(set, i);
        }
    } else {
        printf("\n%d este un numar prim", numar);
    }

    return 0;

}
