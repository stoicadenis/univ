#include <stdio.h>
#include <string.h>

typedef struct {
    int zi,
        luna,
        an;
} timp;

typedef struct {
    char nume[20];
    timp data;
} student;



void adauga(student * stud, int *counter) {
    ( *counter) ++;
    printf("\nAdauga\n");
    while (getchar() != '\n')
    ;
    printf("Nume: ");
    gets(stud[*counter].nume);
    printf("Ziua: ");
    scanf("%d", & stud[*counter].data.zi);
    printf("Luna: ");
    scanf("%d", & stud[*counter].data.luna);
    printf("Anul: ");
    scanf("%d", & stud[*counter].data.an);
}
void afiseaza(student * stud, int counter) {
    printf("\n%s \t %d \t %d \t %d",
        stud[counter].nume,
        stud[counter].data.zi,
        stud[counter].data.luna,
        stud[counter].data.an
    );
}
void sorteaza(student * stud, int counter) {
    int i, sorted;
    student clone;
    do {
        sorted = 1;
        for (i = 0; i < (counter); i++) {
            if ( strcmp(stud[i].nume, stud[i + 1].nume) > 0) {
                sorted = 0;
                clone = stud[i];
                stud[i] = stud[i + 1];
                stud[i + 1] = clone;
            }
        }
    } while (!sorted);

    for (i = 0; i <= counter; i++) {
        afiseaza(stud, i);
    }
}

int main(void) {

    int option = !0,
        n = -1, i, j,
        _data;
    char _nume[20];
    student stud[10];


    while(1) {
        printf("\n0. Iesire");
        printf("\n1. Adauga");
        printf("\n2. Afiseaza");
        printf("\n3. Sorteaza");
        printf("\nDati optiunea: ");
        scanf("%d", & option);
        switch (option) {
            case 0:
                return 0;
            case 1:
                adauga( & stud[0], & n);
                break;
            case 2:
                for (i = 0; i <= n; i++) {
                    afiseaza(stud, i);
                }
                break;
            case 3:
                sorteaza(stud, n);
                break;
            default:
                printf("\nOptiune invalida");
                break;
        }
    }
}
