#include <stdio.h>
#include <stdlib.h>


typedef struct{

int l,h;

}Drept;

 void citire(Drept d[], int n)
 {
     int i;
     for( i=0;i<n;i++)
     {
         printf("\ndreptunghi %d\n\n",i);
         printf("latimea = ");
         scanf("%d",&d[i].l);
         printf("inaltimea = ");
         scanf("%d",&d[i].h);
     }
 }

 int maxim(Drept d[], int n)
 {
     int max=0,k=0,i;
     for(i=0;i<n;i++)
        if(d[i].l*d[i].h>max)
     {
         max=d[i].l*d[i].h;
         k=i;
     }
     return k;
 }


int main()
{
    int nr,max;
    Drept d[5];

    printf("nr = ");
    scanf("%d",&nr);

    citire(d, nr);
    max=maxim(d, nr);

    printf("latimea dreptunghiului cu arie maxima = %d\n",d[max].l);
    printf("inaltimea dreptunghiului cu arie maxima = %d\n",d[max].h);
    return 0;
}
