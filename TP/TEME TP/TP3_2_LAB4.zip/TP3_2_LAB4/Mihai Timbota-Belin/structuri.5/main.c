#include <stdio.h>
#include <string.h>

typedef struct {
	char nume[50];
	float pret;
}Produs;

int main()
{
	Produs produse[100];
	int i, opt,n=0, ok;
	float pret1;
	char nume1[50];

	while(1) {
        printf("1.Introducere\n");
        printf("2.Afisare\n");
        printf("0.Iesire\n");

		printf("operatia: ");
		scanf("%d", &opt);
		switch (opt){
            case 1:
                getchar();
                printf("nume: "); fgets(nume1,50, stdin);
                printf("pret: "); scanf("%g", &pret1);
                ok=0;
                for(i=0;i<n;i++)
                    if(strcmp(produse[i].nume, nume1)==0)
                    {
                        produse[i].pret=pret1;
                        ok=1;
                    }
                    if(ok==0)
                    {
                        strcpy(produse[n].nume, nume1);
                        produse[n].pret=pret1;
                        n++;
                    }

                break;
            case 2:
                for(i = 0; i < n; i++) {
                    printf("%s %g\n", produse[i].nume, produse[i].pret);
                }
                break;
            case 0: return 0;

            default: printf("operatie necunoscuta\n");
		}
	}
}
