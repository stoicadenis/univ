#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct
{

    int a,b;

} Punct;

void citire(Punct p[], int n)
{
    int i;
    for( i=0; i<n; i++)
    {
        printf("\nPunct %d\n\n",i);
        printf("a = ");
        scanf("%d",&p[i].a);
        printf("b = ");
        scanf("%d",&p[i].b);
    }
}

float maxim(Punct p[], int n)
{
    int i, j;
    float maxim=0, dist;
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
        {
            dist=sqrt((p[i].a+p[j].a)*(p[i].a+p[j].a)+(p[i].b+p[j].b)*(p[i].b+p[j].b));
            if(dist>maxim)
                maxim=dist;
        }
        return maxim;
}

int main()
{
    int nr;
    float max;
    Punct p[10];

    printf("nr = ");
    scanf("%d",&nr);

    citire(p,nr);
    max=maxim(p,nr);
    printf("maxim = %f",max);

    return 0;
}
