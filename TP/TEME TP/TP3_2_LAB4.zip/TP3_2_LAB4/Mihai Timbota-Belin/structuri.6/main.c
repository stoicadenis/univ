#include <stdio.h>
#include <stdlib.h>

typedef struct
{

    int ora;
    float val;

} temp;

void citire(temp t[], int n)
{
    int i;
    for( i=0; i<n; i++)
    {
        printf("\ntemperatura %d\n\n",i+1);
        printf("ora = ");
        scanf("%d",&t[i].ora);
        printf("valoare = ");
        scanf("%g",&t[i].val);
    }
}

float medie(temp t[], int n, int o1, int o2 )
{
    float m=0;
    int i,k=0;

    for(i=0;i<n;i++)
    {
        if(t[i].ora>=o1 && t[i].ora<=o2)
        {
            m+=t[i].val;
            k++;
        }
    }
    m=m/k;
    return m;
}

int main()
{
    temp t[10];
    float med;
    int nr,o1, o2;

    printf("nr = ");
    scanf("%d",&nr);

    citire(t,nr);

    printf("ora inceput = ");
    scanf("%d",&o1);
    printf("ora sfarsit= ");
    scanf("%d",&o2);

    med=medie(t, nr, o1, o2);
    printf("medie = %f",med);
    return 0;
}
