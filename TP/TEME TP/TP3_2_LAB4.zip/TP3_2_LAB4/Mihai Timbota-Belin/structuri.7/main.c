#include <stdio.h>

#include <stdlib.h>

typedef struct {
    int divizor,putere;
}
factori;

int nrprim(int nr) {
    int i;
    for (i = 2; i < nr / 2 + 1; i++) {
        if (nr % i == 0) {
            return 0;
        }
    }

    return 1;
}

int descompunere(factori *set, int nr, int * contor) {
    int d=2,p;

    while(nr>1)
    {
        p=0;
        while(nr%d==0)
        {
            p++;
            nr/=d;
        }
        if(p)
        {
            set[*contor].divizor=d;
            set[*contor].putere=p;
            *contor+=1;
        }
        d++;
        if(nr>1 && d * d > nr)
            d = nr;
    }



    return ( * contor);
}


void afisare(factori * set, int contor) {
    printf("\n %d ^ %d ",set[contor].divizor, set[contor].putere);

}

int main() {

    int nr, n = 0, i;

    factori set[10];

    printf("nr=: ");
    scanf("%d", & nr);

    if(nrprim(nr)==0)
    {
        descompunere(set, nr, & n);
        printf("\ndivizorii primi sunt: \n");
        for (i = 0; i < n; i++) {
           afisare(set, i);
        }
    }
     else {
        printf("\n%d e un numar prim", nr);
    }

    return 0;

}
