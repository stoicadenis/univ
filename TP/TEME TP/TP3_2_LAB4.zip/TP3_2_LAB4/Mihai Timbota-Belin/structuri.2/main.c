#include <stdio.h>

typedef struct
{
    char nume[50];
    float pret;
} Produs;

int main()
{
    Produs produse[100],aux;
    int i,j, opt,n=0,ok;
    char nume[50];

    while(1)
    {
        printf("1.Introducere\n");
        printf("2.Afisare\n");
        printf("3.Cautare\n");
        printf("4.Stergere\n");
        printf("5.Ordonare\n");
        printf("0.Iesire\n");

        printf("operatia: ");
        scanf("%d", &opt);
        switch (opt)
        {
        case 1:
            getchar();
            printf("nume: ");
            fgets(produse[n].nume,50, stdin);
            printf("pret: ");
            scanf("%g", &produse[n].pret);
            n++;
            break;
        case 2:
            for(i = 0; i < n; i++)
            {
                printf("%s %g\n", produse[i].nume, produse[i].pret);
            }
            break;

        case 3:
            printf("produsul cautat: ");
            getchar();
            fgets(nume, 50, stdin);

            ok=0;
            for(i=0; i<n; i++)
                if(strcmp(nume, produse[i].nume)==0)
                {
                    ok=1;
                    break;
                }
            if(ok==1)
                printf("\nprodusul exista\n");
            else
                printf("\nprodusul nu exista\n");
            break;

        case 4:
            printf("eliminare produs: ");
            getchar();
            fgets(nume, 50, stdin);
            for(i=0; i<n; i++)
                if(strcmp(nume, produse[i].nume)==0)
                {

                    for(j=i+1; j<n; j++)
                    {
                        produse[i]=produse[j];
                        n--;
                    }
                }

            break;

        case 5:
            for(i=0; i<n-1; i++)
                for(j=i; j<n; j++)
                    if(produse[i].pret>produse[j].pret)
                    {
                        aux=produse[i];
                        produse[i]=produse[j];
                        produse[j]=aux;
                        i--;
                    }
                     for(i = 0; i < n; i++)
            {
                printf("%s %g\n", produse[i].nume, produse[i].pret);
            }


            break;

        case 0:
            return 0;

        default:
            printf("operatie necunoscuta\n");
        }
    }
}
