#include <stdio.h>
#include <stdlib.h>
#include<string.h>

typedef struct
{
    char nume[20];
    char dn[20];
} Elev;

void citire(Elev e[], int n)
{
    int i;
    for( i=0; i<n; i++)
    {
        printf("\nelev %d\n\n",i+1);
        printf("nume = ");
        getchar();
        fgets(e[i].nume, 20, stdin);
        printf("data nasterii = ");

        fgets(e[i].dn, 20, stdin);
    }
}

void ordonare(Elev e[], int n)
{
    int i,j;
    Elev aux;
    for(i=0; i<n-1; i++)
        for(j=i; j<n; j++)
            if(strcmp(e[i].nume,e[j].nume)>0)
            {
                aux=e[i];
                e[i]=e[j];
                e[j]=aux;
                i--;
            }
    for(i = 0; i < n; i++)
    {
        printf("%s %s\n", e[i].nume, e[i].dn);
    }

}

int main()
{
    Elev e[50];
    int n;

    printf("n = ");
    scanf("%d", &n);

    citire(e, n);
    ordonare(e,n);


    return 0;
}
