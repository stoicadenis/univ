#include <stdio.h>
#include <stdlib.h>

void citire_a(int a[][10], int m, int n)
{
    int i, j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ", i, j);
            scanf("%d", &a[i][j]);
        }
    }
}

void citire_b(int b[][10], int n, int p)
{
    int i, j;
    for(i=0; i<n; i++)
    {
        for(j=0; j<p; j++)
        {
            printf("b[%d][%d]= ", i, j);
            scanf("%d", &b[i][j]);
        }
    }
}

void inmultire(int a[][10], int b[][10], int c[][10], int m, int p, int n)
{
    int i, j, k;
    for(i=0; i<m; i++)
    {
        for(j=0; j<p; j++)
        {
            c[i][j]=0;
            for(k=0; k<n; k++)
            c[i][j]=c[i][j]+a[i][k]*b[k][j];
            printf("%d ", c[i][j]);
        }
    }
}

int main()
{
    int m,n,p,a[10][10], b[10][10], c[10][10];
    printf("m= ");
    scanf("%d", &m);
    printf("n= ");
    scanf("%d", &n);
    printf("p= ");
    scanf("%d", &p);
    citire_a(a,m,n);
    citire_b(b,n,p);
    inmultire(a,b,c,m,p,n);
    return 0;
}
