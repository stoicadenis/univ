#include <stdio.h>
#include <stdlib.h>

void trans(float mat1[][30], float mat2[][20], int m, int n)
{
    int i, j;
    printf("mat2:\n");
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
        {
            mat2[i][j]=mat1[j][i];
            printf("%f\n", mat2[i][j]);
        }
    }
}

int main()
{
    int i, j, m, n;
    float mat1[20][30], mat2[30][20];
    printf("m= ");
    scanf("%d", &m);
    printf("n= ");
    scanf("%d", &n);
    printf("mat1:\n");
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ", i, j);
            scanf("%f", &mat1[i][j]);
        }
    }
    trans(mat1,mat2,m,n);
    return 0;
}
