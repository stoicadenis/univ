#include <stdio.h>
#include <stdlib.h>

void citire(int a[][50], int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%d",&a[i][j]);
        }
}

void afisare(int a[][50], int n)
{
    int i,j;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
            printf("%4d ",a[i][j]);
        printf("\n");
    }
}

void transpunere(int a[][50],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++)
        {
            int t;
            t=a[i][j];
            a[i][j]=a[j][i];
            a[j][i]=t;

        }
    }
}

int main()
{
   int a[50][50],n;

    printf("n=");
    scanf("%d",&n);

    citire(a,n);
    printf("\n afisare matrice initiala:\n");
    afisare(a,n);
    transpunere(a,n);
    printf("\n afisare matrice modificata:\n");
    afisare(a,n);

    return 0;
}
