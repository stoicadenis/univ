#include <stdio.h>
#include <stdlib.h>

void init(int a[], int n)
{
    int *p;
    for(p=&a[0]; p<&a[n]; p++)
        *p=0;
}

void afisare(int a[], int n)
{
    int *p;
    for(p=&a[0]; p<&a[n]; p++)
        printf("%d ",*p);
}


void citire(int a[][20], int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%d",&a[i][j]);
        }
}

void func(int a[][20], int v1[], int v2[],int n)
{
    int *r,*q,i,j;
    r=&v1[0];
    q=&v2[0];


    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
    {
        *(r+i)+=*(*(a+i)+j);
        *(q+j)+=*(*(a+i)+j);
    }
}

int main()
{

    int a[20][20],n;
    int v1[20],v2[20];

    printf("n=");
    scanf("%d",&n);

    init(v1,n);
    init(v2,n);


    citire(a,n);
    func(a,v1,v2,n);

    printf("\nafisare sume elemente de pe fiecare linie\n");
    afisare(v1,n);
    printf("\nafisare sume elemente de pe fiecare coloana\n");
    afisare(v2,n);




    return 0;
}
