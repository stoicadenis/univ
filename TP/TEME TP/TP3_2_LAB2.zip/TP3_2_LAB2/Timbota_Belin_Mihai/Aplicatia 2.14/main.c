#include <stdio.h>
#include <stdlib.h>

void init(int a[][4], int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            a[i][j]=0;
}

void citire(int a[][4],int n)
{
    int i,j;
    for(i=0; i<n; i++)
       {
           for(j=0; j<4; j++)
        {
            printf("vanzarile produsului %d pe trimestrul %d: ",i+1,j);
            scanf("%d",&a[i][j]);
        }
          printf("\n");
       }

}

void func(int a[][4],int n)
{
    int i,j,max=0,ok;

    printf("produsele care au inregistrat o crestere continua: ");
    for(i=0; i<n; i++)
    {
        ok=1;
        for(j=1; j<4; j++)
            if(a[i][j]<=a[i][j-1])
            {
                ok=0;
                break;
            }
        if(ok==1)
            printf("%d ",i);
        }




    }


int main()
{
    int a[10][5],n;

    printf("n=");
    scanf("%d",&n);

    init(a,n);
    citire(a,n);
    func(a,n);


    return 0;
}
