#include <stdio.h>
#include <stdlib.h>

void init(int a[][10], int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            a[i][j]=-1;
}

void citire(int pers[][10], int n)
{
int i,j;
for(i=0;i<n;i++)
{   j=0;
    printf("persoana %d are prietenii (introduceti -1 pentru incheiere) : \n",i);
     for(j=0; j<n-1; j++)
        {
            printf("prieten %d: ",j);
            scanf("%d",&pers[i][j]);
            if(pers[i][j]==-1)
                break;
        }

}
}

void afisare(int a[][10],int n)
{
    int i,j,k;
    for(i=0;i<n;i++)
    {k=0;
        for(j=0;j<n;j++)
        {
         if(a[i][j]!=-1)
                k++;
         else
            break;
        }
        printf("persoana %d are %d prieten(i)\n",i,k);
    }
}


int main()
{
    int pers[10][10],n;

    printf("n=");
    scanf("%d",&n);

    init(pers,n);
    citire(pers,n);
    afisare(pers,n);

    return 0;
}
