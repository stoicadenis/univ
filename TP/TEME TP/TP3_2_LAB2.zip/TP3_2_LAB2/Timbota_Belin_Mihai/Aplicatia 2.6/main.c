#include <stdio.h>
#include <stdlib.h>

void citire(float a[][26],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%f",&a[i][j]);
        }
}

void afisare(float a[][26],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            printf("%6.2f",a[i][j]);
        printf("\n");
    }
}

void adaugare(float a[][26],int *m,int n)
{
    int i,j;

    if(*m>1)
    {
        for(i=*m; i>=2; i--)
            for(j=0; j<n; j++)
                a[i+1][j]=a[i][j];


        for(j=0; j<n; j++)
            a[2][j]=0;

        *m=*m+1;
    }
}



int main()
{
    float a[26][26];
    int m,n;
    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);



    citire(a,m,n);
    printf("\n afisare matrice initiala:\n");
    afisare(a,m,n);
    adaugare(a,&m,n);
    printf("\n afisare matrice modificata:\n");
    afisare(a,m,n);

    return 0;
}
