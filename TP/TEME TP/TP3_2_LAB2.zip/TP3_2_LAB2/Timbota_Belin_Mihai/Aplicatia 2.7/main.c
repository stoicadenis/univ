#include <stdio.h>
#include <stdlib.h>

void init(int a[][10],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++)
            a[i][j]=0;
}

void citire(int a[][10],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%d",&a[i][j]);
        }
}


void afisare(int a[][10],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            printf("%d ",a[i][j]);
        printf("\n");
    }
}

void inmultire(int a[][10],int b[][10],int c[][10], int m, int n, int p)
{
    int i,j,k;

    for(i=0; i<m; i++)
        for(j=0; j<p; j++)
        {

            for(k=0; k<n; k++)
                c[i][j]+=a[i][k]*b[k][j];
        }



}

int main()
{
    int a[10][10], b[10][10], c[10][10], m, n, p;

    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);
    printf("p=");
    scanf("%d",&p);

    init(c,m,p);


    printf("\n citire matrice a:\n");
    citire(a,m,n);
    printf("\n citire matrice b:\n");
    citire(b,n,p);
    inmultire(a,b,c,m,n,p);
    printf("\n a*b = \n");
    afisare(c,m,p);

    return 0;
}
