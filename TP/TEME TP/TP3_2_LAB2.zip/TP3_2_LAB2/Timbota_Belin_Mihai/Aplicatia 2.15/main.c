#include <stdio.h>
#include <stdlib.h>

#define N 11


void afisare(int a[][N])
{
    int i,j,k;
    for(i=0; i<N; i++)
    {
        for(j=0; j<N; j++)
            printf("%2d ", a[i][j]);

        printf("\n");
    }

}
void init(int a[][N])
{
    int i,j;
    for(i=0; i<N; i++)
        for(j=0; j<N; j++)
            a[i][j]=0;
}

void reverse(int a[][N],int b[][N])
{
    int i,j;
    for(i=N-1;i>=0;i--)
        for(j=0;j<N;j++)
        b[j][N-i-1]=a[i][j];
}


int main()
{
    int a[N][N],b[N][N],x,y;

    int pivot=5;

    printf("x=");
    scanf("%d",&x);
    printf("y=");
    scanf("%d",&y);

    init(a);
    a[pivot][pivot]=88;
if(x>=0 && y>=0 || x<=0&& y<=0)
    a[pivot-x][pivot+y]=1;
    else
       a[pivot-y][pivot+x]=1;

    reverse(a,b);
    printf("afisare matrice initiala:\n");
    afisare(a);
    printf("afisare matrice rotita:\n");
    afisare(b);

    return 0;
}
