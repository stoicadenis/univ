#include <stdio.h>
#include <stdlib.h>

void afisare(int a[][10],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            printf("%d ",a[i][j]);
        printf("\n");
    }
}

void init(int a[][10],int m, int n)
{
      int i,j,k=0;

   for(i=0;i<m;i++)
    for(j=0;j<n;j++)
   {
       *(*(a+i)+j)=k;

       k++;
   }

}


int main()
{
   int a[20][10],m,n;

    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);

    init(a,m,n);


    afisare(a,m,n);

    getch();
    return 0;
}
