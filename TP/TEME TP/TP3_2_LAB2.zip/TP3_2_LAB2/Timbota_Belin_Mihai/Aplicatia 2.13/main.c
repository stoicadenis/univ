#include <stdio.h>
#include <stdlib.h>

void init(int a[][10], int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            a[i][j]=0;
}

void citire(int a[][10],int n)
{
    int i,j,ok=0;
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
        {
            printf("distanta dintre orasul %d si orasul %d este: ",i,j);
            scanf("%d",&a[i][j]);
            if(ok==0 && a[i][j]!=0)
                a[0][0]=a[i][j];

        }

}

void func(int a[][10],int n)
{
    int i,j,min;
    min=a[0][0];
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
            if(a[i][j]<min && a[i][j]!=0)
                min=a[i][j];

    if(min==0)
    {
        printf("nu exista un drum direct de la un oras la altul\n");
    }
    printf("cele mai apropiate orase in mod direct sunt:\n");
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
            if(a[i][j]==min)
                printf("(%d, %d)\n",i,j);
}

int main()
{
    int a[10][10],n;

    printf("n=");
    scanf("%d",&n);

    init(a,n);
    citire(a,n);
    func(a,n);

    return 0;
}
