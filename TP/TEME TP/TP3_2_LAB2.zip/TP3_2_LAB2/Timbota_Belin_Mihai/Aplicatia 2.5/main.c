#include <stdio.h>
#include <stdlib.h>

void afisare(float a[][30],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            printf("%6.2f",a[i][j]);
        printf("\n");
    }
}

void citire(float a[][30],int m, int n)
{
    int i,j;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%f",&a[i][j]);
        }
}

void transpusa(float a[][30],float b[][30],int m,int n)
{
    int i,j;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++)
            b[j][i]=a[i][j];
}



int main()
{
    float mat1[20][30], mat2[30][20];
    int m,n;

    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);

    citire(mat1 ,m,n);
    printf("\n afisare matrice initiala:\n");
    afisare(mat1,m,n);
    transpusa(mat1,mat2,m,n);
    printf("\n afisare matrice transpusa:\n");
    afisare(mat2,n,m);

    return 0;
}
