#include <stdio.h>
#include <stdlib.h>

void citire(int a[][30],int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            scanf("%d", &a[i][j]);
}

void test(int x[][30],int y[][30],int n,int m)
{
    int i,j,ok=0;

if(n<m)
 printf("Nu apare\n");
else
{


    for (i = 0; i < n-m+1; i++)
        for (j = 0; j < n-m+1; j++)
            if (x[i][j] == y[0][0])
                if (findMatch(x, y, i, j,m)==1)
                {

                    printf("(%d, %d) ",i,j);
                    ok=1;
                }


    if(ok==0)
        printf("Nu apare\n");

}
}

int findMatch(int x[][30], int y[][30],int i,int j,int m)
{

    int ok=1,k,n;

    for (k = i; k < i+m; k++)
    {
        for (n = j; n < j+m; n++)
        {
            if (y[k - i][n - j] != x[k][n])
            {
                return 0;

            }
        }


    }


    return 1;
}
int main()
{
    int a[30][30],b[30][30],m,n;


    scanf("%d",&n);
    scanf("%d",&m);

    citire(a,n);
    citire(b,m);


    test(a,b,n,m);


    return 0;
}
