#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void patrat(int n, int v[])
{
	int i, z, k = 0;
	for (i = 1; i <= 1000; i++)
	{
		z = sqrt(i);
		if (z*z == i)
		{
			v[k] = i;
			k++;
		}
	}
}

void afisare(int n, int a[25][25])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
}

int main()
{
	int n, a[25][25], i, j, k = 0, v[100];

	printf("Linii si coloane:");
	scanf("%d", &n);

	patrat(n, a);

	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			a[i][j] = v[k];
			k++;
		}
	}

	afisare(n, a);

	system("pause");
	return 0;
}