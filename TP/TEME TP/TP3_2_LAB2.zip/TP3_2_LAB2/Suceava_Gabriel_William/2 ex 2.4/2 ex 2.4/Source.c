#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

void citire(int n, int a[25][25])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("Elementele matricei:");
			scanf("%d", &a[i][j]);
		}
	}
}


void afisare(int n, int a[25][25])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d", a[i][j]);
		}
		printf("\n");
	}
}

int suma(int n, int a[25][25])
{
	int i, j, S = 0;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (i < j && a[i][j] % 2 == 0)
			{
				S = S + a[i][j];
			}
		}
	}
	printf("%d", S);
}

int main()
{
	int n, a[25][25];
	printf("Cate linii si coloane are matricea?");
	scanf("%d", &n);

	citire(n, a);
	afisare(n, a);

	suma(n, a);

	system("pause");
	return 0;
}