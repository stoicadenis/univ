#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void citirea(int m, int n, int a[10][10])
{
	int i, j;
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("Elemente matrice a: ");
			scanf("%d", &a[i][j]);
		}
	}
}

void citireb(int n, int p, int b[10][10])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < p; j++)
		{
			printf("Elemente matrice b: ");
			scanf("%d", &b[i][j]);
		}
	}
}

void afisarea(int m, int n, int a[10][10])
{
	int i, j;
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < n; j++)
		{
			printf("%d  ", a[i][j]);
		}
		printf("\n");
	}
}


void afisareb(int n, int p, int b[10][10])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < p; j++)
		{
			printf("%d  ", b[i][j]);
		}
		printf("\n");
	}
}

void inmultire(int m, int p, int c[10][10], int a[10][10], int b[10][10])
{
	int i, j;
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < p; j++)
		{
			c[i][j] = a[i][j] * b[i][j];
		}
	}
}

void afisarec(int m, int p, int c[10][10])
{
	int i, j;
	for (i = 0; i < m; i++)
	{
		for (j = 0; j < p; j++)
		{
			printf("%d  ", c[i][j]);
		}
		printf("\n");
	}
}

int main()
{
	int m, n, p, a[10][10], b[10][10], c[10][10];

	printf("m="); scanf("%d", &m);
	printf("n="); scanf("%d", &n);
	printf("p="); scanf("%d", &p);
	

	citirea(m, n, a);
	afisarea(m, n, a);

	citireb(n, p, b);
	afisareb(n, p, b);

	inmultire(m, p, c, a, b);
	printf("Matricea C: \n");
	afisarec(m, p, c);

	system("pause");
	return 0;
}