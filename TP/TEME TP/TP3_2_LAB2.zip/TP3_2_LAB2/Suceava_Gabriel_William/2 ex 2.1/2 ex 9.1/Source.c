#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

void citire(int n, int v[])
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("Elementele vectorului:");
		scanf("%d", &v[i]);
	}
}


void afisare(int n, int v[])
{
	int i;
	for (i = 0; i < n; i++)
	{
		printf("%d", v[i]);
	}
	printf("\n");
}

void sortare(int n, int v[])
{
	int aux = 0, i, j;

	for (i = 0; i < n - 1; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (v[i] > v[j] && v[j] % 2 == 1 && v[i] % 2 == 1)
			{
				aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
		}
	}
	afisare(n, v);
}

int main()
{
	int n, v[110];
	printf("Cate elemente are vectorul?");
	scanf("%d", &n);
	citire(n, v);
	afisare(n, v);
	sortare(n, v);

	system("pause");
	return 0;
}