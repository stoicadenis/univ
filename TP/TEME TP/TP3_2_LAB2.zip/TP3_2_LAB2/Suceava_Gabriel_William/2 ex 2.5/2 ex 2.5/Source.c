#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

void citire(int n, int m, int mat1[20][30])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			printf("Elementele matricei:");
			scanf("%d", &mat1[i][j]);
		}
	}
}


void afisare(int n, int m, int mat1[20][30])
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			printf("%d  ", mat1[i][j]);
		}
		printf("\n");
	}
}

void transpusa(int n, int m, int mat2[30][20], int mat1[20][30])
{
	int i, j;
	for (i = 0; i < n; ++i)
	{
		for (j = 0; j < m; ++j)
		{
			mat2[j][i] = mat1[i][j];
		}
	}
}


int main()
{
	int n, m, mat1[20][30], mat2[30][20];
	printf("Cate linii si coloane are matricea?");
	scanf("%d %d", &n, &m);
	citire(n, m, mat1);
	afisare(n, m, mat1);
	
	transpusa(n, m, mat2, mat1);
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j) 
		{
			printf("%d  ", mat2[i][j]);
		}
		printf("\n");
	}

	system("pause");
	return 0;
}