#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

#define n 5
#define m 7
#define l 2

void showOff(int vect[n][m])
{
	int i, j;
	for (i = 0; i < n + 1; i++)
	{
		for (j = 0; j < m; j++)
		{
			printf("%3d", vect[i][j]);
		}
		printf("\n");
	}
}

void zero(int(*vect)[n][m])
{
	int i, j;
	for (i = n - 1; i > 0; i--)
	{
		for (j = 0; j < m; j++)
		{
			if (i > l)
			{
				(*vect)[i + 1][j] = (*vect)[i][j];
			}
			if (i == l + 1)
			{
				(*vect)[i][j] = 0;
			}
		}
	}
}

int main()
{
	int v[n][m], i, j, s = 0;
	printf("Matricea initiala: \n");
	
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < m; j++)
		{
			v[i][j] = s;
			printf("%3d", v[i][j]);
		}
		printf("\n");
	}


	zero(&v);
	printf("Matricea rezultata: \n");
	showOff(v);

	system("pause");
	return 0;
}