#include <stdio.h>
void afisare (int mat1[20][30],int n,int m)
{
    int i, j;
    for(i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            printf("%d ", mat1[i][j]);
        }
        printf("\n");
    }
}

void trans (int (*mat2)[30][20], int mat1[20][30],int n,int m)
{

    int i, j;
    for(i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            (*mat2)[i][j] = mat1[j][i];
        }
    }
}
int main()
{

    int mat1[20][30],mat2[30][20],i, j,s=0,n,m;
    scanf("%d",&n);
    scanf("%d",&m);
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++, s++)
        {
            mat1[i][j] = s;
            printf("%d ", mat1[i][j]);
        }
        printf("\n");
    }

    trans(&mat2, mat1,n,m);
    afisare(mat1,n,m);

    return 0;
}
