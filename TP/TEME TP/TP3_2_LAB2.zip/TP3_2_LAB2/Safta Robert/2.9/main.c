#include<stdio.h>
void citire(int a[20][20],int m,int n)
{
	int i, j, x = 1;
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
		{
			*(*(a + i) + j) = x;
			x++;
		}
}

void afisare(int a[20][20],int m,int n)
{
	int i, j;
	for (i = 0; i <m; i++)
	{
		for (j = 0; j < n; j++)
			printf("%d ", *(*(a+i)+j));
		printf("\n");
	}
}

int main()
{
	int a[20][20],m,n;
	scanf("%d",&m);
		scanf("%d",&n);
	citire(a,m,n);
	afisare(a,m,n);
	return(0);

}
