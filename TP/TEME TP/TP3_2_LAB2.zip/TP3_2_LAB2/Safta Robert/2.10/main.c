#include <stdio.h>
#include <stdlib.h>
void citire(int a[50][50],int n)
{
    int i,j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            scanf("%d",&a[i][j]);

}
void ints(int a[50][50],int n)
{
    int i,j,k,m,aux;
    for (i=1; i<n-1; i++)

        for(j=i+1; j<n; j++)

            for (k=2; k<=n; k++)


            for(m=1; m<=i-1; m++)
                {
                    aux=a[i][j];
                    a[i][j]=a[k][m];
                    a[k][m]=aux;
                }

}
void afisare(int a[50][50],int n)
{
    int i,j;
    for(i=0; i<n; i++)
    {

        for(j=0; j<n; j++)
            printf("%d ",a[i][j]);
        printf("\n");
    }
}


int main()
{
    int a[50][50],n;
  scanf("%d",&n);
  citire(a,n);
  ints(a,n);
  afisare(a,n);
    return 0;
}
