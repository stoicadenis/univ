#include <stdio.h>


void afisare (int a[26][25],int n,int m)
{
    int i, j;
    for(i = 0; i < n+1; i++)
    {
        for (j = 0; j < m; j++)
        {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
}

void adaugare (int (*a)[26][25],int n,int m)
{

    int i, j;
    for(i = n+1; i > 0; i--)
    {
        for (j = 0; j < m; j++)
        {
            if(i > 2)
            {
                (*a)[i+1][j] = (*a)[i][j];
            }
            if(i == 2+1)
            {
                (*a)[i][j] = 0;
            }
        }
    }
}


int main()
{

    int a[26][25],i, j,s=0,n,m;
    scanf("%d",&n);
     scanf("%d",&m);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++, s++)
        {
            a[i][j] = s;
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }

    adaugare(&a,n,m);
    afisare(a,n,m);

    return 0;
}
