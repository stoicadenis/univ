#include <stdio.h>
#include <stdlib.h>

void citire(float a[20][25], int * x, int * y)
{
    int i, j;
    for (i = 0; i < * x; i++)
    {
        for (j = 0; j < * y; j++)
        {

            scanf("%f", & a[i][j]);
        }
    }
}
void afisare(float a[20][25], int * x, int * y)
{
    int i, j;
    printf("\n");

    for (i = 0; i < * x; i++)
    {
        for (j = 0; j < * y; j++)
        {
            printf("%f ", a[i][j]);
        }
        printf("\n");
    }

}
void mult(float ( * c)[20][25], float a[20][25], float b[20][25], int x, int y) {
    int i, j, k;
    for (i = 0; i < x; i++) {
        for (j = 0; j < x; j++) {
            (*c)[i][j] = 0;
            for (k = 0; k < y; k++) {
                (*c)[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}
int main()
{
   float a[20][25],b[20][25],c[20][25];
   int n = 0, m = 0,N = 1, M = 1;
    do {
        scanf("%d %d", & n, & m);
        scanf("%d %d", & N, & M);
        if (n != M || N != m) {
            printf("\nIncompatibil");
        }

    } while (n != M || N != m);
  citire(a, & n, & m);
  citire(b, & N, & M);
 if (n > N) N = n;

    mult( &c, a, b, n, N);

    afisare(c, & N, & N);


    return 0;
}
