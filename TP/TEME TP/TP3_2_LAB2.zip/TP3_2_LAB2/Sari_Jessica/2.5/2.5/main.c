#include <stdio.h>
#include <stdlib.h>
void citire(int n, int m, int a[n][m])
{
    printf("Give the elements of the matrix \n");
    for(int i=0; i<n;i++)
        for(int j=0;j<m;j++)
            scanf("%d", &a[i][j]);
}
void display(int n, int m, int a[n][m])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<m;j++)
            printf("%d", a[i][j]);
         printf("\n");
    }

}
void transpusa(float n, int m, float a[n][m], int b[m][n])
{
    for(int i=0; i<n;i++)
        for(int j=0;j<m;j++)
            b[i][j]=a[j][i];
}
int main()
{
    printf("Hello world!\n");
    int n;
    printf("n=");
    scanf("%d", &n);
    int m;
    printf("m=");
    scanf("%d", &m);
    float mat1[20][30];
    float mat2[30][20];
    citire(n, m, mat1);
    display(n, m, mat1);
    transpusa(n, m, mat1, mat2);
    display(m, n, mat2);
    return 0;
}
