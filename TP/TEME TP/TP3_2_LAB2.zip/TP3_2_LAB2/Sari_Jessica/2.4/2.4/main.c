#include <stdio.h>
#include <stdlib.h>
void citire(int n, int a[n][n])
{
    printf("Give the elements of the matrix \n");
    for(int i=0; i<n;i++)
        for(int j=0;j<n;j++)
            scanf("%d", &a[i][j]);
}
void display(int n, int a[n][n])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<n;j++)
            printf("%d", a[i][j]);
         printf("\n");
    }

}
void sum(int n, int a[n][n])
{
    int k=0;
    for(int i=0; i<n;i++)
        for(int j=0;j<n;j++)
        {
            if(i<j&&a[i][j]%2==0)
                k=k+a[i][j];
        }
        printf("Suma elem deasupra diagonalei principale este: %d", k);
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    if(n>25)
        printf("pls give a number n<=25\n");
    int m[n][n];
    citire(n, m);
    display(n, m);
    sum(n, m);
    return 0;
}
