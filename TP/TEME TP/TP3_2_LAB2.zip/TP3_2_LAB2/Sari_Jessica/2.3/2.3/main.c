#include <stdio.h>
#include <stdlib.h>
void display(int n, int m, int a[n][m])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<m;j++)
            printf("%d", a[i][j]);
         printf("\n");
    }

}
int maxim(int n, int m)
{
    if(n>m)
        return n;
    else
        return m;
}
void genesis(int n, int m, int a[n][m])
{
    for(int i=0; i<n;i++)
        for(int j=0;j<m;j++)
            a[i][j]=maxim(i, j);
}
int main()
{
    int n, m;
    printf("n=");
    scanf("%d", &n);
    printf("m=");
    scanf("%d", &m);
    if(n>=10)
        printf("pls give a number n<10\n");
    int a[n][m];
    genesis(n, m, a);
    display(n, m, a);
    return 0;
}
