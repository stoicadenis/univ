#include <stdio.h>
#include <stdlib.h>
void citire(int n, int m, int a[26][25])
{
    printf("Give the elements of the matrix \n");
    for(int i=0; i<n;i++)
        for(int j=0;j<m;j++)
            scanf("%d", &a[i][j]);
}
void inmultire(int n, int m, int p, int a[m][n], int b[n][p], int c[100][100])
{
    int i, j, k, sum=0;
    for (i = 0; i < m; i++) {
      for (j = 0; j < p; j++) {
        for (k = 0; k < n; k++) {
          sum = sum + a[i][k] * b[k][j];
        }
        c[i][j] = sum;
        sum = 0;
      }
    }
}
void display(int n, int m, int a[100][100])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<m;j++)
            printf(" %d", a[i][j]);
         printf("\n");
    }

}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int m;
    printf("m=");
    scanf("%d", &m);
    int p;
    printf("p=");
    scanf("%d", &p);
    int a[m][n], b[n][p], c[100][100];
    printf("elem a= ");
    citire(m, n, a);
    printf("elem b= ");
    citire(m, n, b);
    inmultire(n,m,p,a, b, c);
    printf("a*b=\n");
    display(m,n, c);
    return 0;
}
