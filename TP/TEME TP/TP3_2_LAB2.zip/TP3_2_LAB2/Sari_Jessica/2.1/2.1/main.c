#include <stdio.h>
#include <stdlib.h>
void input(int n, int v[n])
{
    int i;
    printf("elements of the vector are: ");
    for(i=0;i<n;i++)
        scanf("%d", &v[i]);
}
void display(int n, int v[n])
{
    int i;
    for(i=0;i<n;i++)
        printf("%d", v[i]);
}
void sortin(int n, int v[n])
{
    int i, j, aux, a[n], k=0,b=0;
    for(i=0;i<n;i++)
    {
        if(v[i]%2!=0)
        {
            a[k]=v[i];
            k++;

        }
    }
    j=0;
    for(i=0;i<k;i++)
    {
        for(j=0;j<k-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                aux=v[j];
                a[j]=a[j+1];
                a[j+1]=aux;
            }
        }
    }
    printf("\nElements of a are: ");
    display(k,a);
    for(i=0;i<n;i++)
    {
        if(v[i]%2!=0)
        {
            v[i]=a[b];
            b++;
        }
    }
}
int main()
{
    printf("Hello world!\n");
    int nb;
    printf("nb=");
    scanf("%d", &nb);
    int v[nb];
    if(nb>110)
        printf("wrong number\n");
    else
    {
        input(nb, v);
        printf("elementele vectorului sunt: \n");
        display(nb, v);
        sortin(nb, v);
        printf("\n");
        display(nb, v);
    }
    return 0;
}
