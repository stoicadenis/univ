#include <stdio.h>
#include <stdlib.h>
void citire(int n, int a[n][n])
{
    printf("Give the elements of the matrix \n");
    for(int i=0; i<n;i++)
        for(int j=0;j<n;j++)
            scanf("%d", &a[i][j]);
}
void display(int n, int a[n][n])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<n;j++)
            printf("%d", a[i][j]);
         printf("\n");
    }

}
void unitate(int n, int a[n][n])
{
    int k=0;
    for(int i=0; i<n;i++)
        for(int j=0;j<n;j++)
        {
            if(i==j&&a[i][j]!=1)
                k++;
            if(i!=j&&a[i][j]!=0)
                k++;
        }
    if(k!=0)
        printf("Matricea nu este matrice unitate\n");
    if(k==0)
        printf("Matricea este unitate\n");
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    if(n>10)
        printf("pls give a number n<=10\n");
    int m[n][n];
    printf("Hello world!\n");
    citire(n, m);
    display(n, m);
    unitate(n, m);
    return 0;
}
