#include <stdio.h>
#include <stdlib.h>
void citire(int n, int m, int a[26][25])
{
    printf("Give the elements of the matrix \n");
    for(int i=0; i<n;i++)
        for(int j=0;j<m;j++)
            scanf("%d", &a[i][j]);
}
void display(int n, int m, int a[26][25])
{
    printf("E;lements of the  matrix are: \n");
    for(int i=0; i<n;i++)
    {
         for(int j=0;j<m;j++)
            printf(" %d", a[i][j]);
         printf("\n");
    }

}
void addNewLine(int n, int m, int a[26][25])
{
        for(int i=n; i>=0;i--)
        for(int j=m-1;j>=0;j--)
        {
            if(i>=2&&i!=n)
            {
                a[i][j]=a[i-1][j];
            }
            if(i==2)
                a[i][j]=0;

        }
}
int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    int m;
    printf("m=");
    scanf("%d", &m);
    int a[26][25], b[26][25];
    citire(n, m, a);
    display(n, m, a);
    addNewLine(n, m, a);
    display(n, m, a);
    printf("Hello world!\n");
    return 0;
}
