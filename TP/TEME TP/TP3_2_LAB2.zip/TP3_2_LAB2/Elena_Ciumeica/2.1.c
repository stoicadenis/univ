#include<stdio.h>
#include<stdlib.h>
/*
void citire(int* v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		scanf("%d", &v[i]);
	}
}

int isImpar(int n) {
	if (n % 2 != 0) {
		return 1;
	}
	return 0;
}

void sortareCrescatorImpare(int* v, int n) {
	int i, j, aux;
	for (i = 0; i < n-1; i++) {
		for (j = i+1; j < n; j++) {
			if (isImpar(v[i]) && isImpar(v[j]) && (v[i] > v[j])) {
				aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
		}
	}
}

void afisare(int* v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		printf("%5d", v[i]);
	}
	printf("\n");
}

int main() {
	int n;
	int* v;
	printf("Size of array: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int));
	citire(v, n);
	afisare(v, n);
	sortareCrescatorImpare(v, n);
	afisare(v, n);

	return 0;
}*/