#include<stdio.h>
#include<stdlib.h>
/*
void citire(int** v, int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

int peDiagonala(int** v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		if (v[i][i] != 1)
			return 0;
	}
	return 1;
}

void isUnitate(int** v, int n) {
	int i, j, rest = 1;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			if (i != j && v[i][j] != 0) {
				rest = 0;
			}
		}
	}
	if (rest & peDiagonala(v, n)) {
		printf("E unitate\n");
	}
	else {
		printf("Nu e unitate\n");
	}
}

int main() {
	int n;
	int** v;
	printf("N: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	citire(v, n);
	afisare(v, n);
	isUnitate(v, n);

	return 0;
}*/