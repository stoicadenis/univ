#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*void afisare(char** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("\t%c", v[i][j]);
		}
		printf("\n");
	}
}

int isEqualHorizontallyRight(char** a, char* b, int i_pos, int j_pos) {
	int i, counter = 0, len = strlen(b);
	for (i = 0; i < len; i++) {
		if (a[i_pos][j_pos + i] == b[i]) {
			counter++;
		}
	}
	return counter == len;
}
int isEqualVerticallyDown(char** a, char* b, int i_pos, int j_pos) {
	int i, counter = 0, len = strlen(b);
	for (i = 0; i < len; i++) {
		if (a[i_pos + i][j_pos] == b[i]) {
			counter++;
		}
	}
	return counter == len;
}
int isEqualVerticallyUp(char** a, char* b, int i_pos, int j_pos) {
	int i, counter = 0, len = strlen(b);
	for (i = 0; i < len; i++) {
		if (a[i_pos - i][j_pos] == b[i]) {
			counter++;
		}
	}
	return counter == len;
}
int isEqualHorizontallyLeft(char** a, char* b, int i_pos, int j_pos) {
	int i, counter = 0, len = strlen(b);
	for (i = 0; i < len; i++) {
		if (a[i_pos][j_pos - i] == b[i]) {
			counter++;
		}
	}
	return counter == len;
}

void citire(char** v, int m, int n) {
	int i, j;

	for (i = 0; i < m; i++) {
		v[i] = (char*)calloc(n, sizeof(char));
		for (j = 0; j < n; j++) {
			getchar();
			scanf("%c", &v[i][j]);
		}
	}
}

void solutieDupaLinie(char** v, char* s, int n, int* aparut) {
	int i_pos = 0, j_pos, len = strlen(s);
	while (i_pos < n) {
		j_pos = 0;
		while ((j_pos + len) <= n) {
			if (isEqualHorizontallyRight(v, s, i_pos, j_pos)) {
				(*aparut)++;
				printf("De la linia %d coloana %d spre dreapta\n", i_pos, j_pos);
			}
			if (isEqualHorizontallyLeft(v, s, i_pos, j_pos + len - 1)) {
				(*aparut)++;
				printf("De la linia %d coloana %d spre stinga\n", i_pos, j_pos + len - 1);
			}
			j_pos++;
		}
		i_pos++;
	}
}

void solutieDupaColoana(char** v, char* s, int n, int* aparut) {
	int i_pos = 0, j_pos, len = strlen(s);
	while ((i_pos + len) <= n) {
		j_pos = 0;
		while (j_pos < n) {
			if (isEqualVerticallyDown(v, s, i_pos, j_pos)) {
				(*aparut)++;
				printf("De la linia %d coloana %d in jos\n", i_pos, j_pos);
			}
			if (isEqualVerticallyUp(v, s, i_pos + len - 1, j_pos)) {
				(*aparut)++;
				printf("De la linia %d coloana %d in sus\n", i_pos + len - 1, j_pos);
			}
			j_pos++;
		}
		i_pos++;
	}
}

void freeMemory(char** v, int n){
	int i;
	for(i = 0; i < n; i++) {
		free(v[i]);
	}
	free(v);
}

void cautareCuvint(char** v, char* s, int n) {
	int i_pos = 0, j_pos, len = strlen(s), aparut = 0;

	solutieDupaLinie(v, s, n, &aparut);
	solutieDupaColoana(v, s, n, &aparut);

	if (aparut == 0) {
		printf("Nu a aparut\n");
	}
}

int main() {
	int n;
	char** v, a[20];	

	printf("Insert matrix length: ");
	scanf("%d", &n);	
	v = (char**)calloc(n, sizeof(char*));
	printf("Please insert matrix\n");
	citire(v, n, n);
	afisare(v, n, n);	
	printf("Introduceti cuvintul cautat: ");
	scanf("%s", a);
	cautareCuvint(v, a, n);
	freeMemory(v, n);

	return 0;
*/