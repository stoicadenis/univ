#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i <= m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			if (i == m) {
				scanf("%d", &v[i][j]);
			}
			else {
				v[m][j] = NULL;
			}
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void adaugareLin(int** v, int m, int n) {
	int i, j;
	for (i = m; i >= 2; i--) {
		for (j = 0; j < n; j++) {
			if (i == 2) {
				v[i][j] = NULL;
			}
			else {
				v[i][j] = v[i - 1][j];
			}
		}
	}
}

int main() {
	int** v, n, m;
	printf("M & N: ");
	scanf("%d%d", &m, &n);
	v = malloc((m+1) * sizeof(int*));
	citire(v, m, n);
	afisare(v, m, n);
	adaugareLin(v, m, n);
	afisare(v, m+1, n);

	return 0;
}*/