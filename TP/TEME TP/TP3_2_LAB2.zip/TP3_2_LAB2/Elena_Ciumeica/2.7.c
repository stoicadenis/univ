#include<stdio.h>
#include<stdlib.h>

/*
void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void citirec(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void produs(int** a, int** b, int m, int n, int p, int** c) {
	int i, j, z, sum;
	for (i = 0; i < m; i++) {
		for (j = 0; j < p; j++) {
			sum = 0;
			for (z = 0; z < n; z++) {
				sum += a[i][z] * b[z][j];
			}
			c[i][j] = sum;
		}
	}
}

int main() {
	int m, n, p;
	int** a, ** b, ** c;
	printf("M, N, P: ");
	scanf("%d%d%d", &m, &n, &p);
	a = malloc(m * sizeof(int*));
	b = malloc(n * sizeof(int*));
	c = malloc(n * sizeof(int*));
	printf("citire a\n");
	citire(a, m, n);
	printf("citire b\n");
	citire(b, n, p);
	citirec(c, m, p);
	produs(a, b, m, n, p, c);
	afisare(c, m, p);

	return 0;
}
*/