#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		printf("Pentru produsul %d: \n", i);
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void crestereTrimestriala(int** v, int m, int n) {
	int i, j, crestere;
	for (i = 0; i < m; i++) {
		crestere = 1;
		for (j = 1; j < n; j++) {
			if (v[i][j] < v[i][j - 1]) {
				crestere = 0;
			}
		}
		if (crestere) {
			printf("Produsul %d a inregistrat o crestere continua\n", i);
		}
	}
}

int main() {
	int n, ** v;
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	citire(v, n, 4);
	crestereTrimestriala(v, n, 4);

	return 0;
}*/