#include<stdio.h>
#include<stdlib.h>
/*
void patratPerfect(int** v, int n) {
	int i, j, x = 1;
	for (i = 0; i < n; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			v[i][j] = x * x; // ((i*n)+(j+1))^2 
			x++;
		}
	}
}

void afisare(int** v, int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

int main() {
	int n;
	int** v;
	printf("N: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	patratPerfect(v, n);
	afisare(v, n);

	return 0;
}*/