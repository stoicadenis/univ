#include<stdio.h>
#include<stdlib.h>

/*void citirePrieteni(int**v,int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		v[i] = malloc(n * sizeof(int));
		v[i][i] = 0;
		for (j = i + 1; j < n; j++) {
			printf("\n%d este prieten cu %d? ", i, j);
			scanf("%d", &v[i][j]);
		}
	}
	for (i = 1; i < n; i++) {
		for (j = 0; j < i; j++) {
			v[i][j] = v[j][i];
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void afisarePrieteni(int** v, int n) {
	int i, j, sum;
	for (i = 0; i < n; i++) {
		sum = 0;
		for (j = 0; j < n; j++) {
			sum += v[i][j];
		}
		printf("%d are %d prieteni\n", i, sum);
	}
}

int main() {
	int n, **v;
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	citirePrieteni(v, n);
	afisare(v, n, n);
	afisarePrieteni(v, n);

	return 0;
}*/