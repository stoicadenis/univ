#include<stdio.h>
#include<stdlib.h>

/*void citireOrase(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		v[i][i] = 0;
		for (j = i + 1; j < n; j++) {
			printf("Intre %d si %d ce distanta e? ", i, j);
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void distantaMin(int** v, int n) {
	int i, j, min_i = 0, min_j = 0;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (v[min_i][min_j] == 0 || (v[i][j] > 0 && v[min_i][min_j] > v[i][j])) {
				min_i = i;
				min_j = j;
			}
		}
	}
	if (v[min_i][min_j] != 0) {
		printf("Distanta minima este intre orasele %d si %d\n", min_i, min_j);
	}
	else {
		printf("Nu e drum drect\n");
	}
}

int main() {
	int n, ** v;
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	citireOrase(v, n, n);
	distantaMin(v, n);

	return 0;
}*/