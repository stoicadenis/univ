#include<stdio.h>
#include<stdlib.h>
/*
void citire(int** v, int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int n) {
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

int isPar(int n) {
	if (n % 2 == 0) {
		return 1;
	}
	return 0;
}

int sumaDeasuprDiag(int** v, int n) {
	int i, j, suma = 0;
	for (i = 0; i < n; i++) {
		for (j = i+1; j < n; j++) {
			if (isPar(v[i][j])) {
				suma += v[i][j];
			}
		}
	}
	return suma;
}

int main() {
	int n;
	int** v;
	printf("Citire: ");
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	citire(v, n);
	afisare(v, n);
	printf("Suma: %d", sumaDeasuprDiag(v, n));

	return 0;
}*/