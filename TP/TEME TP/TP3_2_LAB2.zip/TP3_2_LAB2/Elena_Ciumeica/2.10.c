#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void interschimbare(int** v, int n) {
	int i, j, aux;
	for (i = 0; i < n; i++) {
		for (j = i + 1; j < n; j++) {
			if (i == j) {
				continue;
			}
			aux = v[i][j];
			v[i][j] = v[j][i];
			v[j][i] = aux;
		}
	}
}

int main() {
	int n, ** v;
	scanf("%d", &n);
	v = (int)malloc(n * sizeof(int*));
	citire(v, n, n);
	afisare(v, n, n);
	interschimbare(v, n, n);
	afisare(v, n, n);

	return 0;
}*/