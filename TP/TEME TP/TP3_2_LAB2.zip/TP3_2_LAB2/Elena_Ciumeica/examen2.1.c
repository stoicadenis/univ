#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

int isEqual(int** a, int** b, int n, int add_i, int add_j) {
	int i, j, is_equal = 1;
	for (i = 0; i < n; i++) {		
		for (j = 0; j < n; j++) {
			if (a[add_i + i][add_j + j] != b[i][j]) {
				is_equal = 0;
			}
		}
	}
	return is_equal;
}

void findTable(int** a, int** b, int m, int n) {
	int i, j, i_pos = 0, j_pos = 0, aparut = 0;
	while ((i_pos + n) <= m){
		j_pos = 0;
		while ((j_pos + n) <= m) {
			if (isEqual(a, b, n, i_pos, j_pos)) {
				aparut++;
				printf("(%d, %d) ", i_pos, j_pos);
			}
			j_pos++;
		}
		i_pos++;
	}
	if (aparut == 0) {
		printf("Nu a aparut\n");
	}
}

void freeMemory(int** v, int n){
	int i;
	for(i = 0; i < n; i++) {
		free(v[i]);
	}
	free(v);
}

int main() {
	int m, n, ** a, ** b;
	printf("insert M & N, N <= M \n");
	scanf("%d%d", &m, &n);
	a = (int**)malloc(m * sizeof(int));
	b = (int**)malloc(n * sizeof(int));
	citire(a, m, m);
	citire(b, n, n);
	afisare(a, m, m);
	afisare(b, n, n);
	findTable(a, b, m, n);
	freeMemory(a, m);
	freeMemory(b, n);

	return 0;
}*/