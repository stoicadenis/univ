#include<stdlib.h>
#include<stdio.h>
/*
void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void realocare(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			if (i < j) {
				v[i][j] = j;
			} else{
				v[i][j] = i;
			}
		}
	}
}

int main() {
	int m, n;
	int** v;
	printf("M si N: ");
	scanf("%d%d", &m, &n);
	v = malloc(m * sizeof(int*));
	realocare(v, m, n);
	afisare(v, m, n);

	return 0;
}*/