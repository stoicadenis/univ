#include<stdio.h>
#include<stdlib.h>

/*void generateTable(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			v[i][j] = i * n + j + 1;
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

int main() {
	int m, n, **v;
	scanf("%d", &m);
	scanf("%d", &n);
	v = malloc(m * sizeof(int*));
	generateTable(v, m, n);
	afisare(v, m, n);

	return 0;
}
*/