#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void transpusa(int** v, int m, int n, int** v2) {
	int i, j;
	for (i = 0; i < n; i++) {
		v2[i] = malloc(m * sizeof(int));
		for (j = 0; j < m; j++) {
			v2[i][j] = v[j][i];
		}
	}
}

int main() {
	int** v, v2, n, m;
	printf("M & N: ");
	scanf("%d%d", &m, &n);
	v = malloc(m * sizeof(int*));
	v2 = malloc(n * sizeof(int*));
	citire(v, m, n);
	afisare(v, m, n);
	transpusa(v, m, n, v2);
	afisare(v2, n, m);

	return 0;
}*/