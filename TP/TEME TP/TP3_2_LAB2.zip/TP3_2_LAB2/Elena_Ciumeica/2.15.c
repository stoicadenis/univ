#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define PI 3.14159265358979323846

/*void rotateVector(float* a, double b[][2], int n) {
	int i, j;
	float sum;
	for (i = 0; i < n; i++) {
		sum = 0;
		for (j = 0; j < n; j++) {
			sum += a[j] * b[j][i];
		}
		a[i] = sum;
	}
}

int main() {
	float v[2];
	double angle = 90 * PI / 180;
	double m[][2] = { 
		{ cos(angle), -sin(angle) },
		{ sin(angle), cos(angle) } 
	};
	scanf("%f%f", &v[0], &v[1]);
	printf("Original: [%7.2f %7.2f]\n", v[0], v[1]);
	rotateVector(v, m, 2);
	printf("Rotated: [%7.2f %7.2f]\n", v[0], v[1]);

	return 0;
}*/