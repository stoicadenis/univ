#include<stdio.h>
#include<stdlib.h>

/*void citire(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
}

void afisare(int** v, int m, int n) {
	int i, j;
	printf("\n");
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%5d", v[i][j]);
		}
		printf("\n");
	}
}

void sumaLinii(int** v, int n, int* a) {
	int i, j, sum;
	for (i = 0; i < n; i++) {
		sum = 0;
		for (j = 0; j < n; j++) {
			sum += v[i][j];
		}
		a[i] = sum;
	}
}

void sumaColoane(int** v, int n, int* a) {
	int i, j, sum;
	for (i = 0; i < n; i++) {
		sum = 0;
		for (j = 0; j < n; j++) {
			sum += v[j][i];
		}
		a[i] = sum;
	}
}
void afisareVector(int* v, int n) {
	int i;
	printf("\n");
	for (i = 0; i < n; i++) {
		printf("%5d", v[i]);
	}
}

int main() {
	int n, ** v, * lin, * col;
	scanf("%d", &n);
	v = malloc(n * sizeof(int*));
	lin = malloc(n * sizeof(int));
	col = malloc(n * sizeof(int));
	citire(v, n, n);
	afisare(v, n, n);
	sumaLinii(v, n, lin);
	sumaColoane(v, n, col);
	afisareVector(lin, n);
	afisareVector(col, n);

	return 0;
}*/