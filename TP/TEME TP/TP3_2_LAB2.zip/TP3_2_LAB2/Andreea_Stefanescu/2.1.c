#include <stdio.h>
#include <stdlib.h>

void citire(int v[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("v[%d]=",i);
        scanf("%d",&v[i]);
    }

}

void afisare(int v[],int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d",v[i]);
}

void sortare(int v[],int n)
{
    int i,j,k,aux;
  do
  {
    k=0;
 for(i=0;i<n;i++)
    for(j=0;j<n;j++)
 {

    if(v[j]!=0 && v[i]%2!=0)
    {
        if(v[i]<v[j])
 {
     aux=v[i];
     v[i]=v[j];
     v[j]=aux;
}
    }
k=1;
}
}
while(!k);
for(i=0;i<n;i++)
        printf("%d",v[i]);

}


int main()
{

int v[10],n;
printf("Dati n= ");
scanf("%d",&n);
citire(v,n);
afisare(v,n);
printf("\n");
sortare(v,n);
return 0;

}
