#include <stdio.h>
#include <stdlib.h>
void citire(int a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<m;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%d",&a[i][j]);
        }

    }
}

void afisare(int a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        printf("%d",a[i][j]);

        printf("\n");
    }
}

void maxim(int a[][10],int n,int m)
{
 int i,j;
     for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
            if(i>j)
            a[i][j]=i;
        else a[i][j]=j;

    }
}


int main()
{
    int a[10][10],n,m;
    printf("n=");
    scanf("%d",&n);
    printf("m= ");
    scanf("%d",&m);
    citire(a,n,m);
    afisare(a,n,m);
    maxim(a,n,m);
    printf("\n");
    afisare(a,n,m);


    return 0;
}
