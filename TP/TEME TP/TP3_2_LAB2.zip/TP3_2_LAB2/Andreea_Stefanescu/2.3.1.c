#include <stdio.h>
#include <stdlib.h>
void citire(float a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<m;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%f",&a[i][j]);
        }

    }
}

void afisare(float a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        printf("%5.2g",a[i][j]);

        printf("\n");
    }
}

void media(float a[][10],int n,int m)
{
 int i,j;
     for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
           a[i][j]=(i+j)/2.0;

    }
}


int main()
{
    float a[10][10];
    int n,m;
    printf("n=");
    scanf("%d",&n);
    printf("m= ");
    scanf("%d",&m);
    citire(a,n,m);
    afisare(a,n,m);
    media(a,n,m);
    printf("\n");
    afisare(a,n,m);


    return 0;
}
