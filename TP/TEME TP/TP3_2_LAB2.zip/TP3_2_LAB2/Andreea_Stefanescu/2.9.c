#include <stdio.h>
#include <stdlib.h>
void afisare(int (*a)[][20],int m,int n)
{
    int i,j;
    for(i=0;i<m;i++)

    {
        for(j=0;j<n;j++)


           printf("%d",(*a)[i][j]);
           printf("\n");


    }
}

 void parcurgere(int (*a)[][20],int m,int n)
 {
    int i,j,k=0,l=0,val=1;
     while (k < m && l < n)
     {
      for (int i = l; i < n; ++i)
            (*a)[k][i] = val++;

        k++;
     }

 }




int main()
{
    int n,m,a[20][20];
    printf("Dati m<=20 =");
    scanf("%d",&m);
    printf("Dati n<=10 =");
    scanf("%d",&n);
    parcurgere(&a,m,n);
    afisare(&a,m,n);
    return 0;
}
