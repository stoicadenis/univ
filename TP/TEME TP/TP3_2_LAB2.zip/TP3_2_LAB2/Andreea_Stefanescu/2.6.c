 #include <stdio.h>
#include <stdlib.h>
void citire(int a[][25],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<m;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%d",&a[i][j]);
        }

    }
}

void afisare(int a[][25],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        printf("%d",a[i][j]);

        printf("\n");
    }
}


int inserare(int a[][25],int n, int m)
{
int i,j;
for(i=n-1;i>=2;i--)
 for(j=0;j<m;j++)
 a[i+1][j]=a[i][j];
for(j=0;j<m;j++)
 a[2][j]=0;
 n++;
 for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        printf("%d",a[i][j]);

        printf("\n");
    }
}

int main()
{
 int n,m,a[26][25];
 printf("Dati n= ");
 scanf("%d",&n);
 printf("Dati m= ");
 scanf("%d",&m);
 citire(a,n,m);
 afisare(a,n,m);
 printf("\n");
 inserare(a,n,m);
 return 0;
}

