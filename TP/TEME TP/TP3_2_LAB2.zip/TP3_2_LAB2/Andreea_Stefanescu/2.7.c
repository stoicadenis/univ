#include <stdio.h>
#include <stdlib.h>
int citire(int m[][20],int n,int k)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for (j=0;j<k;j++)
        {
            printf("m[%d][%d]=",i,j);
            scanf("%d",&m[i][j]);
        }
    }
}
int afisare(int m[][20],int n,int k)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<k;j++)
            printf("%d",m[i][j]);
            printf("\n");
    }
}

int inmultire(int p[][20],int m1[][20],int m2[][20],int n,int m,int k )
{
    int i,j,x;
     for(i=0;i<n;i++)

        for(j=0;j<k;j++)
        {
            p[i][j] = 0;
            for(x=0;x<m;x++)
{

                p[i][j]+= m1[i][x]*m2[x][j];
}

        }


}
int main()
{
int m,n,p;
int a[20][20],b[20][20],c[20][20];
printf("Dati m= ");
scanf("%d",&m);
printf("Dati n=");
scanf("%d",&n);
printf("Dati p=");
scanf("%d",&p);

citire(a,m,n);
citire(b,n,p);
afisare(a,m,n);
printf("\n");
afisare(b,n,p);
printf("\n");
inmultire(c,a,b,m,n,p);
afisare(c,m,p);
return 0;
}
