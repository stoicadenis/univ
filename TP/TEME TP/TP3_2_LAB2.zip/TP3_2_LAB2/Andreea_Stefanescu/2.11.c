#include <stdio.h>
#include <stdlib.h>
void citire(int (*a)[][19],int n)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<n;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%d",&(*a)[i][j]);
        }

    }
}

void afisare(int (*a)[][19],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        printf("%d",(*a)[i][j]);

        printf("\n");
    }
}

void sumacoloana(int (*a)[][19],int (*v1)[19],int n,int *p)
{
    int i,j,S;
    for(j=0;j<n;j++)
   {
   S=0;
   for(i=0;i<n;i++)
    S=S+(*a)[i][j];
    (*v1)[j]=S;
   }
  *p=n;
printf("Vectorul suma de pe coloana este= ");
for(i=0;i<n;i++)
{
    printf("\n%d",(*v1)[i]);
}
 }

void sumalinie(int (*a)[][19],int (*v2)[19],int n,int *p)
{
 int i,j,S;
 for(i=0;i<n;i++)
   {
   S=0;
   for(j=0;j<n;j++)
   S=S+(*a)[i][j];
   (*v2)[i]=S;
   }
   *p=n;
printf("Vectorul suma de pe linie este=");
for(i=0;i<n;i++)
{
    printf("\n%d",(*v2)[i]);
}
 }


int main()
{
 int n,a[19][19],p,v1[19],v2[19];
 printf("Dati n= ");
 scanf("%d",&n);
 citire(&a,n);
 afisare(&a,n);
 sumacoloana(&a,&v1,n,&p);
 printf("\n");
 sumalinie(&a,&v2,n,&p);
 return 0;
}