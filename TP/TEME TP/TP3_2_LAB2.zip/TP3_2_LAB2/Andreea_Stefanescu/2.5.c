#include <stdio.h>
#include <stdlib.h>
#include<math.h>
void citire(int mat1[][30],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)

        {
         printf("mat1[%d][%d]= ",i,j) ;
           scanf("%d",&mat1[i][j]);
        }
}
}

void afisare(int mat1[][30],int n)
{
    int i,j;
      for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)

        printf("%d",mat1[i][j]);

        printf("\n");

    }
}

void transpusa(int mat1[][30],int mat2[][20],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {


        for(j=0;j<n;j++)
        mat2[j][i]=mat1[i][j];
    }

      for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)

        printf("%d",mat2[i][j]);

        printf("\n");

    }
}


int main()
{
 int n,mat1[20][30],mat2[30][20];
 printf("Dati n= ");
 scanf("%d",&n);
 citire(mat1,n);
 afisare(mat1,n);
 printf("\n");
 transpusa(mat1,mat2,n);
 return 0;
}
