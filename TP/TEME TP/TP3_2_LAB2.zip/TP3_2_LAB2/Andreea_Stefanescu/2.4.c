#include <stdio.h>
#include <stdlib.h>
void citire(int a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<m;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%d",&a[i][j]);
        }

    }
}

void afisare(int a[][10],int n,int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        printf("%d",a[i][j]);

        printf("\n");
    }
}

void suma(int a[][10],int n,int m)
{
    int i,j,s=0;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
            if(a[i][j]%2==0)
            s=s+a[i][j];

}
printf("Suma este=%d ",s);
}
int main()
{
    int a[10][10];
    int n,m;
    printf("n=");
    scanf("%d",&n);
    printf("m= ");
    scanf("%d",&m);
    citire(a,n,m);
    afisare(a,n,m);
    suma(a,n,m);
    return 0;
}
