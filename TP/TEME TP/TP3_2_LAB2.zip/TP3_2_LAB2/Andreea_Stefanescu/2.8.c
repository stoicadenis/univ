 #include <stdio.h>
#include <stdlib.h>
void citire(int a[][10],int n)
{
    int i,j,k=1;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if(k<=n*n)
        {
          a[i][j]=k*k;
          k=k+1;
        }
}

void afisare(int a[][10],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        printf("%d",a[i][j]);

        printf("\n");
    }
}

int main()
{
 int n,a[10][10];
 printf("Dati n= ");
 scanf("%d",&n);
 citire(a,n);
 afisare(a,n);
 return 0;
}

