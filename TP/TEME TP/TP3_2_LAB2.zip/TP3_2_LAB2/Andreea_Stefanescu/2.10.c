#include <stdio.h>
#include <stdlib.h>
void citire(int (*a)[][50],int n)
{
    int i,j;
    for(i=0;i<n;i++)

    {
        for(j=0;j<n;j++)
        {
           printf("a[%d][%d]= ",i,j) ;
           scanf("%d",&(*a)[i][j]);
        }

    }
}

void afisare(int (*a)[][50],int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        printf("%d",(*a)[i][j]);

        printf("\n");
    }
}


void interschimbare(int (*a)[][50],int n)
{
 int i,j,aux;
 {
 for ( i = 0; i < n; i++ )
 {
  for ( j = i + 1; j < n; j++ )
  {

    aux=(*a)[i][j];
    (*a)[i][j]=(*a)[j][i];
    (*a)[j][i]=aux;
  }
 }
  for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        printf("%d",(*a)[i][j]);

        printf("\n");
    }
}
}

int main()
{
 int n,a[50][50];
 printf("Dati n= ");
 scanf("%d",&n);
 citire(&a,n);
 afisare(&a,n);
 printf("\n");
 interschimbare(&a,n);
 return 0;
}
