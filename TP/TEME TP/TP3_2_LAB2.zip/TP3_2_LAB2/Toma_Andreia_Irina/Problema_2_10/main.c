#include <stdio.h>
#include <stdlib.h>

void citire(int a[][50], int n, int m)
{
    int i,j;
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
    {
        printf("a[%d][%d]=",i,j);
        scanf("%d", &a[i][j]);
    }
}

void afisare(int a[][50], int n, int m)
{
    int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++){
        printf("%d",a[i][j]);
    }
    printf("\n");
}
}

void transpusa(int a[][50], int b[][50],int m, int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++){
            b[j][i]=a[i][j];
        }
    }
    printf("Transpusa este:");
    for(i=0;i<m;i++)
    {

        for(j=0;j<n;j++)
        {

            printf("%d",b[i][j]);
        }
        printf("\n");
    }

}


int main()
{
int i,j,n,m,a[50][50], b[50][50];
 printf("Dati nr de linii:");
    scanf("%d", &n);
    printf("Dati nr de coloane:");
    scanf("%d", &m);
    citire(a,n,m);
    afisare(a,n,m);
    transpusa(a,b, m,n);
    return 0;
}
