#include <stdio.h>
#include <stdlib.h>

int citire(int a[][20], int n, int m)
{
    int i,j;
    for(i=0;i<n;i++)
    for(j=0;j<m;j++){
        printf("a[%d][%d]=",i,j);
        scanf("%d",&a[i][j]);
        a[i][j]=-1;
    }
}

int afisare(int a[][20], int n, int m){
int i,j;
for(i=0;i<n;i++)
{
    for(j=0;j<m;j++)
    {
        printf("%d",a[i][j]);
    }
    printf("\n");
}
}

int prieteni(int a[][20], int n){
    int i,j,count;
   for(i=0;i<n;i++)
   {
       count=0;
       for(j=0;j<n-1;j++)
       {

           if(a[i][j]=-1)
            {
            break;
           }
           else{
            count++;
           }
       }
   }
}

int main()
{
int i,j,n,m,a[20][20],p;
   printf("Dati nr de linii:");
    scanf("%d", &n);
    printf("Dati nr de coloane:");
    scanf("%d", &m);
citire(a,n,m);
afisare(a,n,m);
p=prieteni(a,n);
printf("%d",p);
return 0;
}
