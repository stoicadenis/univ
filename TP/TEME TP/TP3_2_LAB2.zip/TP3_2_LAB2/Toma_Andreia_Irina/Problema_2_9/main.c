#include <stdio.h>
#include <stdlib.h>

void citire(int a[][10], int n, int m)
{
    int i,j,k=0;
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
    {
       *(*(a+i)+j)=k;
       k++;
    }
}

void afisare(int a[][10], int n, int m)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%d",a[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int n,m,i,j,a[20][10];
    printf("Dati nr de linii:");
    scanf("%d", &n);
    printf("Dati nr de coloane:");
    scanf("%d", &m);
    citire(a,n,m);
    afisare(a,n,m);
    return 0;
}
