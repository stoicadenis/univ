#include <stdio.h>
#include <stdlib.h>

void citire(int n)
{
    int a[10][10], i, j;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++) {
            printf("a[%d][%d]=", i, j);
            scanf("%d", &a[i][j]);
        }
    printf("\n");
    for(i=0; i<n; i++) {
        for(j=0; j<n; j++) {
            printf("%4d", a[i][j]);
        }
    printf("\n");
    }
}
int unitate(int n)
{
    int i, j, a[10][10], auxp, auxs;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++) {
            if(i==j)
                auxp=a[i][j];
            if(i<j||i>j)
                auxs=a[i][j];
        }
    for(i=0; i<n; i++)
        for(j=0; j<n; j++) {
            if(auxp==1&&auxs==0)
                return 1;
            else
                return 0;
                }
}

int main()
{
    int n, u;
    printf("n=");
    scanf("%d", &n);
    citire(n);
    u=unitate(n);
    if(u==1)
        printf("\nMatrice unitate!\n\n");
    else
        printf("\nNu e matrice unitate!\n\n");
    system("pause");
    return 0;
}
