#include <stdio.h>

typedef float M[30][30];

void citire(M a, int *n)
{
    int i, j;
    for(i=0; i<*n; i++)
    for(j=0; j<*n; j++) {
        printf("a[%d][%d]=", i, j);
        scanf("%f", &a[i][j]);
    }
    printf("\n");
}
void afisare(M a, int n)
{
    int i, j;
    for(i=0; i<n; i++) {
    for(j=0; j<n; j++)
        printf("  %f\t", a[i][j]);
    printf("\n");
    }
    printf("\n");
}
void transpusa(M a, int n)
{
    int i, j;
    printf(" Transpusa matricei citite este: \n\n");
    for(i=0; i<n; i++) {
    for(j=0; j<n; j++)
        printf("  %f\t", a[j][i]);
    printf("\n");
    }
    printf("\n");
}

int main()
{
    M a, aux;
    int n;
    printf("n=");
    scanf("%d", &n);
    citire(a, &n);
    afisare(a, n);
    transpusa(a, n);
    system("pause");
    return 0;
}
