#include <stdio.h>

typedef int M[50][50];

void citire(M a, int *n)
{
    int i, j;
    for(i=0; i<*n; i++)
    for(j=0; j<*n; j++){
        printf("a[%d][%d]=", i, j);
        scanf("%d", &a[i][j]);
    }
    printf("\n");
}
void afisare(M a, int n)
{
    int i, j;
    for(i=0; i<n; i++){
        for(j=0; j<n; j++)
            printf("%5d", a[i][j]);
        printf("\n");
    }
    printf("\n");
}
void interschimb(M a, M b, int n)
{
    int i, j;
    printf(" Matricea nou - formata este: \n");
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
        b[i][j]=a[j][i];
    afisare(b, n);
}

int main()
{
    M a, b;
    int n;
    printf("n="); scanf("%d", &n);
    printf("\n");
    citire(a, &n);
    afisare(a, n);
    interschimb(a, b, n);
    system("pause");
    return 0;
}
