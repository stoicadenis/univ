#include <stdio.h>

typedef int M[10][10];

void citireA(M a, int *m, int *n)
{
    int i, j;
    printf("\n");
    for(i=0; i<*m; i++)
    for(j=0; j<*n; j++) {
        printf("a[%d][%d]=", i, j);
        scanf("%d", &a[i][j]);
    }
    printf("\n");
}
void afisareA(M a, int m, int n)
{
    int i, j;
    for(i=0; i<m; i++) {
    for(j=0; j<n; j++)
        printf("%4d", a[i][j]);
    printf("\n");
    }
    printf("\n");
}
void citireB(M b, int *n, int *p)
{
    int i, j;
    printf("\n");
    for(i=0; i<*n; i++)
    for(j=0; j<*p; j++) {
        printf("b[%d][%d]=", i, j);
        scanf("%d", &b[i][j]);
    }
    printf("\n");
}
void afisareB(M b, int n, int p)
{
    int i, j;
    for(i=0; i<n; i++) {
    for(j=0; j<p; j++)
        printf("%4d", b[i][j]);
    printf("\n");
    }
    printf("\n");
}
void inmultire(M a, M b, M aux, int m, int n, int p)
{
    int i, j, k;
    for(i=0; i<m; i++)
        for(j=0; j<n; j++){
           aux[i][j]=0;
        for(k=0; k<p; k++)
            aux[i][j]=aux[i][j]+a[i][k]*b[k][j];
        }
    for(i=0; i<m; i++) {
        for(j=0; j<p; j++)
            printf("%4d", aux[i][j]);
    printf("\n");
    }
}

int main()
{
    M a, b, aux;
    int m, n, p;
    printf("m="); scanf("%d", &m);
    printf("n="); scanf("%d", &n);
    printf("p="); scanf("%d", &p);
    citireA(a, &m, &n);
    afisareA(a, m, n);
    citireB(b, &n, &p);
    afisareA(b, n, p);
    inmultire(a, b, aux, m, n, p);
    system("pause");
    return 0;
}
