#include <stdio.h>
#include <stdlib.h>
typedef int M[25][25];
void citire(M a, int *n)
{
	int i, j;
	for (i = 0; i < *n; i++)
		for (j = 0; j < *n; j++) {
			printf("a[%d][%d]=", i, j);
			scanf("%d", &a[i][j]);
		}
}
void afisare(M a, int n)
{
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
			printf("%4d", a[i][j]);
		printf("\n");
	}
}
int suma(M a, int n)
{
	int i, j, s = 0;
	for (i = 0; i < n - 1; i++)
		for (j = i; j < n; j++)
			if (i < j)
				if (a[i][j] % 2 == 0)
					s += a[i][j];
	printf("\n%4d\n", s);
}

int main()
{
	M a;
	int n;
	printf("n=");
	scanf("%d", &n);
	citire(a, &n);
	afisare(a, n);
	suma(a, n);
	system("pause");
	return 0;
}
