#include <stdio.h>

void patratic(int n)
{
	int i, j, numar = 1;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			printf("%8d", numar*numar);
			numar++;
		}
		printf("\n");
	}
}


int main()
{
	int n;
	printf("n=");
	scanf("%d", &n);
	printf("\n");
	patratic(n);
	printf("\n");
	system("pause");
	return 0;
}
