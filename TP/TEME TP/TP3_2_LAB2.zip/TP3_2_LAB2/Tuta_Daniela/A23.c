#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, m, n, a[10][10];
    printf("m=");
    scanf("%d", &m);
    printf("n=");
    scanf("%d", &n);
    for(i=0; i<m; i++) {
        for(j=0; j<n; j++) {
            if(i>j)
                a[i][j]=i;
            else a[i][j]=j;
        printf("%4d", a[i][j]);
        }
        printf("\n");
    }
    system("pause");
    return 0;
}
