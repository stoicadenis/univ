#include <stdio.h>

 void matrice(int *m, int *n)
 {
     int i, j, *p, numar;
     numar=0;
     p=&numar;
     for(i=0; i<*m; i++) {
     for(j=0; j<*n; j++)
        printf("%8d", ++(*p));
    printf("\n");
     }
     printf("\n");
 }

 int main()
 {
     int m, n;
     printf("m="); scanf("%d", &m);
     printf("n="); scanf("%d", &n);
     printf("\n");
     matrice(&m, &n);
     system("pause");
     return 0;
 }
