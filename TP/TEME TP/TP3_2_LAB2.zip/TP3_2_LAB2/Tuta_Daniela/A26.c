#define L 26
#define C 25
#include <stdio.h>

typedef int matrice[L][C];

void citire(matrice a, int *n)
{
	int i, j;
	for (i = 0; i < *n; i++)
		for (j = 0; j < *n; j++) {
			printf("a[%d][%d]=", i, j);
			scanf("%d", &a[i][j]);
		}
	printf("\n");
}
void afisare(matrice a, int n)
{
	int i, j;
	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++)
			printf("  %d\t", a[i][j]);
		printf("\n");
	}
	printf("\n\n");
}
void afisare0(matrice a, int n)
{
	int i, j;
	for (i = n; i >= 3; i--)
		for (j = 0; j < n; j++) {
			a[i][j] = a[i - 1][j];
			a[3][j] = 0;
	}
	printf("\n  Matricea nou - formata este:\n\n");
	for (i = 0; i <= n; i++) {
		for (j = 0; j < n; j++)
			printf("  %d\t", a[i][j]);
		printf("\n");
	}
	printf("\n");
}

int main()
{
	matrice a;
	int n;
	printf("n=");
	scanf("%d", &n);
	citire(a, &n);
	afisare(a, n);
	afisare0(a, n);
	system("pause");
	return 0;
}
