#include <stdio.h>

typedef int M[20][20];

void citire(M m, int *n)
{
    int i, j;
    for(i=0; i<*n; i++)
    for(j=0; j<*n; j++){
        printf("m[%d][%d]=", i, j);
        scanf("%d", &m[i][j]);
    }
    printf("\n");
}
void afisare(M m, int n)
{
    int i, j;
    for(i=0; i<n; i++) {
    for(j=0; j<n; j++)
        printf("%5d", m[i][j]);
    printf("\n");
    }
    printf("\n");
}
void sumaL(M m, int n, int *v[20])
{
    int i, j, s;
    for(i=0; i<n; i++) {
        s=0;
        for(j=0; j<n; j++)
            s+=m[i][j];
    *v=s;
    printf("Suma elementelor de pe linia %d este %d.\n", i+1, *v);
    }
    printf("\n");
}
void sumaC(M m, int n, int *v[20])
{
    int i, j, s;
    for(j=0; j<n; j++) {
        s=0;
        for(i=0; i<n; i++)
            s+=m[i][j];
    *v=s;
    printf("Suma elementelor de pe coloana %d este %d.\n", j+1, *v);
    }
    printf("\n");
}

int main()
{
    M m;
    int n, v[20];
    printf("n="); scanf("%d", &n);
    citire(m, &n);
    afisare(m, n);
    sumaL(m, n, &v);
    sumaC(m, n, &v);
    system("pause");
    return 0;
}
