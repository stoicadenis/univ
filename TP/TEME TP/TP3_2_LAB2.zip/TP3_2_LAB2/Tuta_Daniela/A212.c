#include <stdio.h>

typedef struct persoane
{
    char nume[20];
} P;

void adaugare(P *pers, int *n)
{
    int i;
    (*n)++;
    getchar();
    for(i=0; i<(*n-1); i++) {
        printf("Nume si prenume: ");
        gets((pers+i)->nume);
    }
    printf("\n");
}
void afisare(P *pers, int n)
{
    int i;
    for(i=0; i<(n-1); i++) {
        printf("%4d. ", i);
        puts((pers+i)->nume);
    }
    printf("\n");
}
void prieteni(P *pers, int *n)
{
    int i, k;
    P aux[20];
    printf("Introduceti 0 cand doriti sa se termine citirea prietenilor!\n");
    for(i=0; i<(*n-1); i++) {
        printf("\nPrietenii lui %s: \n", (pers+i)->nume);
        strcpy(aux, (pers+i)->nume);
        k=-1;
        do {
        gets((pers+i)->nume);
        k++;
        } while(strcmp((pers+i)->nume, "A")>0);
        printf("%s are %d prieteni.\n", aux, k);
    }
}

int main()
{
    P pers[10];
    int n;
    printf("n="); scanf("%d", &n);
    adaugare(pers, &n);
    afisare(pers, n);
    prieteni(pers, &n);
    system("pause");
    return 0;
}
