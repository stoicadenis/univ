#include <stdio.h>

typedef struct oras
{
    char nume[30];
    int d;
} N;

void citire(N *oras, int *n)
{
    int i;
    (*n)++;
    getchar();
    for(i=0; i<(*n-1); i++) {
        printf("Nume oras: ");
        gets((oras+i)->nume);
    }
    printf("\n");
}
void afisare(N *oras, int n)
{
    int i;
    for(i=0; i<n-1; i++) {
        printf("%4d. ", i);
        puts((oras+i)->nume);
    }
    printf("\n");
}
void distanta(N *oras, int *n)
{
    int i;
    for(i=0; i<(*n-2); i++) {
       printf("Distanta dintre %s si %s este de ", (oras+i)->nume, (oras+i+1)->nume);
       scanf("%d", &((oras+i+1)->d));
       if((oras+i)->d==0)
        printf("Nu exista drum direct!\n");
       else
        if(((oras+i)->d)<((oras+i+2)->d))
            printf("Orasele %s si %s sunt cele mai apropiate!\n", (oras+i)->nume, (oras+i+1)->nume);
    }

}


int main()
{
    int n;
    char oras[10];
    printf("n=");
    scanf("%d", &n);
    citire(oras, &n);
    afisare(oras, n);
    distanta(oras, &n);
    system("pause");
    return 0;
}
