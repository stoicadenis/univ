#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void citire(int n)
{
    int i, v[110];
    for(i=0; i<n; i++) {
        printf("v[%d]=", i);
        scanf("%d", &v[i]);
    }
}
void afisare(int n)
{
    int i, v[110];
    for(i=0; i<n; i++)
        printf("%4d", v[i]);
    printf("\n\n");
}
void sortare(int n)
{
    int i, k, aux, v[110];
    do {
        k=1;
        for(i=0; i<n; i++) {
            if(v[i]%2==1&&v[i+1]%2==1)
                if(v[i]>v[i+1]) {
                    aux=v[i];
                    v[i]=v[i+1];
                    v[i+1]=aux;
                    k=0;
                }
        }
    } while(!k);
}

int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    citire(n);
    afisare(n);
    sortare(n);
    afisare(n);
    system("pause");
    return 0;
}

