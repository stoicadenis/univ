#include <stdio.h>
#include <stdlib.h>

void citire(int x[][30], int m, int n)
{
    int i,j;
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
    {
        printf("x[%d][%d]=",i,j);
        scanf("%d",&x[i][j]);
    }
}
void afisare(int x[][30], int m, int n)
{
    int i,j;
    for(i=0;i<m;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",x[i][j]);
    }
    printf("\n");

}

void inmultire(int c[][30],int a[][30], int b[][30], int m, int p, int n)
{
    int i,j,k;
    for(i=0;i<m;i++)
    {for(j=0;j<p;j++)
        {
            c[i][j]=0;
        for(k=0;k<n;k++)
             c[i][j]=c[i][j]+a[i][k]*b[k][j];
         }
    }
}
int main()
{
    int a[20][30],b[20][30],c[20][30],m,n,p;
    printf("m="); scanf("%d",&m);
    printf("n="); scanf("%d",&n);
    printf("p="); scanf("%d",&p);
    citire(a,m,n);
    afisare(a,m,n);
    printf("\n");
    citire(b,n,p);
    afisare(b,n,p);
    printf("\n");
    inmultire(c,a,b,m,p,n);
    printf("Afisare matrice c\n");
    afisare(c,m,p);
    return 0;
}



