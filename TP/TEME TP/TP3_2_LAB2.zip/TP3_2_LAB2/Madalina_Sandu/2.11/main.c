#include <stdio.h>
#include <stdlib.h>
void citire(int a[][30], int *n, int *m)
{
    int i,j;
    for(i=0;i<*m;i++)
        for(j=0;j<*n;j++)
    {
        printf("a[%d][%d]=",i,j);
        scanf("%d",&a[i][j]);
    }
}
void afisare(int a[][30], int *n, int *m)
{
    int i,j;
    for(i=0;i<*m;i++)
    {
        printf("\n");
        for(j=0;j<*n;j++)
        printf("%d ",a[i][j]);
    }
    printf("\n");
}

void suma_coloana(int a[][30],int *v,int *n, int *m)
{
    int i,j;
    for(j=0;j<*n;j++)
    {
        *(v+j)=0;
       for(i=0;i<*m;i++)
          *(v+j)=*(v+j)+a[i][j];
    }

    for(i=0;i<*n;i++)
        printf("%d ",*(v+i));

 printf("\n");
}

void suma_linie(int a[][30],int *v1,int *n, int *m)
{
    int i,j;
    for(i=0;i<*m;i++)
    {
        *(v1+i)=0;
       for(j=0;j<*n;j++)
          *(v1+i)=*(v1+i)+a[i][j];
    }

    for(i=0;i<*m;i++)
        printf("%d ",*(v1+i));

 printf("\n");
}

int main()
{
    int a[10][30],v[10],v1[10],n,m;
    printf("m="); scanf("%d",&m);
    printf("n="); scanf("%d",&n);
    citire(a,&n,&m);
    afisare(a,&n,&m);
    printf("\n");
    printf("Suma elementelor de pe fiecare coloana ");
    suma_coloana(a,v,&n,&m);
    printf("Suma elementelor de pe fiecare linie ");
    suma_linie(a,v1,&n,&m);


    return 0;
}

