#include <stdio.h>
#include <stdlib.h>

void citire(int a[][30], int n)
{
    int i,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
    {
        printf("a[%d][%d]=",i,j);
        scanf("%d",&a[i][j]);
    }
}
void afisare(int a[][30], int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",a[i][j]);
    }
    printf("\n");
}
void interschimbare(int a[][30], int n)
{
    int b[10][30],i,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        if(i>j||i<j)
            b[i][j]=a[j][i];
         else
            b[i][j]=a[i][j];

          for(i=0;i<n;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",b[i][j]);
    }
}
int main()
{
    int a[20][30],n;
    printf("n="); scanf("%d",&n);
    citire(a,n);
    afisare(a,n);
    interschimbare(a,n);
    return 0;
}
