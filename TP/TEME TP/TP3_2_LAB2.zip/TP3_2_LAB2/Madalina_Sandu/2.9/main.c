#include <stdio.h>
#include <stdlib.h>
void formare(int a[][10],int *m, int *n)
{
    int i,j,p=1;
    for(i=0;i<*m;i++)
        for(j=0;j<*n;j++)
          if(p<=*m*(*n))
        {  a[i][j]=p;
           p=p+1;
        }

    for(i=0;i<*m;i++)
    {
        printf("\n");
        for(j=0;j<*n;j++)
        printf("%d ",a[i][j]);
     }
}
int main()
{
    int a[10][10],m,n;
    printf("m="); scanf("%d",&m);
    printf("n="); scanf("%d",&n);
    formare(a,&m,&n);
    return 0;
}



