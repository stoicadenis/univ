#include <stdio.h>
#include <stdlib.h>

void citire(int a[][30], int n, int m)
{
    int i,j;
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
    {
        printf("a[%d][%d]=",i,j);
        scanf("%d",&a[i][j]);
    }
}
void afisare(int a[][30], int n, int m)
{
    int i,j;
    for(i=0;i<m;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",a[i][j]);
    }
    printf("\n");
}
void adaugare(int a[][30], int n, int m)
{
    int i,j,b[10][30];
    if(m==3)
   {  for(i=0;i<m;i++)
        for(j=0;j<n;j++)
        {
             b[i][j]=a[i][j];
              b[m][j]=0;
        }
   }
   else
   {
       for(i=0;i<m;i++)
        for(j=0;j<n;j++)
            if(i==3)
            {  b[i][j]=0;
               b[i+1][j]=a[i][j];
            }
        else
            b[i][j]=a[i][j];
   }
  for(i=0;i<=m;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",b[i][j]);
    }
   printf("\n");

}
int main()
{
    int a[20][30],n,m;
    printf("n="); scanf("%d",&n);
    printf("m="); scanf("%d",&m);
    if(m<3)
        printf("Nu avem linia de indice 2");
        else
    {
       citire(a,n,m);
       printf("Afisare matrice initiala");
       afisare(a,n,m);
       adaugare(a,n,m);
    }
    return 0;
}
