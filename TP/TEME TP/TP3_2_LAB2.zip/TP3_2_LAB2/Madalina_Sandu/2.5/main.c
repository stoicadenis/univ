#include <stdio.h>
#include <stdlib.h>
void citire(int mat1[][30], int n, int m)
{
    int i,j;
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
    {
        printf("mat1[%d][%d]=",i,j);
        scanf("%d",&mat1[i][j]);
    }
}
void afisare(int mat1[][30], int n, int m)
{
    int i,j;
    for(i=0;i<m;i++)
    {
        printf("\n");
        for(j=0;j<n;j++)
        printf("%d ",mat1[i][j]);
    }
    printf("\n");
}
void transpusa(int mat1[][30], int n, int m)
{
    int mat2[30][20],i,j;
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
        mat2[i][j]=mat1[j][i];

    for(i=0;i<n;i++)
    {
        printf("\n");
        for(j=0;j<m;j++)
        printf("%d ",mat2[i][j]);
    }
    printf("\n");
}
int main()
{
    int mat1[20][30],n,m;
    printf("m="); scanf("%d",&m);
    printf("n="); scanf("%d",&n);
    citire(mat1,n,m);
    afisare(mat1,n,m);
    transpusa(mat1,n,m);
    return 0;
}

