#include <stdio.h>
#include <stdlib.h>

void minmax(int v[10],int n)
{

     int imin,imax,min,max,i;
     for(i=1;i<n;i++)
     {
                  if(v[i]<min)

          {
               min=v[i];
               imin=i;
          }
                    if(v[i]<max)
          {
              max=v[i];
              imax=i;
          }
     }
     printf(" Indicii elementelor sunt:%d %d",imin,imax);
}
 int main ()
 {
      int v[10],i,n;
      scanf("%d",&n);
      for(i=0;i<n;i++)
        scanf("%d",&v[i]);
      minmax(v,n);
      return 0;
 }
