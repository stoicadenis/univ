#include <stdio.h>
#include <stdlib.h>

void ordonare(int *a, int *b)
 {
     int *aux;
    if (a>b)
        {
            aux=*a;
            *a=*b;
            *b=aux;
        }


 }
 int main ()
{
     int a,b;
     printf("dati prima valoare ");
     scanf("%d",&a);
     printf("dati a doua valoare ");
     scanf("%d",&b);
     ordonare(&a,&b);
     printf("ordonarea numerelor in ordinea crescatoare este: %d %d",a,b);
     return 0;
}
