#include <stdio.h>
#include <stdlib.h>

void citire(int n, int v[n])
{
    int i;
    for(i=0;i<n;i++)
    {
        scanf("%d", &v[i]);
    }
}
void egal(int m, int x1[m], int x2[m])
{
    int i, k=0;
    for(i=0;i<m;i++)
    {
        if(x1[i]==x2[i])
        {
            k++;
        }
    }
    if(k==0)
            printf("there are no equal elements\n");
        else
        {
            printf("there are %d equal elements", k);
            if(k!=m)
                printf("\n");
            if(k==m)
                printf(", so all the elements are equal\n");
        }
}
int main()
{
    int no;
    while(1)
    {
        printf("how many elements?(less than 10): ");
        scanf("%d", &no);
        if(no>10)
            printf("wrong number\n");
        int v1[no];
        int v2[no];
        int a[4];
        a[0]=4;
        a[1]=3;
        a[2]=9;
         printf("elementele vectorului 1: ");
        citire(no, v1);
        printf("elementele vectorului 2: ");
        citire(no, v2);
        egal(no, v1, v2);

    }
    return 0;
}
