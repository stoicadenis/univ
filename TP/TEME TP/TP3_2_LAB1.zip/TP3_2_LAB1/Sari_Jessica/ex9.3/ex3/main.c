#include <stdio.h>
#include <stdlib.h>

int* ascend(int* x)
{
    int aux;
    if(x[0]>x[1])
    {
        aux=x[1];
        x[1]=x[0];
        x[0]=aux;
    }
    return x;
}
int main()
{
    int a, b, i,j;
    int h[2];
    while(1)
    {
        for(i=0;i<2;i++)
    {
        if(i==0){
            printf("First number is: ");
        scanf("%d", &a);
        h[i]=a;}
        if(i==1){
            printf("Second number is: ");
        scanf("%d", &b);
        h[i]=b;}
    }

    int* d=ascend(&h);
    printf("a and b sorted: %d %d\n", d[0], d[1]);
    }

    return 0;
}
