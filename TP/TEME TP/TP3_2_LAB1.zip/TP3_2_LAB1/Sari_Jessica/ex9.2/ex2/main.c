#include <stdio.h>
#include <stdlib.h>

int findMin(int x, int y)
{
    if(x<y)
        return x;
    return y;
}
int main()
{
    int no1, no2, no3;
    while(1)
    {
        printf("no1=");
        scanf("%d", &no1);
        printf("no2=");
        scanf("%d", &no2);
        printf("no3=");
        scanf("%d", &no3);
        printf("Smol= %d \n", findMin(findMin(no1, no2), no3));
    }

    return 0;
}
