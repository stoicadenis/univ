#include <stdio.h>
#include <stdlib.h>

void horizontalEight(int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("*");
    printf("\n");
}
void verticalEight(int n)
{
    int i, j;
    for(i=0;i<(round(n/2)-1);i++)
    {
         printf("*");
         for(j=0;j<n-2;j++)
            printf(" ");
         printf("*\n");
    }

}
int main()
{
    int n;
    while(1)
    {
        printf("n=");
    scanf("%d", &n);
    if(n%2==0)
        printf("Please enter an uneven number>4\n");
    else
    {
        horizontalEight(n);
        verticalEight(n);
        horizontalEight(n);
        verticalEight(n);
        horizontalEight(n);
    }

    }
    return 0;
}
