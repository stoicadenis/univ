#include<stdio.h>
#include<stdlib.h>

/*
int isEvenSum(int n) {
	if (n % 2 == 0) {
		return n;
	}
	return 0;
}

int sumaNrPareI(int n) {
	int sum = 0;
	while (n != 0) {
		sum += isEvenSum(n % 10);
		n /= 10;
	}
	return sum;
}

int sumaNrPareR(int n) {
	if (n == 0) {
		return 0;
	}
	return sumaNrPareR(n / 10) + isEvenSum(n % 10);
}

int main() {
	int n;
	scanf("%d", &n);
	//printf("Suma nr pare %d", sumaNrPareI(n));
	printf("Suma nr pare %d", sumaNrPareR(n));

	return 0;
}
*/