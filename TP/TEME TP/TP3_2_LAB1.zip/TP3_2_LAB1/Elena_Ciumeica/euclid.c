#include<stdio.h>
#include<stdlib.h>

/*
int euclidIterativ(int a, int b)
{
	int c;
	while (b) {
		c = a % b;
		a = b;
		b = c;
	}
	return a;
}

void euclidRecursiv(int a, int b, int* c)
{
	if (b == 0) {
		*c = a;
	}
	else
		euclidRecursiv(b, a % b, c);
}

int main() {
	int a, b, c;
	scanf("%d%d", &a, &b);
	//c = euclidIterativ(a, b);
	euclidRecursiv(a, b, &c);
	printf("%d", c);

	return 0;
}
*/