#include<stdio.h>
#include<stdlib.h>
/*
int cmmdc(int a, int b) {
	if (a == b) {
		return a;
	}
	if (a > b) {
		return cmmdc(a - b, b);
	}
	return cmmdc(a, b - a);
}

int main() {
	int a, b;
	scanf("%d%d", &a, &b);
	printf("Cmmdc: %d", cmmdc(a, b));

	return 0;
}
*/