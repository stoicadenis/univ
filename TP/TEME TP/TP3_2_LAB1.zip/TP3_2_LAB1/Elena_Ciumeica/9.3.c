#include<stdlib.h>
#include<stdio.h>

/*
void sortCresc(int* tab) {
	if (tab[0] > tab[1]) {
		tab[0] += tab[1];
		tab[1] = tab[0] - tab[1];
		tab[0] = tab[0] - tab[1];
	}
}

int main() {
	int tab[2];
	scanf("%d%d", &tab[0], &tab[1]);
	printf("%d %d\n", tab[0], tab[1]);
	sortCresc(tab);
	printf("%d %d", tab[0], tab[1]);

	return 0;
}
*/