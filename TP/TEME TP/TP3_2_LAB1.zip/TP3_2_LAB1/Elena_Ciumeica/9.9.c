#include<stdio.h>
#include<stdlib.h>

void indiciMinMaxI(int* v, int* r, int n) {
	do {
		n--;
		if (v[r[0]] > v[n]) {
			r[0] = n;
		}
		if (v[r[1]] < v[n]) {
			r[1] = n;
		}
	} while (n);
}

void indiciMinMaxR(int* v, int* r, int n) {

	if (v[r[0]] > v[n]) {
		r[0] = n;
	}
	if (v[r[1]] < v[n]) {
		r[1] = n;
	}
	if (n > 0) {
		indiciMinMaxR(v, r, n-1);
	}
}

int main() {
	int i, size;
	int v[10];

	scanf("%d", &size);
	int r[] = { size - 1, size - 1 };
	for (i = 0; i < size; i++) {
		scanf("%d", &v[i]);
	}
	indiciMinMaxI(v, r, size);
	//indiciMinMaxR(v, r, size - 1);
	printf("Min %d \nMax %d\n", r[0], r[1]);

	return 0;
}