#include<stdio.h>
#include<stdlib.h>
#include<math.h>

/*
int isPrimeI_1(int n) {
	int i;
	if (n < 2) {
		return 0;
	}
	if (n % 2 == 0 && n != 2) {
		return 0;
	}
	for (i = 3; i * i <= n; i += 2) {
		if (n % i == 0) {
			return 0;
		}
	}
	return 1;
}

int isPrimeR(int n, int d) {
	if (n < 2) {
		return 0;
	}
	if (n % 2 == 0 && n != 2) {
		return 0;
	}
	if (n % d == 0 && n != d) {
		return 0;
	}
	if (d * d > n) {
		return 1;
	}
	isPrimeR(n, d + 2);
}

int isPrimeI_2(int n) {
	int c;
	for (c = 2; c <= sqrt(n); c++) {
		if (n % c == 0) {
			return 0;
		}
	}

	if (c == (int)sqrt(n) + 1)
		return 1;

	return 0;
}

int main() {
	int n;
	scanf("%d", &n);
	//if (isPrimeI_1(n)) {
	//if (isPrimeI_2(n)) {
	if (isPrimeR(n, 3)) {
		printf("Este nr prim\n");
	}
	else {
		printf("Nu e nr prim\n");
	}

	return 0;
}
*/