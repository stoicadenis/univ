#include<stdlib.h>
#include<stdio.h>

/*void drawVertically(int n) {
	int i, j;
	for (i = 0; i < n/2; i++) {
		printf("\n*");
		for (j = 0; j < n; j++) {
			printf(" ");
		}
		printf("*\n");
	}
}

void drawHorizontally(int n) {
	int i;
	printf(" ");
	for (i = 0; i < n; i++)
	{
		printf("*");
	}
}

int main() {
	int n;
	scanf("%d", &n);
	drawHorizontally(n);
	drawVertically(n);
	drawHorizontally(n);
	drawVertically(n);
	drawHorizontally(n);

	return 0;
}*/