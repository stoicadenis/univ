#include<stdio.h>
#include<stdlib.h>

/*int SumaR(int n) {
	if (n == 0) {
		return 0;
	}
	return SumaR(n / 10) + (n % 10);
}

int SumaI(int n) {
	int suma = 0;
	while (n > 0) {
		suma += n % 10;
		n /= 10;
	}
	return suma;
}

int main() {
	int n, s;
	scanf("%d", &n);
	//s = SumaI(n);
	s = SumaR(n);
	printf("Suma %d", s);

	return 0;
}
*/