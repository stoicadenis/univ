#include<stdio.h>
#include<stdlib.h>

/*
int Ackermann(int m, int n) { //Stack overflow error!
	if (!m) return n + 1;
	if (!n) return Ackermann(m - 1, 1);
	return Ackermann(m - 1, Ackermann(m, n - 1));
}

int main() {
	int m, n;
	scanf("%d%d", &m, &n);
	printf("Value: %d\n", Ackermann(m, n));

	return 0;
}
*/