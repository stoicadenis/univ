#include<stdio.h>
#include<stdlib.h>

/*
float findMaxElem(float a, float b, float c) {
	if (a > b) {
		if (a > c) {
			return a;
		}
		return c;
	}
	if (b > c) {
		return b;
	}
	return c;
}

int main() {
	float numbers[3];
	scanf("%f%f%f", &numbers[0], &numbers[1], &numbers[2]);
	printf("Max val is: %.2f\n", findMaxElem(numbers[0], numbers[1], numbers[2]));

	return 0;
}
*/