#include<stdio.h>
#include<stdlib.h>
/*
void citire(int* v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		scanf("%d", &v[i]);
	}
}

void egal(int* v1, int* v2, int n) {
	int i;
	for (i = 0; i < n; i++) {
		if (v1[i] != v2[i]) {
			printf("Nu sunt egale\n");
			return;
		}
	}
	printf("Sunt egale\n");
}

int main() {
	int n;
	int* tab1, * tab2;
	scanf("%d", &n);
	tab1 = malloc(n * sizeof(int));
	tab2 = malloc(n * sizeof(int));
	citire(tab1, n);
	citire(tab2, n);
	egal(tab1, tab2, n);

	return 0;
}
*/