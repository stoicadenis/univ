#include<stdio.h>
#include<stdlib.h>
/*
int egal(int* v1, int* v2, int n) {
	int i;
	for (i = 0; i < n; i++) {
		if (v1[i] != v2[i]) {
			return 0;
		}
	}
	return 1;
}

void citire1(int** v, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		v[i] = malloc(n * sizeof(int));
		for (j = 0; j < n; j++) {
			scanf("%d", &v[i][j]);
		}
	}
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			printf("%d", v[i][j]);
		}
		printf("\n");
	}
}

void citire2(int* v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		scanf("%d", &v[i]);
	}
}

void findPoz(int** v1, int* v2, int m, int n, int k) {
	int i, j, has = 0;
	for (i = 0; i < m; i++) {
		for (j = 0; j <= n - k; j++) {
			if (egal(&v1[i][j], v2, k)) {
				printf("Lin %d col %d\n", i, j);
				has = 1;
			}
		}
	}
	if (!has) {
		printf("Nu se regaseste\n");
	}
}

int main() {
	int** a;
	int* v;
	int m, n, k;
	scanf("%d", &m);
	scanf("%d", &n);
	a = malloc(m * sizeof(int*));
	citire1(a, m, n);
	scanf("%d", &k);
	v = malloc(k * sizeof(int));
	citire2(v, k);
	findPoz(a, v, m, n, k);

	return 0;
}
*/