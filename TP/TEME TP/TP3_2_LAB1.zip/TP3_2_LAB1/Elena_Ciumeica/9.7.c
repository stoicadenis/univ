#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define M_PI 3.14159265358979323846264338327950288

/*
float unghi(float x0, float x1, float y0, float y1) {
	float deg, rad;
	rad = atan((y1 - y0) / (x1 - x0));// atan2((y1 - y0), (x1 - x0));
	deg = rad * 180.0 / M_PI;
	return deg;
}

int main() {
	float x0, x1, y0, y1;
	scanf("%d%d%d%d", &x0, &y0, &x1, &y1);
	printf("Unghi cu Ox: %.2f", unghi(x0, x1, y0, y1));

	return 0;
}
*/