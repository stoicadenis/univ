#include <stdio.h>
#include <stdlib.h>

void linieVerticala(int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("*");
    printf("\n");
}

void liniiOrizontale(int n)
{
    int i,j;
    for(i=0;i<(n-3)/2;i++)
    {
        printf("*");
        for(j=1;j<=n-2;j++)
            printf(" ");
        printf("*\n");
    }

}

int main()
{
int n;

printf("n= ");
scanf("%d",&n);

linieVerticala(n);      //apel functie- linia orizontala de sus
liniiOrizontale(n);     //apel functie- liniile verticale superioare
linieVerticala(n);      //apel functie- linia orizontala de la mijloc
liniiOrizontale(n);     //apel functie- liniile verticale inferioare
linieVerticala(n);      //apel functie- linia orizontala de jos

return 0;
}
