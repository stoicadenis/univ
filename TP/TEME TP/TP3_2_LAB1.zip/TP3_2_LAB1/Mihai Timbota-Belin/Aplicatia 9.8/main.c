#include <stdio.h>
#include <stdlib.h>

int ackermann(int m, int n)
{
    if(!m)
        return n+1;
    if(!n)
        return ackermann(m-1,1);
    return ackermann(m-1, ackermann(m,n-1));
}

int main()
{
 int m,n;
    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);

    printf("%d",ackermann(m,n));
    return 0;
}
