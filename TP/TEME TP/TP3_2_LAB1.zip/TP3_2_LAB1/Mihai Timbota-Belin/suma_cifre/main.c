#include <stdio.h>
#include <stdlib.h>

int sumaC(int n)
{

    if(n==0)
       return 0;
    return sumaC(n/10)+n%10;

}

int main()
{
  int n;
  printf("n=");
  scanf("%d",&n);
  printf("suma cifrelor numarului %d = %d",n,sumaC(n));
    return 0;
}
