#include <stdio.h>
#include <stdlib.h>

void func(int v[])
{
    //int a,b;
    printf("a=");
    scanf("%d",&v[0]);
    printf("b=");
    scanf("%d",&v[1]);

    if(v[0]>v[1])
       {
           v[0]+=v[1];
           v[1]=v[0]-v[1];
           v[0]=v[0]-v[1];
       }

}

int main()
{int v[2];
    func(v);
    printf("%d %d",v[0],v[1]);
    return 0;
}
