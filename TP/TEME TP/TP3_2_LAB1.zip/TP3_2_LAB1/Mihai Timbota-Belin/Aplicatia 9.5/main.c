#include <stdio.h>
#include <stdlib.h>

int egal(float v1[],float v2[],int n)
{
    int i;
    for(i=0;i<n;i++)
        if(v1[i]!=v2[i])
            return 0;
    return 1;
}

int main()
{
    int m,n,i,j,k,gasit=0;
    float a[9][9],v[4];

printf("m=");
scanf("%d",&m);
printf("n=");
scanf("%d",&n);


for(i=0;i<m;i++)               // citire matrice
        for(j=0;j<n;j++)
    {
        printf("a[%d][%d]=",i,j);
        scanf("%f",&a[i][j]);
    }
printf("k=");
scanf("%d",&k);


for(i=0;i<k;i++)                //citire tablou
{
    printf("v[%d]=",i);
    scanf("%f",&v[i]);
}

for(i=0;i<m;i++)
    for(j=0;j<n-k+1;j++)
{
    if(egal(&a[i][j],v,k))
    {
     printf("(%d, %d)\n",i,j);
     gasit=1;
    }
}

if(!gasit)
    printf("vectorul v nu apare in matricea m\n");


    return 0;
}
