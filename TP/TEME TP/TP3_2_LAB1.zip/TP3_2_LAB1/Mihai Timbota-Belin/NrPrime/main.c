#include <stdio.h>
#include <stdlib.h>

void NrPrime(int n)
{
    if(n>=1);
    {
        printf("primele %d numere prime sunt: ",n);
        printf("2 ");
    }
    int i=3,j,k;
    for(k=2;k<=n;i++)
    {
        for(j=2;j<=i/2;j++)
            if(i%j==0)
                break;
        if(j==i/2+1)
        {
            printf("%d ",i);
            k++;
        }
    }
}

int main()
{
    int n;
printf("n=");
scanf("%d",&n);
NrPrime(n);
    return 0;
}
