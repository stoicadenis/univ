#include <stdio.h>
#include <stdlib.h>


void indici (int v[],int n, int *imax, int *imin)
{
    int i,max,min;
    max=v[0];
    min=v[0];
    *imax=0;
    *imin=0;
    for(i=1;i<n;i++)
    {
        if(max<v[i])
            {
                max=v[i];
                *imax=i;
            }
        if(min>v[i])
        {
            min=v[i];
            *imin=i;
        }
    }

}

int main()
{
   int n, v[100],imax=0,imin=0,i;

   printf("n=");
   scanf("%d",&n);

   for(i=0;i<n;i++)
   {
       printf("v[%d]=",i);
       scanf("%d",&v[i]);

   }

  indici(v,n,&imax,&imin);

   printf("imax=%d, imnin=%d",imax,imin);
    return 0;
}
