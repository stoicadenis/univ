#include <stdio.h>
#include <stdlib.h>

int cifrePare(int n)
{

    if(n/10==0)
        return (n+1)%2;
    return (cifrePare(n/10))+(n%10+1)%2;
}

int main()
{
 int n;
  printf("n=");
  scanf("%d",&n);
  printf("numarul cifrelor pare ale lui %d este %d",n,cifrePare(n));
    return 0;
}
