#include <stdio.h>
#include <stdlib.h>

int cmmdc(int a,int b)
{
    if(a==b)
        return a;
    if(a>b)
        return cmmdc(a-b,b);
    return cmmdc(a,b-a);
}

int main()
{

  int a,b;
  printf("a=");
  scanf("%d",&a);
    printf("b=");
  scanf("%d",&b);

  printf("cmmdc(%d,%d)=%d\n",a,b,cmmdc(a,b));


    return 0;
}
