#include <stdio.h>
#include <stdlib.h>

void citire_afisare(int v[10], int *n)
{
	int i;
	for (i = 0; i < *n; i++) {
		printf("v[%d]=", i);
		scanf("%d", &v[i]);
	}
	for (i = 0; i < *n; i++)
		printf("%4d", v[i]);
	printf("\n");
}
int egal(int v1[10], int v2[10], int *n)
{
	int i, k;
	do {
		k = 0;
		for (i = 0; i < *n; i++) {
			if (v1[i] == v2[i]) {
				continue;
				return 1;
			}
			else {
				return 0;
				break;
			}
		}
	} while (!k);
}

int main()
{
	int n, v1[10], v2[10], e;
	printf("n=");
	scanf("%d", &n);
	citire_afisare(&v1, &n);
	printf("\n");
	citire_afisare(&v2, &n);
	e = egal(v1, v2, &n);
	if (e == 0) printf("\n   FALSE!\n\n");
	else printf("\n   TRUE!\n\n");
	system("pause");
	return 0;
}
