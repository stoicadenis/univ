#include <stdio.h>

int crescator(int x, int y)
{
    int aux;
    if(x>y) {
        aux=x;
        x=y;
        y=aux;
    }
    printf(" %d  %d\n", x, y);
}
int main()
{
    int numar1, numar2, c, aux;
    printf("Introduceti primul numar: ");
    scanf("%d", &numar1);
    printf("Introduceti al doilea numar: ");
    scanf("%d", &numar2);
    printf("Ordonarea crescatoare a celor doua numere:\n");
    crescator(numar1, numar2);
    return 0;
}
