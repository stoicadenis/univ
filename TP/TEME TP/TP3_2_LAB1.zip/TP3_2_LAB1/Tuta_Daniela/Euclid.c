#include <stdio.h>

int Euclid(int,int);

int main() {
	int a, b, E;
	printf("Introduceti primul numar: ");
	scanf("%d", &a);
	printf("Introduceti al doilea numar: ");
	scanf("%d", &b);
	E=Euclid(a, b);
	printf("Cel mai mare divizor comun dintre %d si %d este %d.\n", a, b, E);
	getch();
	return 0;
}

int Euclid(int m, int n)  {
	int cmmdc, rest;

	rest = m%n;
	while (rest != 0)  {
		m = n;
		n = rest;
		rest = m%n;
	}
	cmmdc = n;
	return n;
}
