#include <stdio.h>

int min(int n, int v[20])
{
	int i, min, k = 0;
	min = v[0];
	for (i = 1; i < n; i++)
		if (min > v[i]) {
			min = v[i];
			k = i;
		}
	return k;
}
int max(int n, int v[20])
{
	int i, max, k = 0;
	max = v[0];
	for (i = 1; i < n; i++)
		if (max < v[i]) {
			max = v[i];
			k = i;
		}
	return k;
}

int main()
{
	int i, n, v[20], m, M;
	printf("n=");
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		printf("v[%d]=", i);
		scanf("%d", &v[i]);
	}
	m = min(n, v);
	M = max(n, v);
	printf("Indicele elementului minim din vector este %d.\n\n", m);
	printf("Indicele elementului maxim din vector este %d.\n\n", M);
	system("pause");
	return 0;
}
