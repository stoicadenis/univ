#include <stdio.h>

void linieOrizontala(int n) {
int i;
for(i=0; i<n; i++)
    printf("*");
printf("\n");
}
void Space(int n) {
int i;
for(i=0; i<(n-2); i++)
    printf(" ");
printf("*\n");
}
void Verticala(int n) {
int i;
for(i=0; i<n/2; i++) {
        printf("*");
        Space(n);
        }
}

int main()
{
    int n, i;
    printf("n="); scanf("%d", &n);
    linieOrizontala(n);
    Verticala(n);
    linieOrizontala(n);
    Verticala(n);
    linieOrizontala(n);
    return 0;
}
