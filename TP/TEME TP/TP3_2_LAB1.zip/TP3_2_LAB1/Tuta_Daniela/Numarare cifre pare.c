#include <stdio.h>

int pare(int nr)
{
    int k, i=0;
    while(nr!=0) {
        k=nr%10;
        if(k%2==0)
            i++;
        nr=nr/10;
    }
    return i;
}
int main()
{
    int numar, p;
    printf("Introduceti numarul: ");
    scanf("%d", &numar);
    p=pare(numar);
    printf("Numarul %d are %d cifre pare.\n", numar, p);
    system("pause");
    return 0;
}
