#include <stdio.h>
#include <math.h>

int prim(int nr)
{
    int i;
    if(nr<2)
        return 0;
    if(nr==2)
        return 1;
    for(i=2; i<=nr/2; i++)
        if(nr%i==0)
            return 0;
    return 1;
}

int main()
{
    int numar;
    printf("Introduceti numarul: ");
    scanf("%d", &numar);
    if(prim(numar)==1)
        printf("Numarul %d este prim!\n", numar);
    else
        printf("Numarul %d NU este prim!\n", numar);
    system("pause");
    return 0;
}
