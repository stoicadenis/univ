
#include<stdio.h>
#include<conio.h>

int sum_of_digits(int n)
{
	if (n == 0)
		return 0;
	return((n % 10) + sum_of_digits(n / 10));
}

int main() {
	int n;
	printf("Dati numarul:");
	scanf("%d", &n);
	int result = sum_of_digits(n);
	printf("Suma cifrelor este:%d", result);
	_getch();
	return 0;
}
