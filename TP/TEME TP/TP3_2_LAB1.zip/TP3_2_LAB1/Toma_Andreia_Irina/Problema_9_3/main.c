
#include<stdio.h>

int swap(int *a, int*b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

int main()
{
	int a, b;
	printf("Introdu a:");
	scanf("%d", &a);
	printf("Introdu b:");
	scanf("%d", &b);
	if (a > b)
		swap(&a, &b);
	printf("Valorile sortate sunt: %d %d", a, b);
	_getch();
	return 0;
}
