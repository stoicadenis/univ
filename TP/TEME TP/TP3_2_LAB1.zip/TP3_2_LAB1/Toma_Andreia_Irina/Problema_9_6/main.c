
#include<stdio.h>

int cmmdc(int a, int b)
{
	if (a == b)
		return a;
	if (a > b)
		return cmmdc(a - b, b);
	if (b > a)
		return cmmdc(a, b - a);
}

int main() {
	int a, b, c;
	printf("Dati a:");
	scanf("%d", &a);
	printf("Dati b:");
	scanf("%d", &b);
	c=cmmdc(a, b);
	printf("CMMDC ESte %d", c);
	_getch();
	return 0;
}
