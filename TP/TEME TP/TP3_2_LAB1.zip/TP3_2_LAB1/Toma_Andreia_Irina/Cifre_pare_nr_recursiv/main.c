
#include<stdio.h>

int even(int n)
{
	int digit;
	if (n == 0)
		return 0;
	digit = n % 10;
	if (digit % 2 == 0)
	{
		return(1 + even(n / 10));
	}
	else
	{
		return even(n / 10);
	}
}

int main()
{
	int n, c;
	printf("Introdu nr:");
	scanf("%d", &n);
	c=even(n);
	printf("Exista %d nr pare",c);
	_getch();
	return 0;
}
