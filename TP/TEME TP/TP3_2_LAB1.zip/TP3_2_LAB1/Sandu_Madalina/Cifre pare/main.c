#include <stdio.h>
#include <stdlib.h>
void cifre_iterativ(int n)
{
    int i,k=0,c;
    while(n)
    {
        c=n%10;
        if(c%2==0)
           {
               k=k+1;
               n=n/10;
           }
           else
            n=n/10;
    }
   printf("Varianta iterativa - Nr are %d cifre pare\n",k);

}

int cifre_recursiv(int n)
{
    if(n==0)
        return 0;
    if(n%2==0)
        return cifre_recursiv(n/10)+1;
    return cifre_recursiv(n/10);
}
int main()
{
    int n,i;
    printf("Introduceti nr "); scanf("%d",&n);
        cifre_iterativ(n);
        printf("Varianta recursiva - Nr are %d cifre pare",cifre_recursiv(n));
    return 0;
}
