#include <stdio.h>
#include <stdlib.h>
void citire(int v[],int n)
{
    int i;
    printf("Citire elemente");
    for(i=0;i<n;i++)
        scanf("%d",&v[i]);
}

int egal(int v1[],int v2[], int n)
{
    int i;
    for(i=0;i<n;i++)
      if(v1[i]!=v2[i])
        return 0;
    return 1;

}

int main()
{
    int n,v1[10],v2[10];
    printf("n=");
    scanf("%d",&n);
    citire(v1,n);
    citire(v2,n);
    if(egal(v1,v2,n)==1)
        printf("Toate elementele sunt egale");
        else
    printf("Elementele nu sunt egale");
    return 0;
}
