#include <stdio.h>
#include <stdlib.h>
int cmmdc(int a, int b)
{
    if(a==b)
        return a;
    else
        if(a>b)
        return cmmdc(a-b,b);
    else
        return cmmdc(a,b-a);
}
int main()
{
    int a,b;
    printf("a="); scanf("%d",&a);
    printf("b="); scanf("%d",&b);
    printf("cmmdc dintre %d si %d este %d",a,b,cmmdc(a,b));
    return 0;
}
