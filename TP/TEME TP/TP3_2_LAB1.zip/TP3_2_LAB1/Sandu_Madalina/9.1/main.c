#include <stdio.h>
#include <stdlib.h>
void linieOrizontala(int n)
{
    int i;
    for (i = 0; i < n; i++)
        printf("*");
    printf("\n");
}

void linieVerticala(int n)
{
    int i,p;
    for (p = 0; p< (n - 3) / 2; p++)
       {
           for(i=0;i<n;i++)
            {if(i==0)
            printf("*");
            else
               {
                   if(i==n-1)
                    printf("*\n");
                    else
                   printf(" ");

               }
            }
    }
}

int main()
{
    int n;
    printf("n=");
    scanf("%d", &n);
    linieOrizontala(n);
    linieVerticala(n);
    linieOrizontala(n);
    linieVerticala(n);
    linieOrizontala(n);
    return 0;
}

