#include <stdio.h>
#include <stdlib.h>

float minim(float a, float b)
{
    if(a<b) return a;
    return b;
}
int main()
{
    float a,b,c;
    printf("Introduceti nr:");
    scanf("%f%f%f",&a,&b,&c);
    printf("Minimul este %f",minim(minim(a,b),c));
    return 0;
}
