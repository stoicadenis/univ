#include <stdio.h>
#include <stdlib.h>
void in(int v[],int n)
{
    int i,mini,maxi;
    mini=v[0];
    maxi=v[0];
    for(i=1;i<n;i++)
        if(v[0]>v[i])
        mini=v[i];
     for(i=0;i<n;i++)
        if(v[0]<v[i])
        maxi=v[i];

        for(i=0;i<n;i++)
            if(v[i]==mini)
            printf("Indice minim:%d\n",i);
        for(i=0;i<n;i++)
            if(v[i]==maxi)
            printf("Indice maxim:%d",i);
}
int main()
{
    int n,v[10],i,mini,maxi;
    printf("n=");  scanf("%d",&n);
    printf("Introduceti elementele\n");
    for(i=0;i<n;i++)
    {
        printf("v[%d]=",i);
        scanf("%d",&v[i]);
    }
    in(v,n);

    return 0;
}
