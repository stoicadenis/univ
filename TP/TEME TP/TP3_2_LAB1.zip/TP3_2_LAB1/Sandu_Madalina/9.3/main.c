#include <stdio.h>
#include <stdlib.h>

void sortare(int *a, int *b)
{
    int aux;
    if(a>b)
    {
        aux=*a;
        *a=*b;
        *b=aux;
    }

}
int main()
{
    int a,b;
    printf("a="); scanf("%d",&a);
    printf("b="); scanf("%d",&b);
    sortare(&a,&b);
     printf("%d,%d",a,b);
    return 0;
}
