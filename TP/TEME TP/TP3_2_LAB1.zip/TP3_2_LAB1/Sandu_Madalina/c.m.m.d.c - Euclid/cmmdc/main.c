#include <stdio.h>
#include <stdlib.h>

int euclid_iterativ(int a,int b)
{
     int c;
     while(b)
    {
        c=a%b;
        a=b;
        b=c;
    }

    return a;
}

int euclid_recursiv(int a,int b)
{
      if (b==0)
           return a;
      else
            return euclid_recursiv(b,a%b);
}
int main()

{
    int a,b;
    printf("Introduceti numerele:");
    scanf("%d%d",&a,&b);
    printf("Varianta iterativa - cmmdc este %d \n",euclid_iterativ(a,b));
    printf("Varianta recursiva - cmmdc este %d",euclid_recursiv(a,b));

    return 0;
}
