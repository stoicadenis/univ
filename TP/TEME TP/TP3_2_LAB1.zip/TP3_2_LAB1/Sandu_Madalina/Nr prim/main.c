#include <stdio.h>
#include <stdlib.h>

int prim_iterativ(int n)
{
    if(n< 2)
        return 0;
    if(n == 2)
        return 1;
    for(int i = 2; i <= n/ 2; i++)
        if(n% i == 0)
            return 0;
    return 1;
}

int prim_recursiv(int n,int d)
{
    if (d==1)
        return 1;
    if(n%d==0)
        return 0;
   return prim_recursiv(n,d-1);
}
int main()
{
    int n;
    printf("n= ");
    scanf("%d",&n);

    printf("Varianta iterativa -  ");
    if(prim_iterativ(n) == 1)
        printf("Nr este prim\n");
    else
        printf("Nr nu este prim\n");

    printf("Varianta recursiva - ");
    if (prim_recursiv(n,n/2)==1)
          printf("Nr este prim\n");
    else
        printf("Nr nu este prim\n");

    return 0;
}
