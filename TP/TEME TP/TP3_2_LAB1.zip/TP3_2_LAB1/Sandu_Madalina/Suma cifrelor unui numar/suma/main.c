#include <stdio.h>
#include <stdlib.h>

int suma_iterativ(int n)
{
    int s=0;
    while(n)
    {
        s=s+n%10;
        n=n/10;
    }
    return s;
}

int suma_recursiv(int n)
{
    if(!n)
        return 0;
    else
        return suma_recursiv(n/10)+n%10;
}
int main()
{
    int n;
    printf("n=");
    scanf("%d",&n);
    printf("Varianta iterativa -  suma este %d \n",suma_iterativ(n));
    printf("Varianta recursiva -  suma este %d ",suma_recursiv(n));
    return 0;
}
