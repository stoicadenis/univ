#include <stdio.h>
#include <stdlib.h>
void citire(int n,int v[])
{
    int i;
    for(i=0;i<n;i++)
        scanf("%d",&v[i]);
}
int egal(int v1[],int v2[],int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(v1[i]!=v2[i])
            return 0;
    }
        return 1;
}
int main()
{
    int n,v1[10],v2[10],i;
    scanf("%d",&n);
    citire(n,v1);
    citire(n,v2);
    if(egal(v1,v2,n))
        printf("vectorii sunt egali");
        else
        printf("vectorii nu sunt egali");
    return 0;
}
