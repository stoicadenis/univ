#include <stdio.h>
#include <stdlib.h>
void pare(int x)
{
    int nr=0;
    while(x)
    {
        if(x%2==0)
            nr++;
        x=x/10;
    }
    printf("%d",nr);
}
int main()
{
    int x,nr;
    scanf("%d",&x);
    pare(x);
    return 0;
}
