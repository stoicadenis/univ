#include <stdio.h>
#include <stdlib.h>
float maxim(float x,float y)
{
    if(x>y)
        return x;
    else return y;
}
int main()
{
    float x,y,z,max;
    scanf(" %f %f %f",&x,&y,&z);
    max=maxim(x,maxim(y,z));
    printf("%f",max);
    return 0;
}
