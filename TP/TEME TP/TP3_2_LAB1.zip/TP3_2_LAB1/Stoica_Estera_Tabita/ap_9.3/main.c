#include <stdio.h>
#include <stdlib.h>

/*Sa se scrie o functie care returneaza doua valori pe care le citeste de la tastatura, sortate in mod crescator.*/

void val(int a, int b)
{
    if(a<b)
        printf("%d %d", a, b);
    else
        printf("%d %d", b, a);
}

int main()
{
    int a,b;
    printf("a= ");
    scanf("%d",&a);
    printf("b= ");
    scanf("%d",&b);
    val(a,b);
    return 0;
}
