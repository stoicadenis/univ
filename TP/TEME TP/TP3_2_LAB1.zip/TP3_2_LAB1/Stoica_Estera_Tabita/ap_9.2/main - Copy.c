#include <stdio.h>
#include <stdlib.h>

/*Sa se scrie o functie care returneaza maximul dintre 3 valori de tip float, primite ca parametrii.*/

float nr_max(float a, float b)
{
    if(a > b)
        return a;
    return b;
}

int main()
{
    float a, b, c;
    printf("a= ");
    scanf("%f",&a);
    printf("b= ");
    scanf("%f",&b);
    printf("c= ");
    scanf("%f",&c);
    printf("Maximul= %.2f", nr_max(nr_max(a,b),c));
    return 0;
}
