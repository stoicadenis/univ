#include <stdio.h>
#include <stdlib.h>

/*Sa se scrie un program care citeste un numar n<10 iar apoi citeste 2 vectori v1 si v2 de cate n elemente de tip int.
Pentru citirea elementelor unui vector se foloseste o functie citire(v,n).
Se ve implementa o functie egal(v1,v2,n), care tsteaza daca toate elemntele de v1 sunt egale cu cele din v2 la pozitii corespondente.*/

void citire1(int v1[], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("v1[%d]= ", i);
        scanf("%d", &v1[i]);
    }
}

void citire2(int v2[], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("v2[%d]= ", i);
        scanf("%d", &v2[i]);
    }
}

int egal(int v1[], int v2[], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        if(v1[i]==v2[i])
            return 0;
    }
        return 1;
}

int main()
{
    int n, v1[10], v2[10];
    printf("n= ");
    scanf("%d", &n);
    citire1(v1,n);
    citire2(v2,n);
    if(egal(v1,v2,n))
       printf("elementele sunt egale");
    else
        printf("elementele nu sunt egale");
    return 0;
}
