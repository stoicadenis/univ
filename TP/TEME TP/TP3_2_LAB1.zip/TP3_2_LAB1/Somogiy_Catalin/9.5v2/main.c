#include <stdio.h>
#include <stdlib.h>
int egal(int v1[],int v[],int k)
{
    int i;
    for(i=0;i<k;i++)
    {
        if(v1[i]!=v[i])
            return 0;
    }
        return 1;
}
int main()
{
    int i,j,n,m,k,cont,x,ok=0;
    float a[9][9],v[4],v1[4];
    scanf("%d %d %d",&m,&n,&k);
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        scanf("%f",&a[i][j]);
        scanf("\n");
    }
    for(i=0;i<k;i++)
        scanf("%f",&v[i]);
    for(i=0;i<m;i++)
    for(j=0;j<n;j++)
    {
        cont=0;
        if(a[i][j]==v[cont])
        {
            x=j;
            for(cont=0;cont<k;cont++)
            {
                v1[cont]=a[i][x];
                x++;
            }
            if(egal(v1,v,k))
            {
                 printf("%d %d\n",i,j);
                 ok=1;
            }

        }
    }
    if(ok==0)
        printf("Secventa nu a fost gasita");
    return 0;
}
