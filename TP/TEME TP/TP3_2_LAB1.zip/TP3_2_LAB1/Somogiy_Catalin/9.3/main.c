#include <stdio.h>
#include <stdlib.h>
void swap(int *a,int *b)
{
    int aux;
    if(*a<*b)
    {
        aux=*a;
        *a=*b;
        *b=aux;
    }
}
int main()
{
    int a,b;
    scanf(" %d %d",&a,&b);
    swap(&a,&b);
    printf(" %d %d",a,b);
    return 0;
}
