#include <stdio.h>
#include <stdlib.h>
void m(int v[],int n)
{
    int imax=0,imin=0,min,max,i;
    min=max=v[0];
    for(i=1;i<n;i++)
    {
        if(v[i]>max)
        {
            max=v[i];
            imax=i;
        }
        if(v[i]<min)
        {
            min=v[i];
            imin=i;
        }

    }
    printf("%d %d",imin,imax);
}
int main()
{
    int v[10],i,n;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf(" %d ",&v[i]);
    m(v,n);
    return 0;
}
