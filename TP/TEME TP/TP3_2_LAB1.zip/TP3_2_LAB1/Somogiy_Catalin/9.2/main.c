#include <stdio.h>
#include <stdlib.h>
float maxim(float a,float b)
{
    if(a>b)
        return a;
    else return b;
}
int main()
{
    float a,b,c,max;
    scanf(" %f %f %f",&a,&b,&c);
    max=maxim(a,maxim(b,c));
    printf("%f",max);
    return 0;
}
