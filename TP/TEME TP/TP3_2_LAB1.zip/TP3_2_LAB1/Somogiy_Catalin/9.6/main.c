#include <stdio.h>
#include <stdlib.h>
int cmmdc(int a,int b)
{
    if(a==b)
    return a;
    if(a>b)
    return cmmdc(a-b,b);
    if(a<b)
    return cmmdc(a,b-a);
}
int euclid(int a, int b)
{
    int c;
    while (b) {
        c = a % b;
        a = b;
        b = c;
    }
    return a;
}
int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d\n",euclid(a,b));
    printf("%d",cmmdc(a,b));
    return 0;
}
