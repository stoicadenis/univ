#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>

int egal(int a[9][9], int m, int n, int v[9], int k)
{
	int cont = 0, tempResult = 0;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (a[i][j] == v[cont])
			{
				for (int x = i + 1; x <= k; x++)
				{
					cont++;
					if (a[i][x] == v[cont])
					{
						printf("\n\n%d %d", i + 1, j + 1);
						if ((cont + 1) == k)
						{
							tempResult = 1;
							break;
						}
					}
					else
						break;
				}
			}
		}
	}
	return tempResult;
}

int main()
{
	int m, n, k, result = 0;
	float a[9][9], v[9];

	do
	{
		printf("\nIntroduceti numarul m mai mic decat 10: ");
		scanf("%d", &m);
	} while (m > 10);

	do
	{
		printf("\nIntroduceti numarul n: ");
		scanf("%d", &n);
	} while (n > 10 && n < 3);

	printf("\nIntroduceti elementele matricii: ");
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			scanf("%f", &a[i][j]);
		}
	}

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			printf(" %f ", a[i][j]);
		}
		printf("\n");
	}
		
	do
	{
		printf("\nIntroduceti numarul k: ");
		scanf("%d", &k);
	} while (k < 0 && k > 5);

	printf("\nIntroduceti elementele vectorului: ");
	for (int i = 0; i < k; i++)
	{
		scanf("%f", &v[i]);
	}

	result = egal(a, m, n, v, k);

	if (result)
	{
		printf("\nVectorul se gaseste in matrice. ");
	}
	else
	{
		printf("\nVectorul nu se gaseste in matrice. ");
	}

	system("pause");
	return 0;
}