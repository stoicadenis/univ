#include <stdlib.h>
#include <stdio.h>

float maxNumbers(int a, int b, int c)
{
	if (a > b)
	{
		return a > c ? a : c;
	}
	else
	{
		return b > c ? b : c;
	}
}

int main()
{
	float a, b, c;
	printf("\nIntroduceti primul numar: ");
	scanf("%f", &a);
	printf("\nIntroduceti al doilea numar: ");
	scanf("%f", &b);
	printf("\nIntroduceti al treilea numar: ");
	scanf("%f", &c);
	printf("\nNumarul maxim este: %f\n\n\n", maxNumbers(a, b, c));

	system("pause");
	return 0;