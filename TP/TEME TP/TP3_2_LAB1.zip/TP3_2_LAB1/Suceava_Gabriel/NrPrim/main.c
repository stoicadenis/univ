#include <stdio.h>
#include <stdlib.h>
int prim(int n)
{
    int d;
    if(n<2)
        return 0;
    if(n!=2 && n%2==0)
        return 0;
    for(d=3;d*d<n;d+=2)
        if(n%d==0)
        return 0;
    return 1;
}
int main()
{
    int n;
    scanf("%d",&n);
    if(prim(n))
        printf("Numarul este prim");
        else printf("Numarul nu este prim");
    return 0;
}
