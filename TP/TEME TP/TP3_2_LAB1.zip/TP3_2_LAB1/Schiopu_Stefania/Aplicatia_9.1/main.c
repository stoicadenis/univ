/*Se cere un numar impar n>4. Sa se deseneze cifra �8�, scris ca un patrat cu o linie orizontala in mijloc,
in asa fel incat pe verticala si pe orizontala sa fie cate n stelute. In program nu vor fi admise duplicari
de cod.*/

#include <stdio.h>
#include <stdlib.h>


void linie_orizontala(int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("*");
    printf("\n");
}

void linie_spatii(int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(i==0 || i==n-1)
            printf("*");
        else
            printf(" ");
    }
    printf("\n");
}

int Validare_n(int n)
{
    if(n>4 && (n%2!=0))
        return 1;
    else
        return 0;
}
int main()
{
    int n,valid,i;
    printf("Introduceti numarul n: ");
    scanf("%d",&n);
    valid=Validare_n(n);
    if(valid==0)
        printf("Valoarea introdusa nu este valida! Numarul trebuie sa fie strict mai mare decat 4 si impar.\n");
    else
    {
        for(i=0;i<n;i++)
            if(i==0 || i==n/2 || i==n-1)
                linie_orizontala(n);
            else
                linie_spatii(n);
    }

   system("pause");
   return 0;
}
