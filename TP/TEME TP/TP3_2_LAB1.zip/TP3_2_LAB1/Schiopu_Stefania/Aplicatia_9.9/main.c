/*Scrieti o functie care parcurge un vector si returneaza indicii elementelor minim si maxim.*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 20

int Returneaza_poz_max(int vect[MAX],int n)
{
    int i,max;
    max=vect[0];
    for(i=1;i<n;i++)
        {
            if(vect[i]>max)
                max=vect[i];
        }
    for(i=0;i<n;i++)
        {
            if(vect[i]==max)
                return i;
        }
}

int Returneaza_poz_min(int vect[MAX],int n)
{
    int i,min;
    min=vect[0];
    for(i=1;i<n;i++)
        {
            if(vect[i]<min)
                min=vect[i];
        }
    for(i=0;i<n;i++)
        {
            if(vect[i]==min)
                return i;
        }
}

void Citire_vector(int vect[MAX],int n)
{
    int i;
    for(i=0;i<n;i++)
        {
            printf("vect[%d]=",i);
            scanf("%d",&vect[i]);
        }

}

int main()
{
    int n,poz_max,poz_min,vect[MAX];
    printf("Introduceti numarul de elemente ale vectorului: ");
    scanf("%d",&n);
    Citire_vector(vect,n);
    poz_max=Returneaza_poz_max(vect,n);
    poz_min=Returneaza_poz_min(vect,n);
    printf("Pozitia elementului minim este %d.\nPozitia elementului maxim este %d.\n",poz_min,poz_max);
    system("pause");
    return 0;
}
