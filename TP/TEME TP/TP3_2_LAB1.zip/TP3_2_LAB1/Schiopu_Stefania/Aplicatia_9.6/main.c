/*ALGORITMUL LUI EUCLID*/

#include <stdio.h>
#include <stdlib.h>

int AlgEuclid(int,int);

int main() {
	int a,b,c;
	printf("Introduceti cele doua numere: ");
	scanf("%d %d",&a,&b);
	c=AlgEuclid(a,b);
	printf("Cel mai mare divizor comun este %d\n", c);
	system("pause");
	return 0;
}

int AlgEuclid(int m, int n)  {
	int cmmdc, rest;
	rest = m%n;
	while (rest != 0)  {
		m = n;
		n = rest;
		rest = m%n;
	}
	cmmdc = n;
	return n;
}
