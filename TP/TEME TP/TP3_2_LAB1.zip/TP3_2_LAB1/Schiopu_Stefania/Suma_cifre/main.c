#include <stdio.h>
#include <stdlib.h>

int Suma_cifre(int nr)
{
    int sum=0;
    while(nr!=0)
    {
        sum=sum+(nr%10);
        nr=nr/10;
    }
    return sum;
}


int main()
{
    int suma,numar;
    printf("Introduceti un numar: ");
    scanf("%d",&numar);
    suma=Suma_cifre(numar);
    printf("Suma cifrelor numarului este %d\n",suma);
    system("pause");
    return 0;
}
