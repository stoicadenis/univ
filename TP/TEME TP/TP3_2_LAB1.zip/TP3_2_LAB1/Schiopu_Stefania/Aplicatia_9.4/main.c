/*Sa se scrie intr-un program care citeste un numar n<10, iar apoi citeste 2 vectori v1 si v2
de cate n elemente de tip int. Pentru citirea elementelor unui vector se foloseste o functie citire(v,n).
Se va implementa o functie egal(v1,v2,n), care testeaza daca toate elementele din v1 sunt egale cu cele din v2
la pozitii corespondente.*/

#include <stdio.h>
#include <stdlib.h>

int Validare_n(int n)
{
    if(n<10 && n>0)
        return 1;
    else
        return 0;
}

void Citire(int v[20],int n)
{
    int i;
    for(i=0;i<n;i++)
        {
            printf("v[%d]=",i);
            scanf("%d",&v[i]);
        }
    printf("\n");
}

int Egal(int v1[20],int v2[20],int n)
{
    int i,j;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            {
                if(i==j)
                    if(v1[i]==v2[j])
                        {
                            return 1;
                        }
                    else
                    {
                        return 0;
                        break;
                    }
            }

}

int main()
{
    int n,valid,vect1[20],vect2[20],egal;
    printf("Introduceti numarul n: ");
    scanf("%d",&n);
    valid=Validare_n(n);
    if(valid==0)
        printf("Numarul nu este valid! Trebuie sa fie pozitiv si strict mai mic decat 10.\n");
    else
    {
        Citire(vect1,n);
        Citire(vect2,n);
        egal=Egal(vect1,vect2,n);
        if(egal==0)
            printf("Vectorii NU au elementele egale.\n");
        else
            printf("Vectorii au elementele egale.\n");
    }
    system("pause");
    return 0;
}
