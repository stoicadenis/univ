#include <stdio.h>
#include <stdlib.h>

int Numar_cifre_pare(int nr)
{
    int numarare=0;
    while(nr!=0)
    {
        if((nr%10)%2==0)
        {
            numarare=numarare+1;
        }
        nr=nr/10;
    }
    return numarare;
}


int main()
{
    int num,numar;
    printf("Introduceti un numar: ");
    scanf("%d",&numar);
    num=Numar_cifre_pare(numar);
    printf("Numarul cifrelor pare este %d.\n",num);

    system("pause");
    return 0;
}
