/*Se citesc numerele m<10, 3<n<10 si apoi elementele de tip float ale unei matrici a[m][n]. Ulterior, se va
citi un numar 0<k<5 si apoi elementele de tip float ale unui vector v[k]. Sa se afiseze toate pozitiile
unde vectorul v se gaseste in liniile matricii. De exemplu, daca v incepe in matrice la pozitia
a[i][j], se va afisa (i,j). Daca vectorul nu a fost gasit in nicio linie, se va afisa un mesaj
corespunzator. Pentru testarea egalitatii elementelor se va folosi functia egal, definita
la aplicatia 9.4.*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 20
 //m=coloane
 //n=linii


void Citire_matrice(float matr[MAX][MAX],int m,int n)
{
    int i,j;
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
        {
            printf("matr[%d][%d]=",i,j);
            scanf("%f",&matr[i][j]);
        }
}


void Citire_vect(float vect[MAX],int e)
{
    int i;
    for(i=0;i<e;i++)
    {
        printf("vect[%d]=",i);
        scanf("%f",&vect[i]);
    }
}

void Egal(float matr[MAX][MAX],float vect[MAX],int e,int m,int n)
{
    int i,j,k;
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
        {
            for(k=0;k<e;k++)
                if(matr[i][j]==vect[k]) //daca un element al vectorului se gaseste in matrice, se va afisa pozitia in matrice la care se gaseste
                    printf("Elementul %f al vectorului se gaseste in matrice la pozitia (%d,%d).\n",vect[k],i,j);
        }

}

int main()
{
    int linii,coloane,elem;
    float vect[MAX],matr[MAX][MAX];
    printf("Introduceti numarul de linii: ");
    scanf("%d",&linii);
    printf("Introduceti numarul de coloane: ");
    scanf("%d",&coloane);
    printf("Introduceti numarul de elemente din vector: ");
    scanf("%d",&elem);
    Citire_matrice(matr,linii,coloane);
    Citire_vect(vect,elem);
    Egal(matr,vect,elem,linii,coloane);

    system("pause");
    return 0;

}
