/*Sa se scrie o functie care returneaza 2 valori pe care le citeste de la tastatura,
sortate in mod crescator. Se va verifica functia.*/

#include <stdio.h>
#include <stdlib.h>

int Returneaza(int a, int b)
{
    if(a>b)
        return a;
    else
        return b;
}

int main()
{
    int max,nr1,nr2;
    printf("Introduceti cele 2 numere: ");
    scanf("%d %d",&nr1,&nr2);
    max=Returneaza(nr1,nr2);
    if(max==nr1)
        printf("%d %d\n",nr1,nr2);
    else
        printf("%d %d\n",nr2,nr1);
    system("pause");
    return 0;
}
