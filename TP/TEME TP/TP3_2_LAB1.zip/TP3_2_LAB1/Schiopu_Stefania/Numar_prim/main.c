#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int Numar_prim(int n)
{
    int i,aux=0;
    for (i = 2; i <= sqrt(n); i++)
		{
			if (n%i == 0)
				aux = aux + 1;
		}
	if (aux == 0)
    {
        return 1;
    }
	else
    {
        return 0;
    }
}
int main()
{
	int nr,prim;
	printf("Introduceti numarul:\n");
	scanf("%d", &nr);
	prim=Numar_prim(nr);
	if(prim==1)
        printf("Numarul este prim\n");
    else
        printf("Numarul NU este prim\n");

	system("pause");
	return 0;
}
