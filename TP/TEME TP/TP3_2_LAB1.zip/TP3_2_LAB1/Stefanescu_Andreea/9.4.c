#include <stdio.h>
#include <stdlib.h>

void citire(int v1[],int v2[],int n)
{
int i,j;
    for(i=0;i<=n;i++)
    {
        printf("v1[%d]=",i);
        scanf("%d",&v1[i]);
    }
    for(j=0;j<=n;j++)
    {
        printf("v2[%d]=",j);
        scanf("%d",&v2[j]);
    }
}
void egal(int v1[],int v2[],int n)
{

 int i,j;
    for( i=0;i<=n;i++)

        for( j=0;j<=n;j++)
        {
        if(v1[i]!=v2[j])
            printf("Vectorii nu sunt egali");

        else
            if(v1[i]=v2[j])

    printf("Vectorii au aceleasi valori pe aceleasi pozitii");
        }

}
int main()
{
    int n;
    int v1[10],v2[10];
    printf("n=");
    scanf("%d",&n);
    if(n>10)

    printf("n este prea mare");

    citire(v1,v2,n);
    egal(v1,v2,n);
    return 0;
}


