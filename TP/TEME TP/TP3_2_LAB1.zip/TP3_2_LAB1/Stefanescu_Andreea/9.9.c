#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int maxim(int v[], int n)
{
	int i,max;
	max= v[0];
	for ( i = 0; i <= n; i++)
	{
		if (v[i] > max)
		{
			max = v[i];
		}
	}
	return max;
}
int minim(int v[], int n)
{
	int i,min;
	min = v[0];
	for ( i = 0; i <= n; i++)
	{
		if (v[i] < min)
		{
			min = v[i];
		}
	}
	return min;
}
int pozitie(int min, int max, int v[], int n)
{
    int i;
	for ( i = 0; i <= n; i++)
	{
		if (min == v[i])
		{
			printf("Minimul se gaseste pe pozitia %d a vectorului\n", i);
		}
		if (max == v[i])
		{
			printf("Maximul se gaseste pe pozitia %d a vectorului\n", i);
		}
	}
}
int main()
{
    int i,n,v[20];
	printf(" n=");
	scanf("%d", &n);
	for ( i = 0; i <= n; i++)
	{
		printf(" \nv[%d]=", i);
		scanf("%d", &v[i]);
	}
	 minim(v, n);
	 maxim(v, n);
	pozitie(minim(v, n),maxim(v, n) , v, n);
	return 0;
}
