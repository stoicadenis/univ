
#include <stdio.h>
#include<stdlib.h>
int pare(int n)
{
 int nr=0;
  if(n==0) return 0;
  else
      if((n%10)%2==0)
return pare(n/10)+1;
return pare(n/10);
}
int main()
{
    int x;
    printf("Dati nr= ");
    scanf("%d",&x);
    pare(x);
    printf("Nr are %d cifre pare",pare(x));
    return 0;
}

