#include <stdio.h>
#include <stdlib.h>
/* nr prim iterativ*/

void prim(int x)
{
    int d=2;
    while(d<=x/2 && x%d!=0)
          {


        d=d+1;
          }
    if(d>x/2 && x>1) printf("Nr e prim");
    else printf("Nr nu e prim");
}

int main()
{
    int n;
    printf("n=");
    scanf("%d",&n);
    prim(n);
    return 0;
}

