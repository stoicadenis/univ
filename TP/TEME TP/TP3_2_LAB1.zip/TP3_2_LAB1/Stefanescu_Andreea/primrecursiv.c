#include <stdio.h>
#include <stdlib.h>
/* nr prim recursiv*/

int prim(int x,int d)
{
if(d==1) return 1;

if(x%d==0) return 0;
else return prim(x,d-1);
}

int main()
{
    int n;
    printf("n=");
    scanf("%d",&n);

    if (prim(n,n/2)==1)
        printf("Nr e prim");
        else
        printf("Nr nu e prim");
    return 0;
}


