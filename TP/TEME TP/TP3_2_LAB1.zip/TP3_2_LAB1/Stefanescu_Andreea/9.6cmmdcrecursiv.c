/*cmmdc recursiv*/
#include <stdio.h>
#include <stdlib.h>
int cmmdc(int x,int y)
{
    if(y==0)
        return x;
    else
        if(x>y)

     return cmmdc(x-y,y);
    if(x<y)
        return cmmdc(x,y-x);



}
int main()
{
    int a,b;
    printf("Dati a= ");
    scanf("%d",&a);
    printf("Dati b= ");
    scanf("%d",&b);
    cmmdc(a,b);
    printf("%d ",cmmdc(a,b));
    return 0;

}





