#include <stdio.h>
#include <stdlib.h>
void verifica(int x,int y)
{
    if(x<y)
    {
    printf(" %d",x);
    printf(" %d",y);
    }
    if(y<x)
    {
    printf("%d",y);
    printf(" %d",x);
    }
}
int main()
{
    int a,b;
    printf("a=");
    scanf("%d",&a);
    printf("b=");
    scanf("%d",&b);
    verifica(a,b);
    return 0;
}
