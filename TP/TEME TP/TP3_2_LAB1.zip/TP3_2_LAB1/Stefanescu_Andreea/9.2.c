/*Aplicatia 9.2*/
#include<stdio.h>
int maxim(int x,int y)
{
    if(x>y)return x;
    return y;
}
int main()
{
    int nr1,nr2,nr3;
    printf("Dati nr1= ");
    scanf("%d",&nr1);
    printf("Dati nr2=");
    scanf("%d",&nr2);
    printf("Dati nr3=");
    scanf("%d",&nr3);
    printf("%d",maxim(maxim(nr1,nr2),nr3));
}
