/*Ackermann*/
#include <stdio.h>
#include <stdlib.h>
int ack(int m, int n)
{
  if (m == 0) return n+1;
  if ((n == 0) && (m>0)) return ack( m - 1, 1 );
  if((n>0)&&(m>0)) return ack( m - 1, ack( m, n - 1 ) );
}
int main()
{
int n,m;
printf("Dati n=");
scanf("%d",&n);
printf("Dati m=");
scanf("%d",&m);
ack(m,n);
printf("%d",ack(m,n));
return 0;
}
