
/*cmmdc iterativ*/
#include <stdio.h>
#include <stdlib.h>
void cmmdc(int x,int y)
{
    int r;
    while(y!=0)
    {
        r=x%y;
        x=y;
        y=r;
    }
    printf("%d",x);

}
int main()
{
    int a,b;
    printf("Dati a= ");
    scanf("%d",&a);
    printf("Dati b= ");
    scanf("%d",&b);
    cmmdc(a,b);
    return 0;

}
