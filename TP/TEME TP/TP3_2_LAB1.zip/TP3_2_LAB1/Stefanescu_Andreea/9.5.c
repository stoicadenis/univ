#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int gaseste(float a[20][20], float v[], int l, int c, int e)
{
    int i,j,k;
	for ( i = 0; i <= l; i++)
	{
		for ( j = 0; j <= c; j++)
		{
			for ( k = 0; k <= e; k++)
			{
				if (a[i][j] == v[k])
				{
					printf(" \n(%d,%d)", i, j);
				}
				else printf("Nu se regaseste vectorul in matrice ")
			}
		}
	}
	printf("\n");
}
int main()
{
    int m,n,x,i,j,k;
    float a[20][20];
    float v[20];
	printf(" m<10=");
	scanf("%d",&m);
	printf(" 3<n<10=");
	scanf("%d",&n);
	for ( i = 0; i <= m; i++)
	{
		for ( j = 0; j <= n; j++)
		{
			printf(" \na[%d][%d]=", i, j);
			scanf("%f", &a[i][j]);
		}
	}
	printf(" 0<x<5=");
	scanf("%d", &x);
	for (k= 0; k <= x; k++)
	{
		printf(" \nv[%d]=", k);
		scanf("%f", &v[k]);
	}
	gaseste(a,v, m, n, x);
	return 0;
}
