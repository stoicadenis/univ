#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int func(float x0, float x1, float y0, float y1)
{
	float A;
	A = (x0,y0) - (x1,y1);
	return atan(A);
}
int main()
{
    float xa, xb, ya, yb;
	printf(" xa=");
	scanf("%f", &xa);
	printf(" xb=");
	scanf("%f", &xb);
	printf(" ya=");
	scanf("%f", &ya);
	printf("yb= ");
	scanf("%f", &yb);
        func(xa,xb,ya,yb);
	printf(" Unghiul dintre dreapta formata de coordonatele xa,xb,ya,yb si Ox are %f* ",func(xa,xb,ya,yb) );

	return 0;
}
