#include <stdio.h>
#include <stdlib.h>
int sumacifre(int n)
{
    if(n==0)
        return 0;
    else
    return sumacifre(n/10)+n%10;

   }


int main()
{
    int n;
    printf("Dati n=");
    scanf("%d",&n);
    sumacifre(n);
    printf("Suma cifrelor este %d",sumacifre(n));
    return 0;
}

