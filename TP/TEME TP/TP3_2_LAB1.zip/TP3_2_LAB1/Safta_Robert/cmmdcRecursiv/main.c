#include <stdio.h>
#include <stdlib.h>

 int cmmdc(int a,int b)
     {
      if (b==0)

           b = a;
      else
            cmmdc(b,a%b);

        }
int main()
{
    int a,b,c;
    scanf(" %d %d",&a,&b);
    c=cmmdc(a,b);
    printf("%d",c);
    return 0;
}
