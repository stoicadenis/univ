#include <stdio.h>
#include <stdlib.h>
int sumacif(long n)
{
    if(n==0)
        return 0;
    else
        return sumacif(n/10)+n%10;
}
int main()
{
    int n,x;
    scanf("%d",&n);
    x=sumacif(n);
    printf("%d",x);
    return 0;
}
