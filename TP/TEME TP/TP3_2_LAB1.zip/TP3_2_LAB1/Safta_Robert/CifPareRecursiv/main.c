#include <stdio.h>
#include <stdlib.h>
int pare(int x)
{
    if(x<10 && x%2==0)
        return 1;
    else if(x<10) return 0;
    if(x%2==0)
        return 1+pare(x/10);
    else return pare(x/10);
}
int main()
{
    int x;
    scanf("%d",&x);
    printf("%d",pare(x));
    return 0;
}
