#include <stdio.h>
#include <stdlib.h>

int nrprim(int n)
{
    int i,ok=1;
    for(i=2; i*i<=n&&ok==1; i++)
    {
        if(n%i==0)
            ok=0;
    }
    if(ok==1)  return 1;

    return 0;

}
int main()
{
    int n;
    scanf("%d",&n);
    if(nrprim(n)) printf("Nr prim");
      else printf("Nr nu este prim");
    return 0;
}
