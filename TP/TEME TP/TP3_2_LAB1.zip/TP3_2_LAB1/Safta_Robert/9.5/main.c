#include <stdio.h>
#include <stdlib.h>

int egal (float v1[],float v2[],int x)
{
    int i;
    for(i=0;i<x;i++)
    {
        if(v1[i]!=v2[i]) return 0;
    }
        return 1;
}

int main()
{

    int i,j,x,k=0,ok=0,n,m,y;
    float a[11][11],v[5],v1[5];
    scanf("%d %d %d",&m,&n,&y);
    for(i=0;i<m;i++)
    {
         for(j=0;j<n;j++)
            scanf("%f",&a[i][j]);
         scanf("\n");
    }        for(i=0;i<y;i++)
            scanf("%f",&v[i]);

        for(i=0;i<m;i++)
        for(j=0;j<n;j++)
        {
            if(a[i][j]==v[k])
            {
                x=j;
                for(k=0;k<y;k++)
                {
                    v1[k]=a[i][x];
                    x++;
                }
                if(egal(v1,v,y))
                {
                    printf("%d %d \n",i,j);
                    ok=1;
                }
            }
        }

        if(ok==0) printf("Vectorul nu a fost gasit");

    return 0;
}
