#include <stdio.h>
#include <stdlib.h>
float maxi(float x,float y)
{
    if(x>y)
        return x;
return y;
}
int main()
{
    float x,y,z,maxim;
    scanf(" %f %f %f",&x,&y,&z);
    maxim=maxi(x,maxi(y,z));
    printf("%f",maxim);
    return 0;
}
