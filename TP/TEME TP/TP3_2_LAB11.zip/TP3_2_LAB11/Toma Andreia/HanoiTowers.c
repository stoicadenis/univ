#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

void towerOfHanoi(int n, char tija1, char tija2, char tija_aux)
{
	if (n == 1)
	{
		printf("\n Muta discul 1 de pe tija %c pe tija %c", tija1, tija2);
		return;
	}
	towerOfHanoi(n - 1, tija1, tija_aux, tija2);
	printf("\n Muta discul %d de pe tija %c pe tija %c", n, tija1, tija2);
	towerOfHanoi(n - 1, tija_aux, tija2, tija1);
}


int main()
{
	int n;
	printf("Dati nr de discuri:");
	scanf("%d", &n);
	towerOfHanoi(n, 'A', 'C', 'B');  // A, B and C are names of rods 
	_getch();
	return 0;
}