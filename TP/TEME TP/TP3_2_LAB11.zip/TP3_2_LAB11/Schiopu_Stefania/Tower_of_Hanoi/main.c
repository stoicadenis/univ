/*TURNURILE HANOI*/

/*Functie recursiva*/

#include <stdio.h>
#include <stdlib.h>

void functie_Hanoi(int n, char tija1, char tija_inter, char tija2)//fr=from rod,tr =to rod, ar=aux rod
{
    if (n == 1)
    {
        printf("Mutam discul 1 de pe tija %c pe tija %c\n", tija1, tija_inter);
        return;
    }
    functie_Hanoi(n-1, tija1, tija2, tija_inter);
    printf("Mutam discul %d de pe tija %c pe tija %c\n", n, tija1, tija_inter);
    functie_Hanoi(n-1, tija2, tija_inter, tija1);
}

int main()
{
    int n = 4; // n reprezinta numarul de discuri

    //in cazul in care dorim sa introducem de la tastatura numarul de discuri, punem in aplicare cele doua functii de mai jos
    /*
    printf("Introduceti numarul de discuri pentru care vreti sa aplicati functia\n\tn=");
    scanf("%d",&n);
    */

    functie_Hanoi(n, 'A', 'C', 'B');  // A, B si C reprezinta numele tijelor

    system("pause");
    return 0;
}
