/*Se da un vector v cu n elemente numere naturale ordonate crescator, maximum 1000 elemente de 9 cifre. Sa se caute un element
cu valoarea x in acest tablou. Implementam cautarea binara.*/

#include <stdio.h>
#include <stdlib.h>

int cautare_binara(int v[], int n, int x)
{
    int s, d, m;
    s = 0;
    d = n - 1;
    do
    {
        m = (s + d)/2;
        if(x > v[m])
            s = m + 1;
        else
            d = m - 1;
    } while(v[m] != x && s <= d);
    return m;
}

int main()
{
    int v[]={11, 134, 146, 235, 277, 300, 346, 436, 512, 549, 599, 601, 768, 855, 999, 1050}, n = 16, x, pozitie_elem_gasit;
    printf("Introduceti elementul cautat x=");
    scanf("%d", &x);
    pozitie_elem_gasit = cautare_binara(v, n, x);
    printf("\nElementul cautat se afla la pozitia %d.\n", pozitie_elem_gasit);

    system("pause");
    return 0;
}
