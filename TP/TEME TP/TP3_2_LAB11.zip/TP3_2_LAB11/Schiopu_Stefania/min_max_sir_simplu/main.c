/*Determinarea minimului si maximului dintr-un sir de numere
Enunt:
Se da un sir de n numere reale {x[0], x[1], �, x[n-1]}. Sa se determine valoarea minima si valoarea maxima din acest sir de numere.
Rezolvare: metoda imediata de rezolvare este parcurgerea intregului sir si inspectarea fiecarui element de doua ori,
o data pentru aflarea minimului si a doua oara pentru aflarea maximului.*/

#include <stdio.h>
#include <stdlib.h>

/*Declaram sirul de numere direct din cod. Alternativ el poate fi citit de la tastatura sau din fisier.*/

#define N 10

int x[] = { 10, 5, 23, -11, 4, 2, 0, -6, 66, 40 };

int main(void)
{
/*Folosim doua variabile pentru a stoca minimul si maximul gasite.*/
    int min, max;
/*Vom contoriza numarul de comparatii care se fac  pentru gasirea minimului si maximului.*/
    int comp = 0;
    int i;
    printf("Avem %d numere.\n", N);
    for (i = 0; i < N; i++)
        printf("%d ", x[i]);     /*Afisam sirul de numere.*/
    printf("\n\n");
/*Initializam minimul si maximul cu prima valoare din sir.*/
    min = x[0];
    max = x[0];
/*Parcurgem intreg sirul si actualizam minimul si maximul atunci cand e cazul.*/
    for (i = 1; i < N; i++)
    {
/*Facem o comparatie pentru minim.*/
        comp++;
        if (min > x[i])
            min = x[i];
/*Si o comparatie pentru maxim.*/
        comp++;
        if (max < x[i])
            max = x[i];
    }
/*Afisam rezultatele.*/
    printf("Minimul este %d.\n", min);
    printf("Maximul este %d.\n", max);
    printf("Comparatii facute: %d.\n", comp);

    system("pause");
    return 0;
}

/*Daca analizam metoda de mai sus, vom vedea ca ea face comparatii inutile, deoarece orice element care este candidat pentru minim nu poate fi
in acelasi timp candidat pentru maxim si invers. Deci este redundant sa testam fiecare element in parte atat pentru minim cat si pentru maxim.*/

