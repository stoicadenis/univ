#include <stdio.h>
/*#define NUMAR 10

int x[] = { 10, 5, 23, -11, 4, 2, 0, -6, 66, 40 };
int compmin = 0, compmax = 0;

void gasesteminim(int st, int dr, int* min) {
	int mijloc, min_st, min_dr;
	printf("Caut in secventa [%d..%d].\n", st, dr);
	if (st == dr) {
		*min = x[st];
	}
	else if (st == dr - 1) {
		compmin++;
		if (x[st] < x[dr]) {
			*min = x[st];
		}
		else {
			*min = x[dr];
		}
	}
	else {
		mijloc = (st + dr) / 2;
		gasesteminim(st, mijloc, &min_st);
		gasesteminim(mijloc + 1, dr, &min_dr);
		compmin++;
		if (min_st < min_dr)
			*min = min_st;
		else
			*min = min_dr;
	}
}

void gasestemaxim(int st, int dr, int* max) {
	int mijloc, max_st, max_dr;
	printf("Caut in secventa [%d..%d].\n", st, dr);
	if (st == dr) {
		*max = x[st];
	}
	else if (st == dr - 1) {
		compmax++;
		if (x[st] < x[dr]) {
			*max = x[dr];
		}
		else {
			*max = x[st];
		}
	}
	else {
		mijloc = (st + dr) / 2;
		gasestemaxim(st, mijloc, &max_st);
		gasestemaxim(mijloc + 1, dr, &max_dr);
		compmax++;
		if (max_st > max_dr)
			*max = max_st;
		else
			*max = max_dr;
	}
}

int main(void) {
	int min, max, i;
	printf("Avem %d numere.\n", NUMAR);
	for (i = 0; i < NUMAR; i++)
		printf("%d ", x[i]);
	printf("\n\n");
	gasesteminim(0, NUMAR - 1, &min);
	printf("\n\n");
	gasestemaxim(0, NUMAR - 1, &max);
	printf("\n");
	printf("Minimul este %d.\n", min);
	printf("Comparatii facute: %d.\n", compmin);
	printf("Maximul este %d.\n", max);
	printf("Comparatii facute: %d.\n", compmax);

	return 0;
}*/