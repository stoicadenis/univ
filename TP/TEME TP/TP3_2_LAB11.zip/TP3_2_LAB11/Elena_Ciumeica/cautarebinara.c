#include<stdlib.h>
#include<stdio.h>

#define NUMAR 1000

int x[] = { -11, -6, 0, 2, 4, 5, 10, 23, 40, 66 };

int cautareBinara(int a[], int s, int d, int x) {
	int m;
	if (s == d && x > a[d]) {
		return d;
	} else if (s < d) {
		m = (s + d) / 2;
		if (x > a[m]) {
			s = m + 1;
		}
		else {
			d = m;
		}
		cautareBinara(a, s, d, x);
	} else {
		return -1;
	}
}

int main() {
	int n = 10, caut = 3;
	/*
	int i;
	printf("Cite valori va contine vectorul? ");
	scanf("%d", &n);
	printf("Introduceti valorile vectorului in ordine crescatorare:\n");
	for (i = 0; i < n; i++)
	{
		scanf("%d", &x[i]);
	}
	printf("Ce numar doriti sa cautati? ");
	scanf("%d", &caut);
	*/
	int s = 0, d = n - 1, rez;

	rez = cautareBinara(x, s, d, caut);
	if (rez != -1) {
		printf("Numarul %d se afla pe pozitia %d\n", caut, rez);
	}
	else {
		printf("Numarul nu a fost gasit\n");
	}

	return 0;
}