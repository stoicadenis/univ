#include <stdio.h>

#define N 20


int secventa[N];
int k=0; // numarul de comparatii in total

// functia pentru cautarea minimului si maximului din secventa de numere

void search(int *min, int *max, int left, int right)
{
    int mid, min_left, min_right, max_left, max_right;
    printf("\n Stanga: %d\n Dreapta:%d\n", left, right);
    if(left==right) {
        // in secventa exista o singura valoare
        *min=secventa[left];
        *max=secventa[right];
    }
    else if(left=right-1) {
        // in secventa exista doar 2 valori
        // a avut loc o comparare
        k++;
        if(secventa[left]<secventa[right]) {
            *min=secventa[left];
            *max=secventa[right];
        }
        else {
            *min=secventa[right];
            *max=secventa[left];
        }
    }
    else {
        // secventa contine mai multe numere -> problema va fi impartita in subprobleme
        mid=(left+right)/2;
        search(&min_left, &max_left, left, mid);
        search(&min_right, &max_right, mid+1, right);
        // se compara minimul si maximul de stanga si dreapta intre ele
        // creste numarul de comparatii
        k++;
        if(min_left>min_right)
            *min=min_right;
        else *min=min_left;
        // se realizeaza inca o comparatie
        k++;
        if(max_left<max_right)
            *max=max_right;
        else *max=max_left;
    }
}



int main(void)
{
    int i, min, max, n;
    printf("Cate numere are secventa? - ");
    scanf("%d", &n);
    // citire valori secventa
    printf("Introduceti numerele:\n");
    for(i=0; i<n; i++)
        scanf("%d", &secventa[i]);
    // afisarea numerelor
    for(i=0; i<n; i++)
        printf("%4d", secventa[i]);
    printf("\n\n");
    // apelam functia recursiva *search*
    search(&min, &max, 0, n-1);
    // afisarea minimului gasit
    printf("\nMinimul gasit in secventa este: %d\n", min);
    // afisarea maximului
    printf("\nMaximul gasit in secventa este: %d\n", max);
    // afisarea numarului de comparatii realizate
    printf("\nAu fost realizare %d comparatii.\n", k);
}
