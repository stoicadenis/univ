#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void hanoi(int n, char ti, char tf, char tm)
// ti - tija initiala, tm - tija intermediara, tf - tija finala
{
    if (n > 1) {
        // n>1 -> mai multe discuri -> se descompune problema in subprobleme
        hanoi(n - 1, ti, tm, tf);
        printf("\t%c - %c\n", ti, tf);
        hanoi(n - 1, tm, tf, ti);
    }
    else
        // exista un singur disc -> se face o singura mutare
        printf("\t%c - %c\n", ti, tf);
}

int main()
{
    int n;
    char ti, tm, tf, tija1, tija2;
    printf("Cate discuri vor fi? - ");
    scanf("%d", &n);
    printf("Pe care tija vor fi discurile la inceput?\n");
    printf("\ta) 1\n\tb) 2\n\tc) 3\n");
    getchar();
    scanf("%c", &tija1);
    printf("Care va fi tija intermediara?\n");
    getchar();
    if (tija1 == 'a') {
        ti = '1';
        printf("\ta) 2\n\tb) 3\n");
        scanf("%c", &tija2);
        if (tija2 == 'a') {
            tm = '2';
            tf = '3';
        }
        else {
            tm = '3';
            tf = '2';
        }
    }
    else if (tija1 == 'b') {
        ti = '2';
        printf("\ta) 1\n\tb) 3\n");
        scanf("%c", &tija2);
        if (tija2 == 'a') {
            tm = '1';
            tf = '3';
        }
        else {
            tm = '3';
            tf = '1';
        }
    }
    else {
        ti = '3';
        printf("\ta) 1\n\tb) 2\n");
        scanf("%c", &tija2);
        if (tija2 == 'a') {
            tm = '1';
            tf = '2';
        }
        else {
            tm = '2';
            tf = '1';
        }
    }
    hanoi(n, ti, tf, tm);
    system("pause");
    return 0;
}
