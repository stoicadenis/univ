#include <stdio.h>
#include <stdlib.h>
void minmax(int x[], int st, int dr, int *min, int *max, int comp)
{
	int mijloc, min_st, max_st, min_dr, max_dr;
	printf("Caut in secventa [%d..%d].\n", st, dr);
	if (st == dr)
	{
		*min = x[st];
		*max = x[st];
	}
	else
		if (st == dr - 1)
		{
			comp++;
			if (x[st] < x[dr])
			{
				*min = x[st];
				*max = x[dr];
			}
			else
			{
				*min = x[dr];
				*max = x[st];
			}
		}
		else
		{
			mijloc = (st + dr) / 2;
			minmax(x, st, mijloc, &min_st, &max_st, comp);
			minmax(x, mijloc + 1, dr, &min_dr, &max_dr, comp);
			comp++;
			if (min_st < min_dr)
				*min = min_st;
			else
				*min = min_dr;
			comp++;
			if (max_st > max_dr)
				*max = max_st;
			else
				*max = max_dr;
		}
}
int main()
{
	int x[10], min, max, i, comp = 0, n;
	printf("n="); scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		printf("x[%d]=", i);
		scanf("%d", &x[i]);
	}
	minmax(x, 0, n - 1, &min, &max, comp);
	printf("Minimul este %d.\n", min);
	printf("Maximul este %d.\n", max);
	printf("Comparatii facute: %d.\n", comp);
	return 0;
}

