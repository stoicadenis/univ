#include <stdio.h>
#include <stdlib.h>

int cautare(int v[], int x, int p, int q)
{
	int m;
	if (q < p)
		return 0;
	else
	{
		m = (p + q) / 2;
		if (v[m] == x)
			return 1;
		else
			if (x < v[m])
				return cautare(v, x, p, m - 1);
			else
				return cautare(v, x, m + 1, q);
	}
}
int main()
{
	int v[1000], n, i, x;
	printf("n="); scanf("%d", &n);
	printf("Elementele vectorului se introduc in ordine crescatoare!\n");
	for (i = 0; i < n; i++)
	{
		printf("v[%d]=", i);
		scanf("%d", &v[i]);
	}
	printf("Introduceti elementul pe care il cautati "); scanf("%d", &x);
	if (cautare(v, x, 0, n - 1) != 0)
		printf("Valoarea introdusa se afla in vector");
	else
		printf("Valoarea introdusa nu se afla in vector");

		return 0;
}
