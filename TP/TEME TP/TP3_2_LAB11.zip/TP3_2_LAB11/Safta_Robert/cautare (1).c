#include <stdio.h>
#include <stdlib.h>
int cautare_binara(int a[1000],int st,int dr,int x)
{
    int mij;
    mij=(st+dr)/2;
    if(a[mij]==x) return mij;
    else{
        if(x>a[mij]) return cautare_binara(a,mij+1,dr,x);
        else return cautare_binara(a,st,mij-1,x);
    }
}
int main()
{
    int a[1000],x,i,n;
    printf("n=");scanf("%d",&n);
    printf("a=");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Elementul de cautat este: ");scanf("%d",&x);
    printf("%d se afla pe pozitia %d in sir",x,cautare_binara(a,0,n-1,x));
    return 0;
}
