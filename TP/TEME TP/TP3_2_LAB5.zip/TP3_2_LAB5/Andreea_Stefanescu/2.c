#include<stdio.h>
struct exemplu
{
	long int a;
	char * b,* c;
};
int main()
{
    struct exemplu x;
	printf("Spatiul ocupat de o variabila la structura: %d\n",sizeof(x));
	x.a=10;
	x.b="ABCD";
	x.c="EFG";
	printf("%d\n",x.a);
	printf("%s\n",x.b);
	printf("%s\n",x.c);

	getchar();
	int k;
	scanf("%d", &k);
}
