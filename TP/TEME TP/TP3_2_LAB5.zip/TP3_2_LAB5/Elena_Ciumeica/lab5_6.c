#include<stdio.h>
#include<stdlib.h>
#define MAX 50

/*typedef struct {
	int l, c, n;
	int linii[MAX];
	int coloane[MAX];
	float nenul[MAX];
} matrice_rara;

void citire(matrice_rara* mat, int* count, int l, int c) {
	int i, j;
	float val;
	mat[*count].l = l;
	mat[*count].c = c;
	mat[*count].n = 0;

	for (i = 0; i < l; i++) {
		for (j = 0; j < c; j++) {
			printf("\nmat[%d][%d]: ", i, j);
			scanf("%f", &val);
			if (val) {
				mat[*count].linii[mat[*count].n] = i;
				mat[*count].coloane[mat[*count].n] = j;
				mat[*count].nenul[mat[*count].n++] = val;
			}
		}
	}
	(*count)++;
}

void afisare(matrice_rara* mat, int count, int l, int c) {
	int i, j, x, n = 0;
	for (x = 0; x < count; x++) {
		n = 0;
		printf("\n");
		for (i = 0; i < l; i++) {
			for (j = 0; j < c; j++) {
				if (mat[x].linii[n] == i && mat[x].coloane[n] == j) {
					printf("%5.2f ", mat[x].nenul[n]);
					n++;
				}
				else {
					printf(" 0.00 ");
				}
			}
			printf("\n");
		}
		printf("\n");
	}
}

void suma(matrice_rara* mat, int count) {
	int i, j, suma, x = 0, y = 0;
	printf("Matricea:\n");
	for (i = 0; i < mat[0].l; i++) {
		for (j = 0; j < mat[0].c; j++) {
			if(mat[0].linii[y] == i && mat[0].coloane[y] == j && mat[1].linii[x] == i && mat[1].coloane[x] == j)
				printf("%5.2f ", mat[0].nenul[y++] + mat[1].nenul[x++]);
			else if (mat[0].linii[y] == i && mat[0].coloane[y] == j)
				printf("%5.2f ", mat[0].nenul[y++]);
			else if (mat[1].linii[x] == i && mat[1].coloane[x] == j)
				printf("%5.2f ", mat[1].nenul[x++]);
			else {
				printf(" 0.00 ");
			}
		}
		printf("\n");
	}

}

int main() {
	matrice_rara mat[2];
	int n = 0, l, c, opt;
	printf("Introduceti nr de linii si coloane: ");
	scanf("%d%d", &l, &c);
	while (1) {
		printf("\n0.Iesirea\n1.Citirea\n2.Afisarea\n3.Suma\nOptiunea: ");
		scanf("%d", &opt);
		switch (opt)
		{
		case 0:
			exit(0);
			break;
		case 1:
			citire(mat, &n, l, c);
			break;
		case 2:
			afisare(mat, n, l, c);
			break;
		case 3:
			suma(mat, n);
			break;
		default:
			break;
		}
	}

	return 0;
}*/