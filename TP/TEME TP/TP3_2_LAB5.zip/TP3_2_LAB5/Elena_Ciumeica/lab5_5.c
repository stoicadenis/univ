#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*typedef struct {
	char nume[50];
	int numar_matricol;
} studenti;

void citire(studenti* st, int* n) {
	printf("Nume: ");
	scanf("%s", st[*n].nume);
	printf("Numar matricol: ");
	scanf("%d", &st[*n].numar_matricol);
	(*n)++;
}

void afisare(studenti* st, int n) {
	int i;
	for (i = 0; i < n; i++) {
		printf("Nume: %s Nr: %d\n", st[i].nume, st[i].numar_matricol);
	}
}

void sortareNume(studenti* st, int n) {
	int i, again = 1;
	studenti aux;
	while (again) {
		again = 0;
		for (i = 1; i < n; i++) {
			if (strcmp(st[i - 1].nume, st[i].nume) > 0) {
				aux = st[i - 1];
				st[i - 1] = st[i];
				st[i] = aux;
				again = 1;
			}
		}
	}
}

void sortareNumar(studenti* st, int n) {
	int i, again = 1;
	studenti aux;
	while (again) {
		again = 0;
		for (i = 1; i < n; i++) {
			if (st[i - 1].numar_matricol > st[i ].numar_matricol) {
				aux = st[i - 1];
				st[i - 1] = st[i];
				st[i] = aux;
				again = 1;
			}
		}
	}
}

void cautareNume(studenti* st, int n) {
	char nume[50];
	int i;
	printf("Nume: ");
	scanf("%s", nume);
	sortareNume(st, n);
	for (i = 0; i < n; i++) {
		if (strcmp(nume, st[i].nume) == 0) {
			printf("Se afla pe pozitia %d\n", i);
			return;
		}
	}
	printf("Nu a putut fi gasit\n");
}

void cautareNumar(studenti* st, int n) {
	int i, nr;
	printf("Numar: ");
	scanf("%d", &nr);
	sortareNumar(st, n);
	for (i = 0; i < n; i++) {
		if (st[i].numar_matricol == nr) {
			printf("Se afla pe pozitia %d\n", i);
			return;
		}
	}
	printf("Nu a putut fi gasit\n");
}

int main() {
	studenti st[20];
	int n = 0, opt;
	while (1) {
		printf("\n1.Citire student\n2.Afisare student\n3.Sortare nume\n4.Sortare numar\n5.Cautare nume\n6.Cautare numar\n0.Iesire\nOptiunea: ");
		scanf("%d", &opt);
		switch (opt) {
		case 0:
			exit(0);
			break;
		case 1:
			citire(st, &n);
			break;
		case 2:
			afisare(st, n);
			break;
		case 3:
			sortareNume(st, n);
			afisare(st, n);
			break;
		case 4:
			sortareNumar(st, n);
			afisare(st, n);
			break;
		case 5:
			cautareNume(st, n);
			break;
		case 6:
			cautareNumar(st, n);
			break;
		default:
			break;
		}
	}

	return 0;
}*/