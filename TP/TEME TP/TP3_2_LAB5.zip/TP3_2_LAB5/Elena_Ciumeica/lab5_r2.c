#include<stdio.h>

/*struct exemplu1
{
	long int a;
	char* b;
	char* c;
};

union exemplu2
{
	long int a;
	char* b;
	char* c;
};

void main()
{
	struct exemplu1 x;
	union exemplu2 y;
	x.a = 10;
	x.b = "ABCD";
	x.c = "EFG";
	y.a = 10;
	y.b = "ABCD";
	y.c = "EFG";

	printf("Spatiul ocupat de o variabila la structura: %d\n", sizeof(x));
	printf("%ld\n", x.a);
	printf("%s\n", x.b);
	printf("%s\n", x.c);

	printf("\nSpatiul ocupat de o variabila la uniune: %d\n", sizeof(y));
	printf("%ld\n", y.a);
	printf("%s\n", y.b);
	printf("%s\n", y.c);

	return 0;
}*/