#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>

typedef struct student
{
    char nume[30];
    int nr;
} s;
void citire(s *stud,int *n)
{
    (*n)++;
    scanf("%s",(stud + *n)->nume);
    scanf("%d",&(stud + *n)->nr);
}
void afisare(s *stud,int n)
{
    int i;
    for(i=0; i<=n; i++)
        printf("%s %d",(stud + n)->nume,(stud + n)->nr);
}
void sortare_nume(s *stud,int *n)
{
    int i,j;
    s aux;
    for(i=0; i<=*n-1; i++)
        for(j=i+1; j<=*n-1; j++)
        {
            if(strcmp((stud+i)->nume,(stud+j)->nume)>0)
            {
                aux=*(stud+i);
                *(stud+i)=*(stud+j);
                *(stud+j)=aux;
            }
        }


}
void sortare_nr(s *stud,int *n)
{
    int i,j;
    s aux;
    for(i=0; i<=*n-1; i++)
        for(j=i+1; j<=*n-1; j++)
        {
            if((stud+i)->nr>(stud+j)->nr)
            {
                aux=*(stud+i);
                *(stud+i)=*(stud+j);
                *(stud+j)=aux;
            }
        }

}
void cautare_nume(s *stud,int *n,char num[30])
{
    int i;
    for(i=0; i<=*n; i++)
        if(strcmp((stud+i)->nume,num)==0)
            printf("%d",i);
}
void cautare_nr(s *stud,int *n,int nrmat)
{
    int i;
    for(i=0; i<=*n; i++)
        if((stud+i)->nr==nrmat)
            printf("%d",i);
}

int main()
{
    s stud[30];
    char num[30];
    int nrmat;
    int n=-1,p;
    do
    {
        printf("\n 0.Iesire \n");
        printf("\n 1.Citire \n");
        printf("\n 2.Afisare \n");
        printf("\n 3.Sortare alfabetica \n");
        printf("\n 4.Sortare dupa nr.matricol \n");
        printf("\n 5.Afisare pozitie dupa numele introdus  \n");
        printf("\n 6.Afisare pozitie dupa nr,matricol  \n");
        printf("Optiune dumneavoastra este:");
        scanf("%d",&p);
        switch(p)
        {
        case 0:
            exit(0);
            break;
        case 1:
            citire(stud,&n);
            break;
        case 2:
            afisare(stud,n);
            break;
        case 3:
            sortare_nume(stud,&n);
            break;
        case 4:
            sortare_nr(stud,&n);
            break;
        case 5:
            printf("Numele pe care il cautati:");
            scanf("%s",num);
            cautare_nume(stud,&n,num);
            break;
        case 6:
            printf("Nr.mat pe care il cautati:");
            scanf("%d",&nrmat);
            cautare_nr(stud,&n,nrmat);
            break;

        default:
            printf("Optiune gresita \n");
            break;

        }

    }
    while(1);

    return 0;
}
