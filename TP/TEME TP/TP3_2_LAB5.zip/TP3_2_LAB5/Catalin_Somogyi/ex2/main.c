#include <stdlib.h>
#include <stdio.h>

struct p1
{
    long int a;
    char *b,*c;
};

union p2
{
    long int a;
    char *b,*c;
};

int main(void)
{
    struct p1 x;
    union p2 y;
    printf("Pentru Struct\n");
    printf("Spatiul ocupat de o variabila la structura: %d\n", sizeof(x));
    x.a = 10;
    x.b = "ABCD";
    x.c = "EFG";
    printf("%d\n", x.a);
    printf("%s\n", x.b);
    printf("%s\n", x.c);

    printf("Pentru Uniune\n");
    printf("Spatiul ocupat de o variabila la uniune: %d\n", sizeof(y));
    y.a = 10;
    y.b = "ABCD";
    y.c = "EFG";
    printf("%d\n", y.a);
    printf("%s\n", y.b);
    printf("%s\n", y.c);
}
