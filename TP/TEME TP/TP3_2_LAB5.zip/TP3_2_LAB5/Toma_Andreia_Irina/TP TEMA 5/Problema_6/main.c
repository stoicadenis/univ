#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int l, c, n;
    int linii[20], coloane[20];
    float nenul[40];

} matrice;

void citire(matrice *mat)
{
    int i;

    printf("nr linii = ");
    scanf("%d", &mat->l);

    printf("nr coloane = ");
    scanf("%d", &mat->c);

    printf("nr elemente nenule = ");
    scanf("%d", &mat->n);
    if(mat->n)
    {


        printf("introduce-ti cele n elemente nenule:\n");
        for(i=0; i<mat->n; i++)
        {
            printf("linia = ");
            scanf("%d", &mat->linii[i]);
            printf("coloana = ");
            scanf("%d", &mat->coloane[i]);
            printf("x = ");
            scanf("%f", &mat->nenul[i]);

        }
    }

}

void afisare(matrice mat)
{
    int i, j, c=0;


    for(i=0; i<mat.l; i++)
    {
        for(j=0; j<mat.c; j++)
            if(mat.linii[c]==i && mat.coloane[c]==j)
            {
                printf("%3.2f ", mat.nenul[c]);
                c++;
            }
            else
                printf("0    ");
        printf("\n");

    }
}

matrice suma(matrice mat1, matrice mat2)
{
    matrice m3;
    int i, j, m1k=0, m2k=0, m3k=0;

    if(mat1.l!=mat2.l || mat1.c!=mat2.c)
        printf("matricele nu se pot aduna\n");
    else
    {
        for(i=0; i<mat1.l; i++)
            for(j=0; j<mat1.c; j++)
            {
                if(mat1.linii[m1k]==i && mat2.linii[m2k]==i && mat1.coloane[m1k]==j && mat2.coloane[m2k]==j)
                {
                    m3.nenul[m3k] = mat1.nenul[m1k] + mat2.nenul[m2k];
                    m3.linii[m3k] = i;
                    m3.coloane[m3k] = j;

                    m3k++;
                    m1k++;
                    m2k++;
                }
                else if(mat1.linii[m1k]==i && mat1.coloane[m1k]==j)
                {
                    m3.nenul[m3k] = mat1.nenul[m1k];
                    m3.linii[m3k] = i;
                    m3.coloane[m3k] = j;

                    m3k++;
                    m1k++;
                }
                else if(mat2.linii[m2k]==i && mat2.coloane[m2k]==j)
                {
                    m3.nenul[m3k] = mat2.nenul[m2k];
                    m3.linii[m3k] = i;
                    m3.coloane[m3k] = j;

                    m3k++;
                    m2k++;
                }

            }
            m3.n=m3k;
            m3.l=mat1.l;
            m3.c=mat1.c;

    }
    return m3;
}

int main()
{
int i;
    matrice m1, m2, m3;

    printf("citire matrice rara 1:\n");
    citire(&m1);

for(i=0;i<m1.n;i++)
    printf("%d ", m1.linii[i]);

    printf("citire matrice rara 2:\n");
    citire(&m2);

    printf("afisare matrice 1:\n");
    afisare(m1);

    printf("afisare matrice 2:\n");
    afisare(m2);

    m3 = suma(m1, m2);
    printf("suma matricelor m1 si m2 este:\n");
    afisare(m3);



    return 0;

