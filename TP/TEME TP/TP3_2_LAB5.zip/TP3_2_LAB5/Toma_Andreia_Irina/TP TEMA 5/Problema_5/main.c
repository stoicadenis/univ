#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>


typedef struct student
{
	char nume[50];
	int nr_matricol;
}S;

int citire(S*st, int *nr)
{
	(*nr)++;
	printf("Dati numele studentului:");
	scanf("\n");
	gets((st + *nr)->nume);
	printf("Dati numarul matricol:");
	scanf("%d", &((st + *nr)->nr_matricol));
}

int afisare(S*st, int nr)
{
	printf("%s %d", (st + nr)->nume, (st + nr)->nr_matricol);
}

void sortare_nume(S*st, int *nr)
{
	int i, k;
	S aux;
	do {
		k = 1;
		for (i = 0; i <= (*nr - 1); i++)
			if (strcmp((st + i)->nume, (st + i + 1)->nume) > 0) {
				aux = *(st + i);
				*(st + i) = *(st + i + 1);
				*(st + i + 1) = aux;
				k = 0;
			}
	} while (!k);
}

void sortare_nr_matricol(S*st, int *nr)
{
	int i, k;
	S aux;
	do
	{
		k = 1;
		for (i = 0; i <= (*nr - 1); i++)
			if ((st + i)->nr_matricol < (st + i + 1)->nr_matricol)
			{
				aux = *(st + i);
				*(st + i) = *(st + i + 1);
				*(st + i + 1) = aux;
				k = 0;
			}
	} while (!k);
}

void cautare_nume(S*st, int *nr, char num[50])
{
	int i, n;
	sortare_nume(&st[0], &n);
	for (i = 0; i <= (*nr); i++)
		if (strcmp((st + i)->nume, num) == 0)
			printf("Studentul ocupa pozitia %d\n", i + 1);
}

void cautare_nr_matricol(S*st, int *nr, int nm)
{
	int i, n;
	sortare_nr_matricol(&st[0], &n);
	for (i = 0; i <= (*nr); i++)
		if ((st + i)->nr_matricol == nm)
			printf("Numarul matricol se afla la pozitia %d\n", i + 1);
}


int main()
{
	int opt, n = -1, i, nm;
	char num[50];
	S st[50];

	do
	{
		printf("\n---MENIU---\n");
		printf("1.Adaugare student\n");
		printf("2.Afisarea tuturor studentilor\n");
		printf("3.Sortarea studentilor dupa nume\n");
		printf("4.Sortarea studentilor dupa numarul matricol\n");
		printf("5.Cautarea unui student si afisarea pozitie la care se afla dupa sortarea alafbetica\n");
		printf("6.Cautarea unui student dupa numarul matricol si afisarea pozitiei la care se afla dupa soartare\n");
		printf("7.Iesire\n");
		printf("Dati optiunea:");
		scanf("%d", &opt);
		switch (opt)
		{
		case 1:
			citire(&st[0], &n);
			break;
		case 2:
			for (i = 0; i <= n; i++)
				afisare(st, i);
			break;
		case 3:
			sortare_nume(&st[0], &n);
			for (i = 0; i <= n; i++)
				afisare(st, i);
			break;
		case 4:
			sortare_nr_matricol(&st[0], &n);
			for (i = 0; i <= n; i++)
				afisare(st, n);
			break;
		case 5:
			printf("Dati numele persoanei pe care doriti sa o cautati:");
			scanf("%s", num);
			cautare_nume(&st[0], &n, num);

			break;
		case 6:
			printf("Dati numarul matricol pe care doriti sa l cautati:");
			scanf("%d", &nm);
			cautare_nr_matricol(&st[0], &n, nm);

			break;
		case 7:
			exit(1);
			break;
		default:
			printf("Optiune invalida.Incercati din nou!");
			break;
		}
	} while (opt != 7);
	_getch();
	return 0;
}
