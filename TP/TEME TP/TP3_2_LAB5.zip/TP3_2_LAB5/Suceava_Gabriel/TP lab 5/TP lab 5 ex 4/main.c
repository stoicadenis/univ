/*P4.//Se citesc de la tastatură și se afișează pe ecran următoarele informații despre autovehicul: marca, tipul
(pentru transport persoane sau pentru transport marfă), numărul de km parcurși, tipul de carburant (diesel/benzina)
și capacitatea (numărul de locuri la transportul de persoane și tonajul la transportul de marfă). Programul va
prelucra informații despre un autovehicul, folosind alocarea dinamica a memoriei*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define tpers 1
#define tmarfa 2
 
struct autovehicul
{
    char aux;
    union
    {
        int locuri;
        double tonaj;
    }capacitate;
    char marca[20];
    char diesel;
    double km;
    char carburant[20];
};
void linii()
{
int car;
while ((car = getchar()) != EOF && car != '\n');
}
int main()
{
struct autovehicul *aut;
char buffer[100];
printf("Marca?");
fgets(buffer, 100, stdin);
buffer[strlen(buffer) - 1] = 0;
aut = (struct autovehicul *)
malloc(sizeof(struct autovehicul) + strlen(buffer) + 1);
if (!aut) {
printf("Eroare aloc memory.\n");
exit(EXIT_FAILURE);
}
strcpy(aut->marca, buffer);
printf("Tip (P - persoane, altceva - marfa)? ");
fgets(buffer, 100, stdin);
if (toupper(buffer[0]) == 'P')
aut->aux = tpers;
else
aut->aux = tmarfa;
if (aut->aux == tpers)
{
printf("Nr. locuri? ");
scanf("%d", &aut->capacitate.locuri);
}
else
{
printf("Tonaj)? ");
scanf("%lf", &aut->capacitate.tonaj);
}
printf("km parcursi? ");

scanf("%f", &aut->km);
linii();
printf("Diesel (D - da, altceva - nu)? ");
fgets(buffer, 100, stdin);
if (toupper(buffer[0]) == 'D')
aut->diesel = 1;
else
aut->diesel = 0;
printf("\nMarca: %s\n", aut->marca);
if (aut->aux == tpers)
printf("Transport persoane: %d locuri\n", aut->capacitate.locuri);
else
printf("Transport marfa: %.2lf tone\n", aut->capacitate.tonaj);
printf("%.2f km parcursi\n", aut->km);
if (aut->diesel)
printf("Diesel\n");
else
printf("Benzina\n");
free(aut);
return 0;
}
