#include <stdio.h>
#include <stdlib.h>
union intreg_real
{
    int i;
    double r;
};

int main()
{
    union intreg_real u;
    printf("Un intreg va ocupa: %d\n", sizeof(int));
    printf("Un real va ocupa: %d\n", sizeof(double));
    printf("Un union va ocupa: %d\n", sizeof(union intreg_real));
    u.i=100;
    printf("%d  %f\n",u.i,u.r);
    u.r=12.12;
    printf("%d  %f",u.i,u.r);
    return 0;
}
