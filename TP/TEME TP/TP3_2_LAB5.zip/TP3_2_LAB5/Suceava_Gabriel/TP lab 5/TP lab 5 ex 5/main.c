/*P5.//Să se scrie un program care gestionează date despre un grup de studenţi. Pentru fiecare student
se memorează numele şi numărul matricol. Programul trebuie să implementeze următoarele operaţii:
- citirea numărului de studenţi şi a datelor acestora;
- afişarea datelor tuturor studenţilor;
- sortarea listei de studenţi în ordinea alfabetică a numelor;
- sortarea listei de studenţi în ordinea crescătoare a numerelor matricole;
- căutarea unui student pentru care se precizează numele şi afişarea poziţiei pe care o ocupă acesta în lista
ordonată alfabetic după numele studenţilor;
- căutarea unui student pentru care se precizează numărul matricol şi afişarea poziţiei pe care o ocupă
acesta în lista ordonată crescător după numărul matricol al studenţilor;*/
#include <stdio.h>
#include <stdlib.h>
typedef struct studenti
{
    char nume[20];
    char prenume[20];
    int nr_matricol;
}S;
void citire(S *stud, int *nr)
{
    (*nr)++;
    printf("Nume: ");
    scanf("%s",(stud+*nr)->nume);
    printf("Prenume: ");
    scanf("%s",(stud+*nr)->prenume);
    printf("Numar matricol: ");
    scanf("%d",&((stud+*nr)->nr_matricol));
}
void afisare(S *stud, int nr)
{
    int i;
    for(i=0; i<=nr; i++)
        printf("Nume: %s %s\nNumar matricol: %d\n",(stud+i)->nume,(stud+i)->prenume,(stud+i)->nr_matricol);
}
void sortare_nume(S *stud, int nr)
{
    int i,j;
    S aux;
    for(i=0; i<=nr; i++)
        for(j=i+1; j<=nr; j++)
        {
            if(strcmp(((stud+i)->nume),((stud+j)->nume)<0))
            {
                aux=*(stud+i);
                *(stud+i)=*(stud+j);
                *(stud+j)=aux;
            }
        }
}
void sortare_nr(S *stud, int nr)
{
    int i,j;
    S aux;
    for(i=0; i<=nr; i++)
        for(j=i+1; j<=nr; j++)
        {
            if((stud+i)->nr_matricol>(stud+j)->nr_matricol)
            {
                aux=*(stud+i);
                *(stud+i)=*(stud+j);
                *(stud+j)=aux;
            }
        }
}
int cautare(S *stud, int nr, char num[10])
{
    int i;
    for(i=0; i<=nr; i++)
        if(strcmp(((stud+i)->nume),num)==0)
            return i;
}
int cautare_nr(S *stud, int nr, int m)
{
    int i;
    for(i=0; i<=nr; i++)
        if((stud+i)->nr_matricol==m)
            return i;
}
int main()
{
    printf("Hello world!\n");
    S stud[10];
    int n=-1,opt,poz,m,nr;
    char num[10];
    do
    {
        printf("opt="); scanf("%d",&opt);
        switch(opt)
        {
        case 1:
            citire(&stud[0],&n);
            break;
        case 2:
            afisare(stud,n);
            printf("\n");
            break;
        case 3:
            sortare_nume(stud,n);
            break;
        case 4:
            sortare_nr(stud,n);
            break;
        case 5:
            printf("num="); scanf("%s",num);
            poz=cautare(stud,n,num);
            printf("pozitia persoanei cu numele %s este %d\n",num,poz);
            break;
        case 6:
            printf("m="); scanf("%d",&m);
            nr=cautare_nr(stud,n,m);
            printf("pozitia persoanei cu nr matricol %d este %d\n",m,nr);
            break;
        case 0:
            break;
        default:
            printf("opt gresita");
        }
    }while(opt!=0);
    return 0;
}
