/*5) Să se scrie un program care sa administreze un parc de automobile. Informaţiile relative la un automobil sunt: numărul de locuri, puterea (în cai putere),
marca, culoarea, anul fabricaţiei maşinii.
a) se vor citi informatiile relative la cele n automobile din parcul de autoturisme. Se vor afisa doar acele automobilele care au 5 locuri;
b) sa se ordoneze crescator dupa putere automobilele – se vor afisa datele ordonate;
c) sa se scrie o functie care afiseaza toate automobilele fabricate într-un anumit an dat ca parametru.*/
#include <stdio.h>
#include <stdlib.h>
typedef struct masimi{
    int locuri,putere,anul;
    char marca[10],culoare[10];
}M;
void citire(M *m, int *nr)
{
    (*nr)++;
    printf("Marca: ");
    scanf("%s",(m+*nr)->marca);
    printf("Culoare: ");
    scanf("%s",(m+*nr)->culoare);
    printf("Numar locuri: ");
    scanf("%d",&((m+*nr)->locuri));
    printf("Puterea: ");
    scanf("%d",&((m+*nr)->putere));
    printf("An fab ricatie: ");
    scanf("%d",&((m+*nr)->anul));
}
void afisare(M *m, int *nr)
{
    int i;
    for(i=0; i<=*nr; i++)
    {
        printf("Marca: %s\n",(m+*nr)->marca);
        printf("Culoare: %s\n",(m+*nr)->culoare);
        printf("Numar locuri: %d\n",((m+*nr)->locuri));
        printf("Puterea: %d\n",((m+*nr)->putere));
        printf("An fab ricatie: %d\n",((m+*nr)->anul));
    }
    printf("\n");

}
void af5(M *m, int *nr)
{
    int i;
    for(i=0; i<=*nr; i++)
    {
        if((m+i)->putere==5){
        printf("Marca: %s\n",(m+*nr)->marca);
        printf("Culoare: %s\n",(m+*nr)->culoare);
        printf("Numar locuri: %d\n",((m+*nr)->locuri));
        printf("Puterea: %d\n",((m+*nr)->putere));
        printf("An fab ricatie: %d\n",((m+*nr)->anul));
        }
    }
    printf("\n");

}
void sortare(M *m, int nr)
{
    int i,j;
    M aux;
    for(i=0; i<=nr; i++)
        for(j=i+1; j<=nr; j++)
            if(((m+i)->putere)>((m+j)->putere))
            {
                aux=*(m+i);
                *(m+i)=*(m+j);
                *(m+j)=aux;
            }
}
void cautare(M *m, int nr, int an)
{
    int i;
    for(i=0; i<=nr; i++)
        if(((m+i)->anul)==an)
            afisare(m,i);
    printf("\n");
}
int main()
{
    printf("Hello world!\n");
    int n=-1,i,opt,an;
    M m[10];
    do
    {
        printf("\nopt="); scanf("%d",&opt);
        switch(opt)
        {
        case 1:
            citire(&m[0],&n);
            break;
        case 2:
            afisare(m,&n);
            break;
        case 3:
            af5(m,&n);
            break;
        case 4:
            sortare(m,n);
            break;
        case 5:
            printf("an="); scanf("%d",&an);
            cautare(m,n,an);
            break;
        case 0:
            break;
        }
    }while(opt!=0);
    return 0;
}
