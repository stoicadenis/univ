///3) Să se realizeze o aplicaţie care realizează prelucrări cu numere complexe, adică citire, afişare, modul, sumă şi produs între două astfel de numere.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct complex
{
    float a;
    float b;
}C;
void citire(C *c, int *nr)
{
    (*nr)++;
    printf("Partea intreaga=");
    scanf("%f",&((c+*nr)->a));
    printf("Partea imaginara=");
    scanf("%f",&((c+*nr)->b));
}
void afisare(C *c, int nr)
{
    int i;
    for(i=0; i<=nr; i++)
        printf("%0.f+%0.fi\n",(c+i)->a,(c+i)->b);
}
void mod(C *c, int nr)
{
    float m;
    m=sqrt(pow(((c+nr)->a),2)+pow(((c+nr)->b),2));
    printf("%0.f+%0.fi are modulul %f\n",(c+nr)->a,(c+nr)->b,m);
}
void suma(C *c, int nr)
{
    int i,j;
    float sint,simg;
    for(i=0; i<=nr; i++)
    for(j=i+1; j<=nr; j++){
        sint=(c+i)->a+(c+j)->a;
        simg=(c+i)->b+(c+j)->b;
        printf("Suma numerelor %0.f+%0.fi si %0.f+%0.fi este %0.f+%0.fi\n",(c+i)->a,(c+i)->b,(c+j)->a,(c+j)->b,sint,simg);
    }
}
void produs(C *c, int nr)
{
    int i,j;
    float p1,p2;
    for(i=0; i<=nr; i++)
    for(j=i+1; j<=nr; j++){
        p1=((c+i)->a)*((c+j)->a)+(((c+i)->b)*((c+j)->b)*(-1));
        p2=((c+i)->b)*((c+j)->a)+((c+i)->a)*((c+j)->b);
        printf("Produsul numerelor %0.f+%0.fi si %0.f+%0.fi este %0.f+%0.fi\n",(c+i)->a,(c+i)->b,(c+j)->a,(c+j)->b,p1,p2);
    }
}
int main()
{
    printf("Hello world!\n");
    C c[10];
    int n=-1,opt,i;
    float modul;
    do
    {
        printf("opt="); scanf("%d",&opt);
        switch(opt)
        {
        case 1:
            printf("\nCitire:\n");
            citire(&c[0],&n);
            break;
        case 2:
            printf("\nAfisare\n");
            afisare(c,n);
            break;
        case 3:
            for(i=0; i<=n; i++){
                mod(c,i);
            }
            break;
        case 4:
            suma(c,n);
            break;
        case 5:
            produs(c,n);
            break;
        case 0:
            break;
        default:
            printf("!!!");
        }
    }while(opt!=0);
    return 0;
}
