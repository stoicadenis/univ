#include<stdio.h>
typedef struct exemplu_s
{
	long int a;
	char* b;
	char* c;
} exemplu_s;

typedef union exemplu_u
{
	long int a;
	char* b;
	char* c;
} exemplu_u;
void main()
{
	exemplu_s x;
	printf("Spatiul ocupat de o variabila la structura: %d\n",sizeof(x));
	x.a=10;
	x.b="ABCD";
	x.c="EFG";
	printf("%ld\n",x.a);
	printf("%s\n",x.b);
	printf("%s\n",x.c);

	exemplu_u x2;
	printf("Spatiul ocupat de o variabila la uniune: %d\n",sizeof(x2));
	x2.a=10;
	x2.b="ABCD";
	x2.c="EFG";

	printf("%ld\n",x2.a);
	printf("%s\n",x2.b);
	printf("%s\n",x2.c);

	return 0;

}
