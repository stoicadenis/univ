#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct student
{
    char nume[30];
    int nr;
} student;

int citire(student tab[])
{
    int n,i;
    printf("nr de studenti = ");
    scanf("%d", &n);

    for(i=0; i<n; i++)
    {
        printf("\n\nstudent[%d]\n", i);
        getchar();
        printf("nume: ");
        fgets(tab[i].nume, 30, stdin);
        tab[i].nume[strlen(tab[i].nume)-1]='\0';

        printf("nr matricol = ");
        scanf("%d", &tab[i].nr);
    }
    return n;
}

void afisare(student tab[], int n)
{
    int i;
    for(i=0; i<n; i++)
    {
        printf("\n\nstudent[%d]\n", i);
        printf("nume = %s\nnr matricol = %d", tab[i].nume, tab[i].nr);
    }
}

void sortareNume(student tab[], int n)
{
    student aux;
    int i,j;

    for(i=0; i<n-1; i++)
        for(j = i+1; j<n; j++)
            if(_stricmp(tab[i].nume, tab[j].nume)>0)
            {
                aux = tab[i];
                tab[i] = tab[j];
                tab[j] = aux;
            }
    printf("\nSortarea dupa nume a fost efectuata\n");
}

void sortareNr(student tab[], int n)
{
    student aux;
    int i,j;

    for(i=0; i<n-1; i++)
        for(j = i+1; j<n; j++)
            if(tab[i].nr>tab[j].nr)
            {
                aux = tab[i];
                tab[i] = tab[j];
                tab[j] = aux;
            }
    printf("\nSortarea dupa nr matricol a fost efectuata\n");
}

void cautareNume(student tab[], int n)
{
    int i;
    char nume[30];
    sortareNume(tab, n);


    printf("nume = ");
    getchar();
    fgets(nume, 30, stdin);
    nume[strlen(nume)-1]='\0';

    for(i=0;i<n;i++)
        if(_stricmp(nume, tab[i].nume)==0)
            break;
    if(i==n)
        printf("studentul nu exista\n");
    else
        printf("studentul se afla pe pozitia %d", i);

}

void cautareNr(student tab[], int n)
{
     int i, numar;

    sortareNr(tab, n);

    printf("nr matricol = ");
    scanf("%d", &numar);

    for(i=0;i<n;i++)
        if(tab[i].nr == numar)
            break;
    if(i==n)
        printf("studentul nu exista\n");
    else
        printf("studentul se afla pe pozitia %d", i);
}

int main()
{
    student s[10];
    int n=0, p;

    printf("1) citire studenti\n");
    printf("2) afisare\n");
    printf("3) sortare alfabetica dupa nume\n");
    printf("4) sortare crescaroare dupa nr matricol\n");
    printf("5) cautare student dupa nume\n");
    printf("6) cautare student dupa nr matricol\n");
    printf("0) iesire\n");

    do
    {
        printf("\noptiunea dvs este : ");
        scanf("%d", &p);

        switch(p)
        {
        case 1:
            n=citire(s);
            break;

        case 2:
            afisare(s,n);
            break;

        case 3:
            sortareNume(s, n);
            break;

        case 4:
            sortareNr(s, n);
            break;

        case 5:
            cautareNume(s, n);
            break;

        case 6:
            cautareNr(s, n);
            break;

        case 0:
            exit(0);
            break;

        default:
            printf("ati introdus o optiune gresita\n");



        }
    }while(1);

    return 0;
}
