#include <stdio.h>
#include <stdlib.h>
typedef struct student
{
    char name[40];
    int nomat;
}S;

void citire(S *st, int *n)
{
    (*n)++;
    printf("Name: ");
    scanf("%s",(st+*n)->name);
    printf("Nr matricol: ");
    scanf("%d",&(st+*n)->nomat);
}

void afisare(S *s, int *n)
{
    int i;
    for(i=0;i<=*n;i++)
    printf("Name: %s\n Nr matricol: %d\n",(s+i)->name,(s+i)->nomat);
}

void sortareName(S *st, int *n)
{
    int i,k;
    S aux;
    do
    {
       k=1;
       for(i=1;i<=*n;i++)
       if(strcmp((st+i)->name,(st+i-1)->name)<0)
       {
           aux=*(st+i-1);
           *(st+i-1)=*(st+i);
           *(st+i)=aux;
           k=0;
       }
    } while (!k);

}

void sortareMatricol(S *st, int *n)
{
    int i,k;
    S aux;
    do
    {
        k=1;
        for(i=1;i<=*n;i++)
        if((st+i)->nomat<(st+i-1)->nomat)
        {
            aux=*(st+i-1);
            *(st+i-1)=*(st+i);
            *(st+i)=aux;
            k=0;
        }
    }while(!k);
}

void searchName(S *st, int *n)
{
    char numee[40];
    int i;
    printf("Numele studentului cautat:\n");
    scanf("%s",numee);
    sortareName(st,n);
    for(i=0;i<=*n;i++)
    if(strcmp((st+i)->name,numee)==0) printf("Se afla pe pozitia: %d\n",i+1);
}

void searchMatricol(S *st, int *n)
{
    int i,nmat;
    printf("Nr matricol elevului cautat:\n");
    scanf("%d",&nmat);
    sortareMatricol(st,n);
    for(i=0;i<=*n;i++)
    if((st+i)->nomat==nmat)
    printf("Se afla pe pozitia: %d\n",i+1);
}

int main()
{
    S st[100];
    int n=-1,opt;
    do
    {
        printf("1.Input\n");
        printf("2.Display\n");
        printf("3.Sortare dupa nume\n");
        printf("4.Sortare dupa numarul matricol\n");
        printf("5.Pozitia unui student in lista ordonata alfabetic dupa nume\n");
        printf("6.Pozitia numarului matricol in lista ordonata crescator dupa numarul matricol\n");
        printf("0.Exit\n");
        printf("Optiunea dvs. este: \n");
        scanf("%d",&opt);
        switch(opt)
        {
            case 1:
                citire(st,&n);
                break;
            case 2:
                afisare(st,&n);
                break;
            case 3:
                sortareName(st,&n);
                afisare(st,&n);
                break;
            case 4:
                sortareMatricol(st,&n);
                afisare(st,&n);
                break;
            case 5:
                searchName(st,&n);
                break;
            case 6:
                searchMatricol(st,&n);
                break;
            case 0:
                exit(0);
                break;
            default:
                printf("Wrong nb\n");
                break;
        }
    } while (1);

    return 0;
}
