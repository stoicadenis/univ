#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct{
    char nume[10],prenume[10];
    int matricol;
}S;
void citire(S *s, int n)
{
    char num[10],p[10];
    int i;
    for(i=0;i<n;i++)
    {
        getchar();
        printf("Nume:");
        fgets(num,10,stdin);
        num[strlen(num)-1]=0;
        strcpy(s[i].nume,num);

        printf("Prenume:");
        fgets(p,10,stdin);
        p[strlen(p)-1]=0;
        strcpy(s[i].prenume,p);

        printf("Numar matricol:");
        scanf("%d",&s[i].matricol);
    }
}
void afisare(S *s,int n)
{
    int i;
    for(i=0;i<n;i++)
    {
        printf("Nume si prenume:%s %s\n",s[i].nume,s[i].prenume);
        printf("Numar matricol:%d\n",s[i].matricol);
    }
    printf("\n");
}
void sortare_alfabetic(S *s, int n)
{
    char aux[10];
    int i,k;
    do{
            k=1;
    for(i=1;i<n;i++)
        if(strcmp(s[i].nume,s[i-1].nume)<0)
    {
        strcpy(aux,s[i-1].nume);
        strcpy(s[i-1].nume,s[i].nume);
        strcpy(s[i].nume,aux);
        k=0;
    }

    }while(!k);
}
void sortare_crescator(S *s, int n)
{
    int i,k,aux;
    do{
            k=1;
    for(i=1;i<n;i++)
        if(s[i].matricol<s[i-1].matricol)
    {
        aux=s[i-1].matricol;
        s[i-1].matricol=s[i].matricol;
        s[i].matricol=aux;
        k=0;
    }

    }while(!k);
}
void cautare1(S *s, int n, char name[10])
{
    int i;
    sortare_alfabetic(s,n);
    for(i=0;i<n;i++)
        if(strcmp(name,s[i].nume)==0)
        printf("Acesta afla pe pozitia %d in lista ordonata alfabetic\n",i);
}
void cautare2(S *s, int n,int nrm)
{
    int i;
    sortare_crescator(s,n);
    for(i=0;i<n;i++)
        if(s[i].matricol==nrm)
        printf("Acesta se afla pe pozitia %d in lista ordonata crescator dupa nr matricol\n",i);
}
int main()
{
    int n,nrm;
    S s[10];
    char name[10];
    printf("Introduceti nr de studenti");
    scanf("%d",&n);
    citire(s,n);
    printf("Afisare studenti in ordine alfabetica\n");
    sortare_alfabetic(s,n);
    afisare(s,n);
    printf("Afisare studenti in ordine crescatoare dupa nr matricol\n");
    sortare_crescator(s,n);
    afisare(s,n);
    printf("Introduceti numele studentului pe care il cautati:");
    getchar();
    fgets(name,10,stdin);
    name[strlen(name)-1]=0;
    cautare1(s,n,name);
    printf("Introduceti numarul matricol al studentului pe care il cautati:");
    scanf("%d",&nrm);
    cautare2(s,n,nrm);
    return 0;
}

