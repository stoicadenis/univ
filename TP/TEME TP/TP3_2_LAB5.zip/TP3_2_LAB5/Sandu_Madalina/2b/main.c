#include <stdio.h>
#include <stdlib.h>
typedef union exemplu
{
	long int a;
	char* b;
	char* c;
}Exemplu;
int main()
{
	Exemplu x;
	printf("Spatiul ocupat de o variabila la uniune: %d\n",sizeof(x));
	x.a=10;
	x.b="ABCD";
	x.c="EFG";

	printf("%ld\n",x.a);
	printf("%s\n",x.b);
	printf("%s\n",x.c);

	getchar();
	int k;
	scanf("%d", &k);
}

