#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

typedef enum { TVMamifer, TVInsecta, TVPeste, TVPasare  }TipVietuitoare;

typedef struct Vietuitoare
{
	TipVietuitoare tv;
	int durata_viata;
	char nume[50];
	union
	{
		struct
		{
			int gestatie;
			int nr_pui;
		}mamifer;

		struct
		{
			int nr_picioare;
			char zburatoare;
			char periculoasa;
		}insecta;

		struct
		{
			char tip_apa;
			int adancime;
			int viteza;
		}peste;

		struct
		{
			int anvergura;
			int altitudine;
			int viteza;
		}pasare;
	}specie;

}V;

int adaugare(V*v, int *nr)
{
	(*nr)++;
	printf("Dati numele vietuitoarei:");
	scanf("%s",(v+*nr)->nume);
	printf("Dati durata sa de viata:");
	scanf("%d", &(v + *nr)->durata_viata);
	printf("Dati tipul acesteia: 0-mamifer 1-insecta 2-peste 3-pasare");
	scanf("%d", &(v + *nr)->tv);
	switch ((v+*nr)->tv)
	{
	case 0:
		printf("Dati perioada de gestatie:");
		scanf("%d", &(v + *nr)->specie.mamifer.gestatie);
		printf("Dati numarul de pui pe care ii poate avea vietuitoarea respectiva:");
		scanf("%d", &(v + *nr)->specie.mamifer.nr_pui);
		break;
	case 1:
		printf("Dati numarul de picioare:");
		scanf("%d", &(v + *nr)->specie.insecta.nr_picioare);
		printf("Este zburatoare? 0-nu \n  1-da");
		scanf("%hhd", &(v + *nr)->specie.insecta.zburatoare);
		printf("Este periculoasa pentru om? 0-nu\n 1-da");
		scanf("%hhd", &(v + *nr)->specie.insecta.periculoasa);
		break;
	case 2:
		printf("Dati tipul apei:\n 0-sarata\n  1-dulce");
		scanf("%hhd", &(v + *nr)->specie.peste.tip_apa);
		printf("Dati adancimea:");
		scanf("%d", &(v + *nr)->specie.peste.adancime);
		printf("Dati viteza:");
		scanf("%d", &(v + *nr)->specie.peste.viteza);
		break;
	case 3:
		printf("Dati anvergura:");
		scanf("%d", &(v + *nr)->specie.pasare.anvergura);
		printf("Dati altitudinea:");
		scanf("%d", &(v + *nr)->specie.pasare.altitudine);
		printf("Viteza este:");
		scanf("%d", &(v + *nr)->specie.pasare.viteza);
		break;
	default:
		break;
	}

}

int afisare(V*v, int *nr)
{
	int i;
	for (i = 0; i <= 0; i++)
	{
		printf("Numele vietuitoarei este %s\n", (v + i)->nume);

		printf("Durata de viata a vietuitoarei date este %d ani\n", (v + i)->durata_viata);

		switch ((v + i)->tv)
		{
		case 0:
			printf("Perioada de gestatie este de %d luni\n", (v + i)->specie.mamifer.gestatie);
			printf("Numarul de pui pe care ii poatea avea mamiferul respectiv este :%d\n", (v + i)->specie.mamifer.nr_pui);
			break;
		case 1:
			printf("Numarul de picioare este %d\n", (v + i)->specie.insecta.nr_picioare);
			if ((v + i)->specie.insecta.zburatoare == 0)
				printf("Insecta data este zburatoare\n");
			else
				printf("Insecta data nu este zburatoare\n");
			if ((v + i)->specie.insecta.periculoasa == 0)
				printf("Insecta nu este periculoasa pentru om\n");
			else
				printf("Insecta este periculoasa pentru om\n");
			break;
		case 2:
			if ((v + i)->specie.peste.tip_apa == 0)
				printf("Apa este sarata\n");
			else
				printf("Apa este dulce\n");
			printf("Adancimea este %d\n", (v + i)->specie.peste.adancime);
			printf("Viteza este %d\n", (v + i)->specie.peste.viteza);
			break;
		case 3:
			printf("Anvergura este %d\n", (v + i)->specie.pasare.anvergura);
			printf("Altitudinea este: %d\n", (v + i)->specie.pasare.altitudine);
			printf("Viteza este %d", (v + i)->specie.pasare.viteza);
			break;
		}
	}
}

int main()
{
	V v[50];
	int opt, n = -1;
	do
	{
		printf("1.Adaugare\n");
		printf("2.Afisare\n");
		printf("3.Iesire\n");
		printf("Dati optiunea:");
		scanf("%d", &opt);
		switch (opt)
		{
		case 1:
			adaugare(&v, &n);
			break;
		case 2:
			afisare(&v, &n);
			printf("\n");
			break;
		case 3:
			exit(0);
			break;
		default:
			printf("Optiune gresita!");
			break;
		}
	} while (opt != 3);
	_getch();
	return 0;
}
