#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

typedef enum{TMBenzina, TMMOtorina, TMElectric}TipMotor;
typedef enum{TVPersoane, TVMarfa, TVSpecial}TipVehicul;

typedef struct Vehicul
{
	TipMotor tm;
	char marca[50];
	TipVehicul tv;
	union
	{
		struct
		{
			int nr_locuri;
			int nr_airbaguri;
		}persoane;

		struct
		{
			double cantitate;
			char frigorific;
		}marfa;

		char special[50];
	}specific;

}V;

int adaugare(V*v, int *nr)
{
	(*nr)++;
	printf("Dati tipul motorului: 0-benzina, 1-motorina,  2-electric\n");
	scanf("%d", &(v + *nr)->tm);
	printf("Dati marca:");
	scanf("%s", (v + *nr)->marca);
	printf("Dati tipul vehicului: 0-persoane  1-marfa  2 electric");
	scanf("%d", &(v + *nr)->tv);
	switch ((v + *nr)->tv)
	{
	case 0:

		printf("Dati numarul de locuri: ");
		scanf("%d", &(v + *nr)->specific.persoane.nr_locuri);
		printf("Dati numarul de airbaguri: ");
		scanf("%d", &(v + *nr)->specific.persoane.nr_airbaguri);
		break;
	case 1:
		printf("Dati cantitatea:");
		scanf("%lg", &(v + *nr)->specific.marfa.cantitate);
		printf("Este frigorific?\n  0-nu\n 1-da\n");
		scanf("%hhd", &(v + *nr)->specific.marfa.frigorific);
		break;
	case 2:
		printf("Intrebuintarea specifica:");
		scanf("%s", (v + *nr)->specific.special);
		break;
	}

}

int afisare(V*v, int *nr)
{
	int i;
	for (i = 0; i <= 0; i++)
	{
		switch ((v + i)->tm)
		{
		case 0:
			printf("Motor pe benzina\n");
			break;
		case 1:
			printf("Motor pe motorina\n");
			break;
		case 2:
			printf("Motor electric\n");
			break;
		}

		printf("Marca este %s\n", (v + i)->marca);

		switch ((v + i)->tv)
		{
		case 0:
			printf("Numarul de locuri este: %d\n", (v + i)->specific.persoane.nr_locuri);
			printf("Numarul de airbag-uri este :%d\n", (v + i)->specific.persoane.nr_airbaguri);
			break;
		case 1:
			printf("Cantitatea este %lg\n", (v + i)->specific.marfa.cantitate);
			if ((v + i)->specific.marfa.frigorific == 0)
				printf("Nu este frigorific");
			else
				printf("Este frigorific");
			break;
		case 2:
			printf("Intrebuintarea specifica este %s", (v + i)->specific.special);
			break;
		}
	}
}

int main()
{
	V v[50];
	int opt, n = -1;
	do
	{
		printf("1.Adaugare\n");
		printf("2.Afisare\n");
		printf("3.Iesire\n");
		printf("Dati optiunea:");
		scanf("%d", &opt);
		switch (opt)
		{
		case 1:
			adaugare(&v, &n);
			break;
		case 2:
			afisare(&v, &n);
			printf("\n");
			break;
		case 3:
			exit(0);
			break;
		default:
			printf("Optiune gresita!");
			break;
		}
	} while (opt != 3);
	_getch();
	return 0;
}
