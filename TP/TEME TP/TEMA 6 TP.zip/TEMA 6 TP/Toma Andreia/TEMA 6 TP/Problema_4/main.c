#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

typedef struct animal
{
	unsigned int picioare : 10;
	float greutate;
	char denumire_stiintifica[9];
	char periculoase;
	unsigned int varsta : 11;
}A;

int adaugare(A*a, int *nr)
{
	unsigned int v, p;
	(*nr)++;
	printf("Dati denumirea stiintifica:");
	scanf("%s", (a + *nr)->denumire_stiintifica);
	printf("Dati varsta:");
	scanf("%u", &v);
	(a + *nr)->varsta = v;
	printf("Dati numarul de picioare:");
	scanf("%u", &p);
	(a + *nr)->picioare = p;
	printf("Dati greutatea in kg:");
	scanf("%f", &(a + *nr)->greutate);
	printf("Este periculoasa pentru om?\n 0-nu\n 1-da\n");
	scanf("%hhd",&(a+*nr)->periculoase);
}

int afisare(A*a, int *nr)
{
	int i;
	for (i = 0; i <= *nr; i++)
	{
		printf("Denumirea stiintifica este %s\n", (a+i)->denumire_stiintifica);
		printf("Varsta este %d\n", (a + i)->varsta);
		printf("Numarul de picioare este : %u\n", (a+i)->picioare);
		printf("Greutatea in kg este %f\n", (a + i)->greutate);
		if ((a + i)->periculoase == 0)
			printf("Nu este periculoasa\n");
		else
			printf("Este periculoasa\n");
	}
}

int main()
{
	A a[50];
	int n = -1, opt;
	A b;
	printf("Spatiu de memorare: %lu\n", sizeof(b));
	do
	{
		printf("1.Adaugare\n");
		printf("2.Afisare\n");
		printf("3.Iesire\n");
		printf("Dati optiunea:");
		scanf("%d", &opt);
		switch (opt)
		{
		case 1:
			adaugare(&a, &n);
			break;
		case 2:
			afisare(&a, &n);
			break;
		case 3:
			exit(0);
			break;
		default:
			printf("Optiune gresita!");
			break;
		}
	} while (opt != 3);
	_getch();
	return 0;
}
