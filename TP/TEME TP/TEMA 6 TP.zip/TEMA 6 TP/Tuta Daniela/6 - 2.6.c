#include <stdio.h>
#include <stdlib.h>
#include <string.h>

union medicament
{
    unsigned char grad[7];
    unsigned short varsta_minima:4;
    unsigned short eliberare:1;
};

int main()
{
    union medicament M;
    unsigned char aux_grad[7];
    char *denumire;
    unsigned short aux_varsta_minima, aux_eliberare;
    denumire=(char*)(malloc(sizeof(char)));
    printf("\n Dimensiunea structurii medicament este de %d biti\n", sizeof(M));
    printf("\nIntroduceti denumirea medicamentului: ");
    fgets(denumire, 20, stdin);
    printf(" Gradul de periculozitate (scazut/mediu/mare): ");
    fgets(aux_grad, 7, stdin);
    strcpy(M.grad, aux_grad);
    printf(" Se elibereaza doar pe baza de reteta? (1 - da/0 - nu): ");
    scanf("%u", &aux_eliberare);
    M.eliberare=aux_eliberare;
    printf(" Varsta minima de administrare: ");
    scanf("%u", &aux_varsta_minima);
    M.varsta_minima=aux_varsta_minima;
    if(aux_varsta_minima<1||aux_varsta_minima>18)
        printf(" Varsta minima trebuie sa fie intre 1 si 18 ani!\n");
    // Afisarea informatiilor despre medicament
    printf("\n  %s", denumire);
    printf("\n Grad periculozitate: %s", M.grad);
    if(aux_eliberare==1)
        printf(" Se elibereaza DOAR pe baza de reteta!\n");
    else printf(" Se elibereaza si FARA prescriptie medicala!\n");
    printf(" Varsta minima de administrare: %u ani\n\n", M.varsta_minima);
    return 0;
}
