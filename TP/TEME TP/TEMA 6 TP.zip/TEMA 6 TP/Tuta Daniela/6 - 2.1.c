#include <stdio.h>
#include <string.h>

typedef enum {tm_benzina, tm_motorina, tm_electric} tip_motor;
const char *nume_tm[]={"benzina", "motorina", "electric"};
typedef enum {tv_persoane, tv_marfa, tv_special} tip_vehicul;
const char *nume_tv[]={"persoane", "marfa", "special"};

typedef struct
{
    tip_motor tm;
    char marca[20];
    tip_vehicul tv;
    union
    {
        struct
        {
            int nr_locuri;
            int nr_airbaguri;
        } p;
        struct
        {
            double capacitate;
            char frigorific; // false (0), true(1)
        } m;
        char special[20]; // "tractor", "balastiera", ...
    } specific;
} vehicul;

void afisare(vehicul *v)
{
    printf("\nTip motor: %s\n", nume_tm[v->tm]);
    printf("Marca: %s\n", v->marca);
    printf("Tip vehicul: %s\n", nume_tv[v->tv]);
    if(v->tv==0) {
        printf("Numar de locuri: %d\n", v->specific.p.nr_locuri);
        printf("Numar de airbaguri: %d\n", v->specific.p.nr_airbaguri);
    }
    else if(v->tv==1) {
        printf("Capacitate (kg): %lg\n", v->specific.m.capacitate);
        if(v->specific.m.frigorific==1)
            printf("\nFrigorific\n");
        else
            printf("\nNu este frigorific\n");
    }
    else
        printf("Numele intrebuintarii: %s\n", v->specific.special);
}
void citire(vehicul *v)
{
    int tm, tv;
    printf("Tip motor (0 - benzina, 1 - motorina, 2 - electric): ");
    scanf("%d", &tm);
    v->tm=tm;
    printf("Marca (producator si tip): ");
    getchar();
    fgets(v->marca, 20, stdin);
    printf("Tip vehicul (0 - persoane, 1 - marfa, 2 - special): ");
    scanf("%d", &tv);
    v->tv=tv;
    if(v->tv==0) {
        printf("Numar de locuri: ");
        scanf("%d", &v->specific.p.nr_locuri);
        printf("Numar de airbaguri: ");
        scanf("%d", &v->specific.p.nr_airbaguri);
    }
    else if(v->tv==1) {
        printf("Capacitate (kg): ");
        scanf("%lg", &v->specific.m.capacitate);
        printf("Este frigorific? (0 - nu, 1 - da)\n");
        scanf("%hhd", &v->specific.m.frigorific);
    }
    else {
        getchar();
        printf("Numele intrebuintarii: ");
        fgets(v->specific.special, 20, stdin);
    }
}

int main()
{
    vehicul v;
    int nr, i=0;
    printf("Cate autovehicule doriti sa introduceti?\n");
    scanf("%d", &nr);
    while(i<nr) {
        printf("Introduceti datele autovehicolului %d:\n", i);
        citire(&v);
        afisare(&v);
        i++;
    }
    return 0;
}
