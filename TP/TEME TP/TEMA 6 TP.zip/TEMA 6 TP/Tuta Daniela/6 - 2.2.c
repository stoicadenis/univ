#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {mamifer, insecta, peste, pasare} tip_vietuitoare;
const char *nume_vietuitoare[]={"mamifer", "insecta", "peste", "pasare"};
typedef enum {sarata, dulce} tip_apa;
const char *denumire[]={"sarata", "dulce"};

typedef struct
{
    tip_vietuitoare tip;
    unsigned int ani;
    union
    {
        struct
        {
            unsigned int perioada_gestatie, nr_pui;
        } mamifer;
        struct
        {
            unsigned int nr_picioare;
            char pericol; // flase (0), tru (1)
            char zbor[3];
        } insecta;
        struct
        {
            tip_apa apa; // 0 - sarata, 1 - dulce
            unsigned int adancime, viteza;
        } peste;
        struct
        {
            float anvergura;
            double altitudine, viteza;
        } pasare;
    } specific;
} vietuitoare;

void citire(vietuitoare *v)
{
    int t;
    printf("Tip (0 - mamifer, 1 - insecta, 2 - peste, 3 - pasare): ");
    scanf("%d", &t);
    v->tip=t;
    printf("Durata medie de viata (ani): ");
    scanf("%u", &v->ani);
    if(v->tip==0) {
        printf("Perioada de gestatie (ani): ");
        scanf("%u", &v->specific.mamifer.perioada_gestatie);
        printf("Numarul mediu de pui pe care ii naste: ");
        scanf("%u", &v->specific.mamifer.nr_pui);
    }
    else if(v->tip==1) {
        printf("Numar de picioare: ");
        scanf("%u", &v->specific.insecta.nr_picioare);
        printf("Poate zbura? (da/nu)\n");
        getchar();
        scanf("%s", v->specific.insecta.zbor);
        printf("Prezinta un pericol pentru om? (0 - nu, 1 - da)\n");
        scanf("%hhd", &v->specific.insecta.pericol);
    }
    else if(v->tip==2) {
        printf("Tipul de apa (0 - sarata, 1 - dulce): ");
        scanf("%d", &v->specific.peste.apa);
        printf("Adancimea maxima la care poate inota (m): ");
        scanf("%u", &v->specific.peste.adancime);
        printf("Viteza maxima de inot (m/s): ");
        scanf("%u", &v->specific.peste.viteza);
    }
    else {
        printf("Anvergura aripilor: ");
        scanf("%f", &v->specific.pasare.anvergura);
        printf("Altitudinea maxima de zbor: ");
        scanf("%lf", &v->specific.pasare.altitudine);
        printf("Viteza maxima de zbor: ");
        scanf("%lf", &v->specific.pasare.viteza);
    }
}
void afisare(vietuitoare *v)
{
    printf(" Tip: %s\n", nume_vietuitoare[v->tip]);
    printf(" Durata medie de viata: %u ani\n", v->ani);
    if(v->tip==0) {
        printf(" Perioada de gestatie: %u ani\n", v->specific.mamifer.perioada_gestatie);
        printf(" Numarul mediu de pui pe care ii naste: %u\n", v->specific.mamifer.nr_pui);
    }
    else if(v->tip==1) {
        printf(" Numar picioare: %u\n", v->specific.insecta.nr_picioare);
        if(strcmp(v->specific.insecta.zbor, "da")==0)
            printf(" Poate zbura.\n");
        else printf(" Nu poate zbura.\n");
        if(v->specific.insecta.pericol==1)
            printf(" Prezinta un pericol pentru om!!!\n");
        else printf(" NU prezinta un pericol pentru om!\n");
    }
    else if(v->tip==2) {
        if(v->specific.peste.apa==0)
            printf(" Tipul apei: sarata\n");
        else printf(" Tipul apei: dulce\n");
        printf(" Adancimea maxima la care poate inota este de %u m.\n", v->specific.peste.adancime);
        printf(" Viteza maxima de inot este de %u m/s\n", v->specific.peste.viteza);
    }
    else {
        printf(" Anvergura aripilor: %f m\n", v->specific.pasare.anvergura);
        printf(" Altitudinea maxima de zbor este %lf m\n", v->specific.pasare.altitudine);
        printf(" Viteza maxima de zbor %lf km/h\n", v->specific.pasare.viteza);
    }
}

int main()
{
    vietuitoare v;
    char nume[20];
    printf("Introduceti denumirea vietuitoarei: ");
    fgets(nume, 20, stdin);
    citire(&v);
    printf("\n   %s\n", nume);
    afisare(&v);
    return 0;
}
