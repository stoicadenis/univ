#include <stdio.h>

//cantitatea unui produs poate fi data in numar de bucati sau prin greutate, exprimata in kg
union cantitate
{
    int nr_buc;
    double kg;
};
struct produs
{
    char um; // unitate de masura: 'b' - bucata, 'k' - kg
    union cantitate c;
};

/* struct produs
{
    char um; // unitate de masura
    union
    {
        int nr_buc;
        double kg;
    } c; // cantitate
};
struct produs
{
    char nume[20];
    double pret;
    char um; // unitate de masura
    union
    {
        int nr_buc;
        double kg;
    } c; // cantitate
}; */

void afisare(struct produs *p)
{
    switch(p->um) {
        case 'b': printf("%d bucati\n", p->c.nr_buc);
                break;
        case 'k': printf("%g kg\n", p->c.kg);
                break;
        default: printf("Unitate de masura invalida!\n");
    }
}
void introducere(struct produs *p)
{
    printf("Unitate de masura (b - nr. bucati, k - kg): ");
    scanf("%c", &p->um);
    switch(p->um) {
        case 'b': printf("Numar de bucati: ");
                scanf("%d", &p->c.nr_buc);
                break;
        case 'k': printf("Greutate (kg): ");
                scanf("%lg", &p->c.kg);
                break;
        default: printf("Unitate de masura invalida!\n");
    }
}

int main()
{
    struct produs p;
    introducere(&p);
    afisare(&p);
    return 0;
}
