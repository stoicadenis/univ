#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct animal
{
   unsigned short nr_picioare:10;
   unsigned short varsta:11;
   unsigned short pericol:1;
   double greutate; // cel mai greu animal cantareste 101 tone
   unsigned char abreviere[8];
};
#define N sizeof(struct animal)

int main()
{
    struct animal A;
    char *nume;
    unsigned short aux_nr_picioare;
    unsigned short aux_varsta;
    unsigned short aux_pericol;
    double aux_greutate;
    unsigned char aux_abreviere[8];
    nume=(char*)(calloc(N, sizeof(char)));
    printf(" Dimensiunea structurii este: %u.\n", sizeof(A));
    printf(" Introduceti denumirea uzuala a animalului: ");
    fgets(nume, 12, stdin);
    printf(" Cate picioare are? - ");
    scanf("%u", &aux_nr_picioare);
    A.nr_picioare=aux_nr_picioare;
    if(aux_nr_picioare<0||aux_nr_picioare>1000)
        printf(" Numarul de picioare trebuie sa fie cuprins in intervalul [0; 1000]!\n");
    else {
        printf(" Cate kg cantareste? - ");
        scanf("%lf", &aux_greutate);
        A.greutate=aux_greutate;
        printf(" Este periculos pentru om? (0 - nu, 1 - da) \n");
        scanf("%u", &aux_pericol);
        A.pericol=aux_pericol;
        getchar();
        printf(" Abreviere stiintifica a speciei: ");
        fgets(aux_abreviere, 8, stdin);
        strcpy(A.abreviere, aux_abreviere);
        if(strlen(A.abreviere)>9)
            printf(" Denumirea trebuie sa contina maxim 8 caractere!!\n");
        else {
            printf(" Cati ani traieste maxim? - ");
            scanf("%u", &aux_varsta);
            A.varsta=aux_varsta;
            if(aux_varsta<0||aux_varsta>2000)
                printf(" Varsta maxima trebuie sa fie cuprinsa in intervalul [0; 2000]!\n");
            else {
        // Afisarea datelor introduse
            printf("\n\n   Informatii despre %s", nume);
            printf("\n Numar picioare: %u\n", A.nr_picioare);
            printf(" Greutate: %lf kg.\n", A.greutate);
            if(A.pericol==0)
                printf(" NU este periculos pentru om!\n");
        else printf("****PERICULOS PENTRU OM!!!****\n");
        printf(" Abreviere stiintifica a speciei: %s", A.abreviere);
        printf(" Varsta maxima: %u ani\n", A.varsta);
            }
        }
    }
    return 0;
}
