#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct masuratoare
{
    char unitate_masura[6];
    unsigned int multiplicator;
    unsigned int valoare;
};

int main()
{
    struct masuratoare M;
    unsigned int *val;
    char *um; // unitate de masura
    val=(int*)(malloc(sizeof(int)));
    um=(char*)(malloc(sizeof(char)));
    printf("%d\n", sizeof(M));
    printf("Valoare=");
    scanf("%u", val);
    getchar();
    printf("Unitate de masura: ");
    fgets(um, 6, stdin);
    return 0;
}
