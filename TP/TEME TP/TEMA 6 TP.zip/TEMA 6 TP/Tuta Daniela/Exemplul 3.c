#include <stdio.h>

enum unitate_masura {um_bucata, um_kg};
// typedef enum {um_bucata, um_kg} unitate_masura;
// unitate_masura um;

struct produs
{
    char nume[20];
    double pret;
    enum unitate_masura um; // unitate de masura
    union
    {
        int nr_buc;
        double kg;
    } c;
};

void afisare(struct produs *p)
{
    switch(p->um) {
        case um_bucata: printf("%d bucati\n", p->c.nr_buc);
                    break;
        case um_kg: printf("%lg lg\n", p->c.kg);
                    break;
        default: printf("Unitate de masura invalida!\n");
    }
}
void introducere(struct produs *p)
{
    int um; // variabila auxiliara folosita pentru citire, deoarece nu se stie dimensiunea tipului enum
    printf("Unitate de masura (0 - nr. bucati, 1 - kg): ");
    scanf("%d", &um);
    p->um=um;
    switch(p->um) {
        case um_bucata: printf("Numar de bucati: ");
                    scanf("%d", &p->c.nr_buc);
                    break;
        case um_kg: printf("Greutate (kg): ");
                    scanf("%lg", &p->c.kg);
                    break;
        default: printf("Unitate de masura invalida!\n");
    }
}

int main()
{
    struct produs p;
    introducere(&p);
    afisare(&p);
    return 0;
}
