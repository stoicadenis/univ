#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct text
{
    union linie
    {
        char *linie_text;
    };
};

void eroare(void)
{
    puts("\nEroare alocare dinamica memorie!\n");
    exit(1);
}


int main()
{
    struct text T;
    char *LinieText, *var, *val;
    LinieText=(char*)(malloc(sizeof(char)));
    printf(" Introduceti linia de text\n Forma: nume_variabila=valoare\n\n");
    fgets(LinieText, 50, stdin);
    if(!(T.linie_text=(char*)malloc(strlen(LinieText)+1)))
        eroare();
    strcpy(T.linie_text, LinieText);
    printf("\n %s\n", T.linie_text);
    var=strtok(T.linie_text, "=");
    if(*var<'A'||*var>'z')
        printf(" Primul caracter pentru nume_variabila trebuie sa fie litera!\n");
    val=strtok(NULL, "=");
    if(*(val+3)>='A'&&(*val>='A'&&*val<='z'))
        printf(" Valoarea trebuie sa inceapa cu ghilimele!!!\n");
    else if(*val>='A'&&*val<='z')
        printf(" Valoarea trebuie sa inceapa cu apostrof!!!\n");
    free(LinieText);
    return 0;
}
