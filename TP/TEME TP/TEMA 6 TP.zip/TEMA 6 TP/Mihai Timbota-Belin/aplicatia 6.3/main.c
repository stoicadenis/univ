#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef union
{
    int i;
    double d;
    char c;
    char s[20];

} tip;

typedef struct
{
    char linie [40];
    char nume[20];
    tip val;
    int ok;
    char err[20];
    int selector; // 0-int, 1-double, 2-char, 3-string

} atr;

void citire(char s[], atr *a)
{
    int i=0,j=0;
    char val[20];

    a->ok=1;
    printf("introduce-ti atriburea:\n");
    fgets(a->linie, 40, stdin);

    if(!strchr(a->linie,'=') || strchr(a->linie, '=')==a->linie)
    {
        a->ok=0;
        strcpy(a->err,"atribuirea nu contine niciun '=' sau acesta este primul caracter ");
    }
    else
    {

        while(a->linie[i]!='=')                 // setare nume variabila
        {
            a->nume[j]=a->linie[i];
            i++;
            j++;
        }

        a->nume[j]='\0';
        if( a->nume[0]<'A'||a->nume[0]>'z')
        {
            a->ok=0;
            strcpy(a->err, "eroare");
        }

        j=0;
        i++;

        while(i<strlen(a->linie)-1)        // setare valoare variabila
        {
            val[j]=a->linie[i];
            i++;
            j++;
        }
        val[j]='\0';

        if(val[0]=='\'' && val[j-1]=='\'')
            {a->val.c=val[1];
            a->selector=2;
            }

        else if(val[0]=='"' && val[j-1]=='"')
            {
                strcpy(a->val.s, val);
                strcpy(a->val.s, a->val.s+1);
                a->val.s[j-2]='\0';
                a->selector=3;
            }
            else
            {
                int minus=1;
                char parteint[10];


                if(val[1]=='-')
                    minus=-1;

                if (!strchr(val, '.'))
                  {

                    a->val.i=atoi(val)*minus;
                    a->selector=0;
                  }
                else if(val[0]!='.' && val[j-1]!='.')
                    {
                        j=0;
                        while(val[j]!='.')
                            parteint[j]=val[j++];

                            parteint[j]='\0';
                            a->val.d=atoi(parteint);
                            a->selector=1;

                    }
                    else{
                        a->ok=0;
                        strcpy(a->err,"eroare");
                    }

            }
    }
    }


int main()
{
    char linie[40];
    atr a;

    citire(linie, &a);
    if(a.ok)
{printf("%s = ", a.nume, a.val.i);

switch(a.selector)
{
case 0:
    printf("%d",a.val.i);
    break;
case 1:
    printf("%f", a.val.d);
    break;
case 2:
    printf("%c", a.val.c);
    break;
case 3:
    printf("%s", a.val.s);
}
}
else printf("%s", a.err);



    return 0;
}
