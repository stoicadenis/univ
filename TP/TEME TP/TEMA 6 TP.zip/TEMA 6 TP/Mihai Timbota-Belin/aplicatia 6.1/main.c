#include <stdlib.h>
#include <stdio.h>

typedef enum {TMBenzina, TMMotorina, TMElectric } TipMotor;
typedef enum {TVPersoane, TVMarfa, TVSpecial} TipVehicul;

const char *numeTM[]= {"benzina", "motorina", "electric"};
const char *numeTV[]= {"persoane", "marfa", "special"};

typedef struct
{
    TipMotor tm;
    TipVehicul tv;
    char marca[20];

    union
    {
        struct
        {
            int nrLocuri;
            int nrAirbaguri;
        } p;
        struct
        {
            double capacitate;
            char frigorific; // false(0), true(1)
        } m;

        char special[20]; // "tractor", etc
    } specific;
} Vehicul;

void citire(Vehicul *v)
{
    int tm,tv;

    printf("marca: ");
    fgets(v->marca, 20, stdin);

    printf("tip motor(0-benzina, 1-motorina, 2-electric): ");
    scanf("%d", &tm);
    v->tm=tm;

    printf("tip vehicul(0-persoane, 1-marfa, 2-special): ");
    scanf("%d", &tv);
    v->tv=tv;

    if(tv==0)
    {
        printf("nr locuri: ");
        scanf("%d",&v->specific.p.nrLocuri);
        printf("nr Airbaguri: ");
        scanf("%d",&v->specific.p.nrAirbaguri);
    }
    else if(tv==1)
    {
        printf("capacitate: ");
        scanf("%lg", &v->specific.m.capacitate);
        getchar();
        printf("frigorific (0-nu, 1-da): ");
        scanf("%c",&v->specific.m.frigorific);
    }
    else
    {

        printf("tip special: ");
        getchar();
        fgets(v->specific.special, 20, stdin);


    }

}

void afisare(Vehicul *v)
{
    printf("marca: %s", v->marca);
    printf("tip motor: %s\n", numeTM[v->tm]);
    printf("tip vehicul: %s\n", numeTV[v->tv]);

    if(v->tv==0)
    {
        printf("nr locuri: %d\n", v->specific.p.nrLocuri);
        printf("nr airbaguri: %d\n", v->specific.p.nrAirbaguri);
    }
    else if(v->tv==1)
    {
        printf("capacitate: %f\n", v->specific.m.capacitate);

        printf("frigorific: %c\n", v->specific.m.frigorific);
    }
    else
        printf("tip special: %s\n", v->specific.special);


}

int main()
{
    Vehicul v;
    citire(&v);
    afisare(&v);

    getch();
    return 0;
}

