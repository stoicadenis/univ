#include <stdio.h>
#include <stdlib.h>

typedef struct{
unsigned int pericol:2; // 0-scazut, 1-mediu, 2- mare
unsigned int reteta:1; // 0-nu, 1-da
unsigned int varsta:5;
}medicament;

void citire(medicament *m)
{
    int aux;

    printf("gradul de periculozitate(0-scazuta, 1-mediu, 2-mare): ");
    scanf("%d", &aux);
    m->pericol=aux;

    printf("reteta(0-nu, 1-da): ");
    scanf("%d", &aux);
    m->reteta=aux;

    printf("varsta minima: ");
    scanf("%d", &aux);
    m->varsta=aux;
}

void afisare(medicament *m)
{
    printf("gradul de periculozitate: %d\n", m->pericol);
    printf("se elibereaza prin reteta: %d\n", m->reteta);
    printf("varsta minima: %d\n", m->varsta);

}




int main()
{
    medicament m;

     printf("dimensiunea structurii este %d\n", sizeof(medicament) );

     citire(&m);
     afisare(&m);


    return 0;
}
