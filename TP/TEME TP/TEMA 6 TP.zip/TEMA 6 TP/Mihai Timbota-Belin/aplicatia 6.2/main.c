#include <stdio.h>
#include <stdlib.h>

typedef enum {mamifer, insecta, peste} tip;
typedef enum {dulce, sarata} apa;

const char *numeTip[]= {"mamifer", "insecta", "peste"};
const char *numeApa[]= {"dulce", "sarata"};


typedef struct
{
    tip t;
    int dv;
    union
    {

        struct
        {
            int perioada;
            int nr_pui;
        } mam;

        struct
        {
            unsigned int nr_picioare;
            char zbor;             // 0-false, 1-true
            char pericol;          //0-false, 1-true
        } ins;

        struct
        {
            apa a;
            int adancime;
            unsigned int viteza;
        } pes;

        struct
        {
            unsigned int anvergura;
            unsigned int altitudine;
            unsigned  int viteza;
        }pas;

    } specific;

} vietuitoare;

void citire(vietuitoare *v)
{
    int t;
    int a;

    printf("tipul de vietuitoare(0-mamifer, 1-insecta, 2-peste, 3-pasare): ");
    scanf("%d", &t);
    v->t=t;

    printf("durata medie de viata: ");
    scanf("%d", &v->dv);

    switch(v->t)
    {
    case 0:
        printf("perioada de gestatie: ");
        scanf("%d", &v->specific.mam.perioada);
        printf("numarul mediu de pui pe care il naste: ");
        scanf("%d", &v->specific.mam.nr_pui);
        break;

    case 1:
        printf("nr de picioare: ");
        scanf("%d", &v->specific.ins.nr_picioare);
        getchar();
        printf("poate sa zboare(0-nu, 1-da)? ");
        scanf("%c", &v->specific.ins.zbor);
        printf("e periculoasa pentru om(0-nu, 1-da)?");
        getchar();
        scanf("%c", &v->specific.ins.pericol);
        break;

    case 2:

        printf("tip de apa(0-dulce, 1-sarata): ");
        getchar();
        scanf("%d", &a);
        v->specific.pes.a=a;
        printf("adancime maxima: ");
        scanf("%d", &v->specific.pes.adancime);
        printf("viteza maxima de inot: ");
        scanf("%d", &v->specific.pes.viteza);
        break;

    case 3:
        printf("anvergura aripilor: ");
        scanf("%d", &v->specific.pas.anvergura);
        printf("altitudinea maxima de zbor: ");
        scanf("%d", &v->specific.pas.altitudine);
        printf("viteza maxima de zbor: ");
        scanf("%d", &v->specific.pas.viteza);
        break;
default: break;

    }

}

void afisare(vietuitoare *v)
{
    printf("tipul de vietuitoare: %s\n", numeTip[v->t]);

    printf("durata medie de viata: %d\n", v->dv);


    switch(v->t)
    {
    case 0:
        printf("perioada de gestatie: %d\n", v->specific.mam.perioada);
        printf("numarul mediu de pui pe care il naste: %d\n", v->specific.mam.nr_pui);
        break;

    case 1:
        printf("nr de picioare: %d\n",v->specific.ins.nr_picioare );
        printf("zbor: %c\n",v->specific.ins.zbor);
        printf("periculoasa pentru om: %c\n", v->specific.ins.pericol);
        break;

    case 2:
        printf("tip de apa: %s \n", numeApa[v->specific.pes.a]);
        printf("adancime maxima: %d\n", v->specific.pes.adancime);
        printf("viteza maxima de inot: %d\n",v->specific.pes.viteza);
        break;

    case 3:
        printf("anvergura aripilor: %d\n",v->specific.pas.anvergura );
        printf("altitudinea maxima de zbor: %d\n", v->specific.pas.altitudine);
        printf("viteza maxima de zbor: %d\n",v->specific.pas.viteza);
        break;


    }
}


int main()
{
    vietuitoare v;
    citire(&v);

   afisare(&v);

    getch();
    return 0;
}
