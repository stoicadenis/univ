#include <stdio.h>
#include <stdlib.h>

typedef struct{
unsigned int picioare:10;
float greutate;
unsigned int periculos:1;
char abreviere[9];
unsigned int varsta:11;
}animal;

void citire(animal *a)
{int aux;
    printf("nr de picioare: ");
    scanf("%d", &aux);
    a->picioare=aux;

    printf("greutate: ");
    scanf("%f", &a->greutate);

    printf("periculos (0-nu, 1-da): ");
    scanf("%d",&aux);
    a->periculos=aux;

    printf("abreviere :");
    getchar();
    fgets(a->abreviere, 9, stdin);

    printf("varsta maxima : ");
    scanf("%d", &aux);
    a->varsta=aux;
}

void afisare(animal *a)
{
    printf("nr de picioare: %d\n", a->picioare);
    printf("greutate: %f\n", a->greutate);
    printf("periculos: %d\n", a->periculos);
    printf("abreviere: %s", a->abreviere);
    printf("varsta maxima: %d", a->varsta);
}

int main()
{
    animal a;
    printf("dimensiunea structurii este %d\n", sizeof(a));
    citire(&a);
    afisare(&a);



    return 0;
}
