#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {gram, metru, litru} um;
typedef enum {pico, nano, mili, centi, deci, fara, deca, hecto, kilo, mega, giga} mul;

const char *numeUm[] = {"gram", "metru", "litru"};
const char *numeMul[] = {"pico", "nano", "mili", "centi", "deci","", "deca", "hecto", "kilo", "mega", "giga"};

typedef struct
{
    um masura:2;
    mul multi:4;
    unsigned int val:9;
    unsigned int ok:1;

} masuratoare;

void citire(masuratoare *m)
{
    char uni[10];
    int i;
    unsigned long x;
    m->multi=5;

    printf("valoare = ");
    scanf("%d", &x);


    printf("unitate de masura = ");
    getchar();
    fgets( uni,10,stdin);
    uni[strlen(uni)-1]='\0';


    for(i=0; i<3; i++)
        if(strcmp(uni, numeUm[i])==0)
        {
            m->masura=i;
            break;
        }
    if(x)
        while(x%10==0&& m->multi!=10)
        {
            m->multi++;
            x/=10;
        }
    m->val=x;
    m->ok=1;
    if(x-m->val!=0)
        m->ok=0;

}

void afisare(masuratoare *m)
{
    if(m->ok)
    {
        printf("%d %s%s\n", m->val, numeMul[m->multi],numeUm[m->masura]);
    }
    else printf("eroare\n");
}



int main()
{
    masuratoare m;
    citire(&m);
    afisare(&m);


    getch();
    return 0;
}
