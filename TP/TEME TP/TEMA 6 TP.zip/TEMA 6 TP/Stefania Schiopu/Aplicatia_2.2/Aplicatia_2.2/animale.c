﻿/*Folosind struct si union, definiti o structura de date care sa poata memora urmatoarele informatii despre vietuitoare:
- tipul (poate fi: mamifer, insecta, peste, pasare)
- durata medie de viata in ani
- daca e mamifer: perioada de gestatie, numarul mediu de pui pe care ii naste
- daca e insecta: numarul de picioare, daca poate sa zboare sau nu, daca este periculoasa sau nu pentru om
- daca e peste: tipul de apa: sarata/dulce, adancimea maxima la care se poate intalni, viteza maxima de inot
- dacă e pasare : anvergura aripilor, altitudinea maxima de zbor, viteza maxima de zbor
Definiti structura in asa fel incat memoria consumata sa fie minima. Cititi si afisati informatiile despre o vietuitoare.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { mamifer, insecta, peste, pasare }tip;
typedef enum { sarata, dulce }tip_apa;
typedef struct animale
{
	int durata_viata;
	char nume[30];
	tip t;
	union
	{
		struct
		{
			int gestatie, pui;
		}mamifer;

		struct
		{
			int picioare;
			char zboara, periculoasa;
		}insecta;

		struct
		{
			tip_apa apa;
			int adancime, viteza_inot;
		}peste;

		struct
		{
			int anvergura, altitudine, viteza_zbor;
		}pasare;

	}vietate;
}animal;

void Citire(animal *a, int *n)
{
	(*n)++;
	printf("Numele vietatii: ");
	scanf("%s", (a + *n)->nume);
	printf("Durata medie de viata: ");
	scanf("%d", &(a + *n)->durata_viata);
	printf("Tipul vietuitoarei (introduceti 0 - mamifer, 1 - insecta, 2 - peste, 3 - pasare): ");
	scanf("%d", &(a + *n)->t);
	switch ((a + *n)->t)
	{
	case 0:
		printf("Perioada de gestatie: ");
		scanf("%d", &(a + *n)->vietate.mamifer.gestatie);
		printf("Numarul mediu de pui: ");
		scanf("%d", &(a + *n)->vietate.mamifer.pui);
		break;
	case 1:
		printf("Numarul de picioare: ");
		scanf("%d", &(a + *n)->vietate.insecta.picioare);
		printf("Zboara: ");
		scanf("%hhd", &(a + *n)->vietate.insecta.zboara);
		printf("Periculos pentru om: ");
		scanf("%hhd", &(a + *n)->vietate.insecta.periculoasa);
		break;
	case 2:
		printf("Tipul de apa in care se gaseste (introduceti 0 - dulce, 1 - sarata): ");
		scanf("%d", &(a + *n)->vietate.peste.apa);
		printf("Adancimea maxima la care poate fi gasit: ");
		scanf("%d", &(a + *n)->vietate.peste.adancime);
		printf("Viteza maxima cu care inoata: ");
		scanf("%d", &(a + *n)->vietate.peste.viteza_inot);
		break;
	case 3:
		printf("Anvergura aripilor: ");
		scanf("%d", &(a + *n)->vietate.pasare.anvergura);
		printf("Altitudinea maxima de zbor: ");
		scanf("%d", &(a + *n)->vietate.pasare.altitudine);
		printf("Viteza cu care zboara: ");
		scanf("%d", &(a + *n)->vietate.pasare.viteza_zbor);
		break;
	default:
		printf("\nOptiunea gresita! Introduceti 0 - mamifer, 1 - insecta, 2 - peste, 3 - pasare.\n");
		break;
	}
}


void Afisare(animal *a, int n)
{
	int i;
	for (i = 0; i <= n; i++)
	{
		printf("Numele vietatii: %s\n", (a + i)->nume);
		printf("Durata medie de viata: %d\n", (a + i)->durata_viata);
		if ((a + i)->t == 0)
		{
			printf("Mamifer\n");
			printf("Perioada de gestatie: %d\nNumarul mediu de pui: %d\n", (a + i)->vietate.mamifer.gestatie, (a + i)->vietate.mamifer.pui);
			printf("\n");
		}
		if ((a + i)->t == 1)
		{
			printf("Insecta\n");
			printf("Numarul de picioare: %d\n", (a + i)->vietate.insecta.picioare);
			if ((a + i)->vietate.insecta.zboara == 0)
				printf("Insecta nu zboara\n");
			else
				printf("Insecta poate zbura\n");
			if ((a + i)->vietate.insecta.periculoasa == 0)
				printf("Insecta nu este periculoasa pentru om\n");
			else
				printf("Insecta este periculoasa pentru om\n");
			printf("\n");
		}
		if ((a + i)->t == 2)
		{
			printf("Peste\n");
			printf("Tipul de apa in care se gaseste (0 - dulce, 1 - sarata) %d\nAdancimea maxima la care poate fi vazut: %d\nViteza maxima cu care inoata: %d\n", (a + i)->vietate.peste.apa, (a + i)->vietate.peste.adancime, (a + i)->vietate.peste.viteza_inot);
			printf("\n");
		}
		if ((a + i)->t == 3)
		{
			printf("Pasare\n");
			printf("Anvergura aripilor: %d\nAltitudinea maxima de zbor: %d\nViteza maxima cu care zboara: %d\n", (a + i)->vietate.pasare.anvergura, (a + i)->vietate.pasare.altitudine, (a + i)->vietate.pasare.viteza_zbor);
			printf("\n");
		}
	}
}






	int main()
	{
		animal a[30];
		int n = -1;
		enum meniu { iesire, adaugare, afisare }opt;
		do
		{
			printf("\n0.Iesire\n");
			printf("1.Citire\n");
			printf("2.Afisare\n");
			
			printf("\nOptiunea dumneavoastra este: ");
			scanf("%d", &opt);
			switch (opt)
			{
			case iesire:
				exit(0);
				break;
			case adaugare:
				Citire(a, &n);
				break;
			case afisare:
				Afisare(a, n);
				break;
			default:
				printf("\nOptiunea nu exista! Te rugam sa alegi o optiune valida!\n");
				break;
			}
		} while (1);

		system("pause");
		return 0;
	}