﻿/*Se citeste de la tastatura o linie de text care contine o atribuire a unei variabile cu o valoare. Linia
are forma "nume_variabila = valoare". Numele variabilei poate contine doar litere sau cifre, cu restrictia ca primul
caracter sa fie litera. Valoarea poate fi numar (incepe cu o cifra si poate avea zecimale), caracter (incepe cu
apostrof) sau sir de caractere (incepe cu ghilimele). Cateva exemple de astfel de atribuiri:
raza=10.12
B22 = 'c'
adresa="Bd. Vasile Parvan nr. 2"
Folosind struct si union definiti o structura de date pentru a pastra in mod eficient informatia din linia citita de la
tastatura. Transferati informatia din linia citita intr-o variabila de tipul structurii de date definite. Afisati informatia
pastratăa in variabila, folosind formatul original (nume_variabila = valoare). Tratati posibile erori ce pot să apară în
linia citită (nume incorect de variabilă, lipsește semnul egal, valoarea atribuită este invalidă).*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct linie_text
{
	char variabila[10];
	char valoare[10];
	char legatura[2];
}T;

int validare_variabila(char *sir)
{
	int i;
// daca primul caracter NU este (litera mica    sau    litera mare)
	if (!((sir[0] >= 'a' && sir[0] <= 'z') || (sir[0] >= 'A' && sir[0] <= 'Z')))
		return 0;
	for (i = 0; sir[i] != '\0'; i++)
// daca restul NU este  (litera mica          sau         litera mare             sau        cifra)
		if (!((sir[i] >= 'a' && sir[i] <= 'z') || (sir[i] >= 'A' && sir[i] <= 'Z') || (sir[i] >= '0' && sir[i] <= '9')))
			return 0;
	 return 1; // DAR daca toate conditiile de mai sus se indeplinesc, atunci suntem in cerinta 
}

int validare_valoare(char *sir)
{
	int i, n = strlen(sir) - 1;
	for (i = 1; i < n; i++)
		if (!((sir[0] == '"' && sir[n] == '"') || (sir[i] >= '0' && sir[i] <= '9') || (strchr("'", sir[0]) && strchr("'", sir[n]))))
			return 0; // nu citeste sirul de caractere din ghilimele daca are si spatii
	return 1;
}

void Citire(T *t, int *n)
{
	(*n)++;
	printf("Variabila: ");
	scanf("%s", (t + *n)->variabila);

	// se face validarea, dar se afiseaza si ce este gresit

	if (validare_variabila((t + *n)->variabila) == 0)
	{
		printf("Variabila nu corespunde!\n");
	}

	printf("Egalul: ");
	scanf("%s", (t + *n)->legatura);
	if (strcmp((t + *n)->legatura, "=") != 0)
	{
		printf("Legatura se face prin egal!\n");
	}

	printf("Valoarea: ");
	scanf("%s", (t + *n)->valoare);
	if (validare_valoare((t + *n)->valoare) == 0)
	{
		printf("Valoarea nu corespunde!\n");
	}
}

void Afisare(T *t, int n)
{
	int i;
	for (i = 0; i <= n; i++)
		printf("%s %s %s\n", (t + i)->variabila, (t + i)->legatura, (t + i)->valoare);
}

int main()
{
	T t[20];
	int n = -1, opt;
	do
	{
		printf("\n0.Iesire\n");
		printf("1.Citire linie\n");
		printf("2.Afisare linie de text\n");
		
		printf("\nOptiunea dumneavoastra: ");
		scanf("%d", &opt);
		switch (opt)
		{
		case 0:
			exit(0);
			break;
		case 1:
			Citire(t, &n);
			break;
		case 2:
			Afisare(t, n);
			break;
		default:
			printf("\nOptiune inexistenta! Te rugam sa alegi o optiune valida!\n");
			break;
		}
	} while (1);

	system("pause");
	return 0;
}