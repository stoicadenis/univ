#include <stdio.h>
#include <stdlib.h>
typedef enum{scazuta,medie,mare}Periculozitate;
typedef enum{da,nu}Reteta;
Periculozitate p;
Reteta r;

typedef struct{
    unsigned char varsta:5;
}Medicament;

void citire(Medicament *m, int *n)
{
    unsigned int v;
    (*n)++;
    printf("Gradul de periculozitate (0-scazuta,1-medie, 2-mare):"); scanf("%d",&p);
    printf("Se elibereaza doar pe baza de reteta? (0-nu,1-da):"); scanf("%d",&r);
    printf("Varsta minima de administrare (1-18 ani):"); scanf("%hhu",&v);
        m[*n].varsta=v;
}
void afisare(Medicament *m, int n)
{
    int i;
    for(i=0;i<=n;i++)
    {
        switch(p)
        {
            case 0:
            printf("Medicamentul %d are periculozitate scazuta\n",i+1);
            break;
            case 1:
            printf("Medicamentul %d are periculozitate medie\n",i+1);
            break;
            case 2:
            printf("Medicamentul %d are periculozitate mare\n",i+1);
            break;
        }
         if(r==0)
            printf("-> Se elibereaza si fara reteta\n");
            else
                printf("-> Se elibereaza doar pe baza de reteta\n");
        printf("-> Varsta minima de administrare este %hhu ani\n",m[i].varsta);
    }
}
int main()
{
   printf("Spatiul de memorare ocupat: %ld octet\n", sizeof(Medicament));
   Medicament m[10];
   int opt,n=-1;
   do{
        printf("\t1.Citire medicament\n");
        printf("\t2.Afisare informatii despre medicamente\n");
        printf("Introduceti optiunea:");
        scanf("%d",&opt);
        switch(opt)
        {
            case 1: citire(m,&n);
            break;
            case 2: afisare(m,n);
            break;
            default: printf("Optiunea nu exista!");
            break;
        }
   }while(1);
    return 0;
}

