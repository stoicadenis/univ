#include <stdio.h>
#include <stdlib.h>

typedef struct {
    unsigned int perioada_gestatie:4,
                        nr_pui:3,
                        durata_de_viata:7;
}mamifer;

typedef struct{
    unsigned int nr_picioare:8,
                         zboara:1,
                         periculoasa:1,
                         durata_de_viata:7;
}insecta;

typedef struct{
    unsigned int apa:1,
                         adancime:9,
                         viteza:7,
                         durata_de_viata:7;
}peste;

typedef struct{
    unsigned int aripi:9,
                         altitudine:11,
                         viteza:7,
                         durata_de_viata:7;
}pasare;

typedef struct{
    unsigned int tip:3;
}tip_animal;
typedef union{
    mamifer m;
    insecta i;
    peste pe;
    pasare pa;
    tip_animal tip_a;
}Vietuitoare;

void citire(Vietuitoare *v, tip_animal *t, int *n, int opt)
{
    unsigned int val;
    (*n)++;
    t[*n].tip=opt;
    switch(opt)
    {
    case 1:
                printf("Durata medie de viata (ani):"); scanf("%u",&val);
                        v[*n].m.durata_de_viata=val;
                printf("Perioada de gestatie (luni):"); scanf("%u",&val);
                        v[*n].m.perioada_gestatie=val;
                printf("Numarul mediu de pui pe care ii naste:"); scanf("%u",&val);
                        v[*n].m.nr_pui=val;
    break;
    case 2:
                printf("Durata medie de viata (ani):"); scanf("%u",&val);
                        v[*n].i.durata_de_viata=val;
                printf("Numarul de picioare:"); scanf("%u",&val);
                        v[*n].i.nr_picioare=val;
                printf("Poate sa zboare?(0-nu/1-da)"); scanf("%u",&val);
                        v[*n].i.zboara=val;
                printf("Este periculoasa pentru om?(0-nu/1-da)"); scanf("%u",&val);
                        v[*n].i.periculoasa=val;
    break;
    case 3:
                printf("Durata medie de viata (ani):"); scanf("%u",&val);
                        v[*n].pe.durata_de_viata=val;
                printf("Tipul de apa(0-sarata/1-dulce):"); scanf("%u",&val);
                        v[*n].pe.apa=val;
                printf("Adancimea maxima la care se poate intalni (m):"); scanf("%u",&val);
                        v[*n].pe.adancime=val;
                printf("Viteza maxima de inot"); scanf("%u",&val);
                        v[*n].pe.viteza=val;
    break;
    case 4:
                printf("Durata medie de viata (ani):"); scanf("%u",&val);
                        v[*n].pa.durata_de_viata=val;
                printf("Anvergura aripilor:"); scanf("%u",&val);
                        v[*n].pa.aripi=val;
                printf("Altitudinea maxima de zbor:"); scanf("%u",&val);
                        v[*n].pa.altitudine=val;
                printf("Viteza maxima de zbor:"); scanf("%u",&val);
                        v[*n].pa.viteza=val;
    break;

    }
}
void afisare(Vietuitoare *v, tip_animal *t, int n)
{

    int i;
    for(i=0;i<=n;i++)
    {
        switch(t[i].tip)
        {
        case 1:
                    printf("\tMamifer\n");
                    printf("Durata de viata:%u ani\nPerioada de gestatie:%u luni\nNr de pui:%u\n",
                              v[i].m.durata_de_viata,v[i].m.perioada_gestatie,v[i].m.nr_pui);
        break;

        case 2:
                    printf("\tInsecta\n");
                    printf("Durata de viata:%u ani\nPerioada de gestatie:%u luni\n",
                              v[i].i.durata_de_viata,  v[i].i.nr_picioare);

                    if(v[i].i.zboara==1)
                        printf("Poate sa zboare\n");
                printf("Nu poate sa zboare\n");

                    if(v[i].i.periculoasa==1)
                        printf("Este periculoasa pentru om\n");
                printf("Nu este periculoasa pentru om\n");
        break;

       case 3:
                    printf("\tPeste\n");
                    printf("Durata de viata:%u ani\nAdancimea maxima:%u m\nViteza maxima:%u km/h\n",
                              v[i].pe.durata_de_viata, v[i].pe.adancime, v[i].pe.viteza);

                    if(v[i].pe.apa==1)
                        printf("Se gaseste in apa sarata\n");
                printf("Se gaseste in apa dulce");
        break;

        case 4:
                    printf("\tPasare\n");
                    printf("Durata de viata:%u ani\nAnvergura aripilor:%u\nAltitudinea maxima:%u m\nViteza maxima:%u km/h\n",
                              v[i].pa.durata_de_viata,v[i].pa.aripi, v[i].pa.altitudine,v[i].pa.viteza);
        break;

        }
    }
}
int main()
{
    Vietuitoare v[10];
    tip_animal t[10];
    int opt,n=-1,i;
    do{
            printf("\t1.Introduceti un mamifer\n");
            printf("\t2.Introduceti o insecta\n");
            printf("\t3.Introduceti un peste\n");
            printf("\t4.Introduceti o pasare\n");
            printf("\t5.Afisare vietuitoare\n");
            printf("\t0.Iesire\n");
            printf("Introduceti optiunea:");
            scanf("%d",&opt);

            switch(opt)
            {
            case 1: citire(v,t,&n,opt);
                    break;
            case 2:citire(v,t,&n,opt);
                    break;
            case 3:citire(v,t,&n,opt);
                    break;
            case 4:citire(v,t,&n,opt);
                    break;
            case 5: afisare(v,t,n);
                    break;
            case 0: exit(0);
                    break;
            default: printf("Nu exista optiunea introdusa!");
                    break;
            }
    }while(1);

     return 0;

}
