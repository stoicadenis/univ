#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef enum{TMBenzina, TMMotorina, TMElectric}TipMotor;
const char *numeTM[]={"benzina", "motorina", "electric"};
typedef enum{TVPersoane, TVMarfa, TVSpecial}TipVehicul;
const char *numeTV[]={"persoane", "marfa", "special"};

typedef struct{
    TipMotor tm;
    char marca[20];
    TipVehicul tv;
    union{
        struct{
            int nrLocuri;
            int nrAirbaguri;
            }p;
        struct{
            double capacitate;
            char frigorific;
            }m;
        char special[20];
        }s;
}Vehicul;

void citire(Vehicul *v, int *n)
{
    (*n)++;
    int tm,tv;
    printf("Tipul motorului (0-benzina,1-motorina,2-electric):"); scanf("%d",&tm);
            (v+*n)->tm=tm;
    printf("Marca:"); scanf("%s",(v+*n)->marca);
    printf("Tip vehicul (0-persoane,1-marfa,2-special)"); scanf("%d",&tv);
            (v+*n)->tv=tv;
        switch((v+*n)->tv)
        {
            case TVPersoane:
                                          printf("Nr de locuri:");
                                          scanf("%d",&(v+*n)->s.p.nrLocuri);
                                          printf("Nr de airbaguri:");
                                          scanf("%d",&(v+*n)->s.p.nrAirbaguri);
            break;
            case TVMarfa:
                                    printf("Capacitate:");
                                    scanf("%d",&(v+*n)->s.m.capacitate);
                                    printf("Este frigorific? (0-nu/1-da):");
                                    scanf("%d",&(v+*n)->s.m.frigorific);
            break;
            case TVSpecial:
                                     printf("Ce tip de masina este?:");
                                     scanf("%s",(v+*n)->s.special);
            break;
        }
}
void afisare(Vehicul *v, int n)
{
    int i;
    for(i=0;i<=n;i++)
    {
        printf("\tVehiculul nr %d este de tip %s\n",i+1,numeTV[(v+i)->tv]);
        printf("Tip motor: %s\n",numeTM[(v+i)->tm]);
        printf("Marca:%s\n",(v+i)->marca);
        switch((v+i)->tv)
        {
            case TVPersoane: printf("Nr de locuri:%d\n",(v+i)->s.p.nrLocuri);
                                          printf("Nr de aribaguri:%d\n",(v+i)->s.p.nrAirbaguri);
            break;
            case TVMarfa: printf("Capacitate:%d\n",(v+i)->s.m.capacitate);
                                    if((v+i)->s.m.frigorific==0)
                                    printf("Vehiculul nu este frigorific\n");
                                    else
                                        printf("Vehiculul este frigorific\n");
            break;
            case TVSpecial: printf("Tip masina:%s\n",(v+i)->s.special);
            break;
        }
    }
}
int main()
{
    Vehicul v[10];
    int opt,n=-1;
    do{
        printf("\t1.Citire\n");
        printf("\t2.Afisare\n");
        printf("\t0.Iesire\n");
        printf("Introduceti optiunea:");
        scanf("%d",&opt);
        switch(opt)
        {
            case 1: citire(v,&n);
            break;
            case 2: afisare(v,n);
            break;
            case 0: exit(0);
            break;
            default: printf("Optiunea nu exista!");
            break;
        }
    }while(1);
    return 0;
}
