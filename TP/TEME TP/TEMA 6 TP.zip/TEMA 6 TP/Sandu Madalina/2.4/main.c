#include<stdio.h>
#include<stdlib.h>
typedef struct {
    unsigned int nr_picioare: 10,
                          varsta_maxima:11;
    float greutate;
    char abreviere[8],
             periculos;
}Animale;
void citire(Animale *a, int *n)
{
    unsigned int val;
    (*n)++;
    printf("Nr de picioare:"); scanf("%u", & val);
            a[*n].nr_picioare = val;
    printf("Greutate (kg):"); scanf("%f", & a[*n].greutate);
    printf("Este periculos pentru om? (0-nu/1-da)"); scanf("%hhd", &a[*n].periculos);
    printf("Abrevierea stiintifica a speciei:"); scanf("%s", a[*n].abreviere);
    printf("Varsta maxima (ani):"); scanf("%u", & val);
            a[*n].varsta_maxima = val;
}
void afisare(Animale *a, int n)
{
    int i;
    for(i=0;i<=n;i++)
    {
        printf("\tAnimalul nr %d\n",i+1);
        printf("-> Nr de picioare:%u\n-> Greutate:%.3f\n-> Abrevierea stiintifica:%s\n-> Varsta maxima:%u\n",
              a[i].nr_picioare,a[i].greutate,a[i].abreviere,a[i].varsta_maxima);
        if(a[i].periculos==1)
            printf("-> Este periculos pentru om\n");
              else
            printf("-> Nu este periculos pentru om\n");
    }
    printf("\n");
}
int main()
{
    printf("Spatiul de memorare ocupat: %ld octeti\n", sizeof(Animale));
    Animale a[10];
    int opt, n = -1;

    do{
        printf("\t1.Citire animale\n");
        printf("\t2.Afisare informatii despre animale\n");
        printf("\t0.Iesire\n");
        printf("Introduceti optiunea:");
        scanf("%d", & opt);
        switch (opt)
        {
            case 1:
                        citire(a, &n);
            break;
            case 2:
                        afisare(a, n);
            break;
            case 0: exit(0);
            break;
            default:
                        printf("Optiunea nu exista!");
            break;
        }
    }while(1);
    return 0;
}
