#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct{
    char variabila[10],
            legatura[4],
            valoare[10];
}T;

int var(char *s)
{
    int i;
    if(!((s[0]>='a'&&s[0]<='z')||(s[0]>='A'&&s[0]<='Z')))
        return 0;
    for(i=0;s[i]!='\0';i++)
    if(!((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9')))
        return 0;
    return 1;
}

int val(char *s)
{
    int i,n=strlen(s)-1;
    for(i=1;i<n;i++)
    if(!((s[0]=='"'&&s[n]=='"')||(s[i]>='0'&&s[i]<='9')||( strchr("'",s[0]) && strchr("'",s[n]))))
        return 0;
    return 1;
}

void citire(T *t, int *n)
{
    (*n)++;
    printf("Introduceti variabila:"); scanf("%s",(t+*n)->variabila);
    if(var((t+*n)->variabila)==0)
    {
        printf("Variabila nu corespunde!");
        exit(0);
    }
    printf("Introduceti egalul:"); scanf("%s",(t+*n)->legatura);
    if(strcmp((t+*n)->legatura,"=")!=0)
    {
        printf("Legatura se face prin egal!");
        exit(0);
    }
    printf("Introduceti valoarea:"); scanf("%s",(t+*n)->valoare);
    if(val((t+*n)->valoare)==0)
    {
        printf("Valoarea nu corespunde!");
        exit(0);
    }
}

void afisare(T *t, int *n)
{
    int i;
    for(i=0;i<=*n;i++)
    printf("%s %s %s",(t+i)->variabila,(t+i)->legatura,(t+i)->valoare);
}

int main()
{
    T t[10];
    int opt,n=-1;
    do
    {
        printf("\t1.Citire\n");
        printf("\t2.Afisare\n");
        printf("\t0.Iesire\n");
        printf("Introduceti optiunea:");
        scanf("%d",&opt);
        switch(opt)
        {
            case 1: citire(t,&n);
            break;
            case 2: afisare(t,&n);
                        printf("\n");
            break;
            case 0: exit(0);
            break;
            default: printf("Optiunea nu exista!\n");
            break;
        }
    } while (1);

    return 0;
}

