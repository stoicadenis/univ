#include<stdio.h>
#include<stdlib.h>

/*typedef enum { TMBenzina, TMMotorina, TMElectric }TipMotor;
typedef enum { TVPersoane, TVMarfa, TVSpecial }TipVehicul;
const char* numeTM[] = { "benzina" ,"motorina", "electric" };
const char* numeTV[] = { "tip persoane","tip marfa","tip special" };

typedef struct {
	TipMotor tm;
	char marca[20];
	TipVehicul tv;
	union {
		struct {
			int nrLocuri;
			int nrAirbaguri;
		} VehiculPersoane;
		struct {
			double capacitate;
			char frigorific; // false (0), true (1)
		} VehiculMarfa;
		char special[20]; 
	} specific;
} Vehicul;

void citireSpecific(Vehicul* v) {
	switch (v->tv)
	{
	case 0:
		printf("Nr de locuri: ");
		scanf("%d", &v->specific.VehiculPersoane.nrLocuri);
		printf("Nr airbaguri: ");
		scanf("%d", &v->specific.VehiculPersoane.nrAirbaguri);
		break;
	case 1:
		printf("Capacitate: ");
		scanf("%lf", &v->specific.VehiculMarfa.capacitate);
		printf("Frigorific (0 - false, 1 - true): ");
		scanf("%hhd", &v->specific.VehiculMarfa.frigorific);
		break;
	case 2:
		printf("Numele intrebuintarii specifice: ");
		scanf("%s", v->specific.special);
		break;
	default:
		printf("Gresit!");
		exit(0);
		break;
	}
}

void afisareTipMotor(Vehicul* v)
{
	printf("tip motor : %s\n", numeTM[v->tm]);
}

void afisareTipVehicol(Vehicul* v)
{
	printf("tip motor : %s\n", numeTV[v->tv]);
	switch (v->tv)
	{
	case 0:
		printf("Nr de locuri: %d\n", v->specific.VehiculPersoane.nrLocuri);
		printf("Nr airbaguri: %d\n", v->specific.VehiculPersoane.nrAirbaguri);
		break;
	case 1:
		printf("Capacitate: %.2lf\n", v->specific.VehiculMarfa.capacitate);
		printf("Frigorific (0 - false, 1 - true): %hhd\n", v->specific.VehiculMarfa.frigorific);
		break;
	case 2:
		printf("Numele intrebuintarii specifice: %s\n", v->specific.special);
		break;
	default:
		break;
	}
}

void afisare(Vehicul* v) {
	afisareTipMotor(v);
	printf("Marca: %s\n", v->marca);
	afisareTipVehicol(v);
}

void citire(Vehicul* v)
{
	int tm;
	printf("Tip motor (0 - benzina, 1 - motorina, 2 - electric): ");
	scanf("%d", &tm);
	v->tm = tm;
	printf("Marca: ");
	scanf("%s", v->marca);
	printf("Tip vehicul (0 - de persoane, 1 - de marfa, 2 - special): ");
	scanf("%d", &v->tv);
	citireSpecific(v);
}

int main() {
	Vehicul v;
	citire(&v);
	afisare(&v);

	return 0;
}*/