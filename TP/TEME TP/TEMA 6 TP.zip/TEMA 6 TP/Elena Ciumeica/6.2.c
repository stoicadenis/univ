#include<stdlib.h>
#include<stdio.h>

/*typedef enum { mamifer, insecta, peste, pasare} NumeAnimal;
const char* numeAnimal[] = { "mamifer", "insecta", "peste", "pasare" };

typedef struct {
	unsigned int tip;
	float durataMViata;
	union {
		struct {
			unsigned int perioadaGestatie:4, nrPui:3;
		} mamifer;
		struct {
			unsigned int nrPicioare;
			char zboara, periculoasa;
		} insecta;
		struct {
			char tipApa;
			float adincimea, viteza;
		} peste;
		struct {
			float anvelgura, altitudine, viteza;
		} pasare;
	} tipselectie;
} animal;

void afisareNumeAnimal(animal* a) {
	printf("Tip animal: %s\n", numeAnimal[a->tip]);
}

void afisare(animal* a) {
	afisareNumeAnimal(a);
	printf("durata medie de viata: %d\n", a->durataMViata);
	switch (a->tip)
	{
	case 0:
		printf("perioada de gestatie: %d\n", a->tipselectie.mamifer.perioadaGestatie);
		printf("nr mediu de pui: %d\n", a->tipselectie.mamifer.nrPui);
		break;
	case 1:
		printf("nr picioare: %d\n", a->tipselectie.insecta.nrPicioare);
		printf("zboara (0-fals,1-adev): %hhd\n", a->tipselectie.insecta.zboara);
		printf("periculoasa (0-fals,1-adev): %hhd\n", a->tipselectie.insecta.periculoasa);
		break;
	case 2:
		printf("tip apa (0-sarata,1-dulce): %hhd\n", a->tipselectie.peste.tipApa);
		printf("adincime: %.2f\n", a->tipselectie.peste.adincimea);
		printf("viteza: %.2f\n", a->tipselectie.peste.viteza);
		break;
	case 3:
		printf("anvelgura: %.2f\n", a->tipselectie.pasare.anvelgura);
		printf("altitudine: %.2f\n", a->tipselectie.pasare.altitudine);
		printf("viteza: %.2f\n", a->tipselectie.pasare.viteza);
		break;
	default:
		exit(0);
		break;
	}
}

void citire(animal* a) {
	int aux;
	printf("Tip animal (0-mamifer, 1-insecta, 2-peste, 3-pasare): ");
	scanf("%d", &a->tip);
	printf("durata medie de viata: ");
	scanf("%d", &a->durataMViata);
	switch (a->tip)
	{
	case 0:
		printf("perioada de gestatie: ");
		scanf("%d", &aux);
		a->tipselectie.mamifer.perioadaGestatie = aux;
		printf("nr mediu de pui: ");
		scanf("%d", &aux);
		a->tipselectie.mamifer.nrPui = aux;
		break;
	case 1:
		printf("nr picioare: ");
		scanf("%d", &a->tipselectie.insecta.nrPicioare);
		printf("zboara (0-fals,1-adev): ");
		scanf("%hhd", &a->tipselectie.insecta.zboara);
		printf("periculoasa (0-fals,1-adev): ");
		scanf("%hhd", &a->tipselectie.insecta.periculoasa);
		break;
	case 2:
		printf("tip apa (0-sarata,1-dulce): ");
		scanf("%hhd", &a->tipselectie.peste.tipApa);
		printf("adincime: ");
		scanf("%f", &a->tipselectie.peste.adincimea);
		printf("viteza: ");
		scanf("%f", &a->tipselectie.peste.viteza);
		break;
	case 3:
		printf("anvelgura: ");
		scanf("%f", &a->tipselectie.pasare.anvelgura);
		printf("altitudine: ");
		scanf("%f", &a->tipselectie.pasare.altitudine);
		printf("viteza: ");
		scanf("%f", &a->tipselectie.pasare.viteza);
		break;
	default:
		exit(0);
		break;
	}
}

int main() {
	animal a;
	citire(&a);
	afisare(&a);

	return 0;
}*/