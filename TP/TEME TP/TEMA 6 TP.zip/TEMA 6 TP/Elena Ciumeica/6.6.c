#include<stdio.h>
#include<stdlib.h>

/*const char* periculozitate[] = { "scazuta","medie","mare" };
const char* reteta_text[] = { "nu", "da" };

typedef struct {
	unsigned char
		periculozitate : 2,
		reteta : 1,
		virsta : 5;
} medicament;

void citire(medicament* m) {
	unsigned int aux;
	printf("Periculozitate (0-scazuta,1-medie,2-mare): ");
	scanf("%u", &aux);
	m->periculozitate = aux;
	printf("Reteta (0-nu,1-da): ");
	scanf("%u", &aux);
	m->reteta = aux;
	printf("Virsta (1-18 ani): ");
	scanf("%u", &aux);
	m->virsta = aux;
}

void afisare(medicament* m) {
	printf("Periculozitate: %s\nNecesita reteta: %s\nVirsta: %u ani\n", periculozitate[m->periculozitate], reteta_text[m->reteta], m->virsta);
}

int main() {
	medicament m;
	citire(&m);
	afisare(&m);

	return 0;
}*/