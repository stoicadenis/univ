#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 30

/*typedef struct {
	char nume[MAX], valoare[MAX];
} tip_string;

typedef struct {
	char nume[MAX];
	char valoare;
} tip_char;

typedef struct {
	char nume[MAX]; 
	float valoare;
} tip_numar;

typedef struct {
	union {
		tip_string s;
		tip_char c;
		tip_numar n;
	} data;
	char numetip;
} tip;

int validareNume(char* str) {
	int i;

	if (!((str[0] <= 'z' && str[0] >= 'a') || (str[0] <= 'Z' && str[0] >= 'A'))) {
		return 0;
	}

	for (i = 0; str[i] != '\0'; i++) {
		if (!((str[i] <= 'z' && str[i] >= 'a') || (str[i] <= 'Z' && str[i] >= 'A') || (str[i] <= '9' && str[i] >= '0'))) {
			return 0;
		}
	}

	return 1;
}

void trim(char* str, char c) {
	int i = strlen(str);
	if (str[i - 1] == c)
		str[i - 1] = '\0';
	if (str[0] == c) {
		for (i = 0; str[i] != '\0'; i++) {
			str[i] = str[i + 1];
		}
	}
}

int separare(char* str, char sign, char* nume, char* valoare) {
	int i, k;
	for (i = 0; str[i] != sign; i++) {
		nume[i] = str[i];
	}
	nume[i] = '\0';
	for (k = i + 1; str[k] != '\0'; k++) {
		valoare[k - i - 1] = str[k];
	}
	valoare[k - i - 1] = '\0';
}

char getType(char* str, float* nr) {
	char* end;
	*nr = strtof(str, &end);
	if (str[0] == '\"' && str[strlen(str) - 1] == '\"') {
			return 's';
	}
	else if(str[0] == '\'' && str[strlen(str) - 1] == '\'' && strlen(str) == 3) {
		return 'c';
	}
	else if (*end == '\0') {
		return 'n';
	}
	return ' ';
}

void afisare(tip* t) {
	switch (t->numetip)
	{
	case 's':
		printf("%s=\"%s\" is a string", t->data.s.nume, t->data.s.valoare);
		break;
	case 'c':
		printf("%s='%c' is a char", t->data.c.nume, t->data.c.valoare);
		break;
	case 'n':
		printf("%s=%.2f is a number", t->data.n.nume, t->data.n.valoare);
		break;
	default:
		break;
	}
}

void citire(tip* t) {
	char input[MAX], nume[MAX], valoare[MAX], type;
	float nr;
	fgets(input, MAX, stdin);
	if ((strlen(input) > 0) && (input[strlen(input) - 1] == '\n'))
		input[strlen(input) - 1] = '\0';
	if (!strstr(input, "="))
		return;
	separare(input, '=', nume, valoare);
	if (!validareNume(nume))
		return;
	type = getType(valoare, &nr);
	trim(valoare, '\'');
	trim(valoare, '\"');
	t->numetip = type;
	switch (type)
	{
	case 's':
		strcpy(t->data.s.nume, nume);
		strcpy(t->data.s.valoare, valoare);
		break;
	case 'c':
		strcpy(t->data.c.nume, nume);
		t->data.c.valoare = valoare[0];
		break;
	case 'n':
		strcpy(t->data.n.nume, nume);
		t->data.n.valoare = nr;
		break;
	default:
		return;
	}
	afisare(t);
}

int main() {
	tip t;
	printf("Scrieti sub forma: nume_variabila=valoare\n");
	citire(&t);

	return 0;
}*/