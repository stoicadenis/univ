#include<stdio.h>
#include<stdlib.h>

/*const char* multi_text[] = { "pico", "nano", "mili", "centi", "deci", "", "deca", "hecto", "kilo", "mega", "giga" };
const char*  unitate_text[] = { "gram", "metru", "litru" };

typedef struct {
	unsigned short
		valoare : 10,
		unitate : 2,
		multiplicator : 4;
} masurator;

void afisare(masurator* m) {
	printf("Valoare: %u\nUnitate: %s%s\n", m->valoare, multi_text[m->multiplicator], unitate_text[m->unitate]);
}

void citire(masurator* m) {
	unsigned int val, unit, prefix = 5;
	printf("Valoare = ");
	scanf("%u", &val);
	printf("Unitate (0-gram,1-metru,2-litru) = ");
	scanf("%d", &unit);
	while (val > 0 && val % 10 == 0) {
		val /= 10;
		prefix++;
	}
	if (val > 1023) {
		printf("Valoarea nu incape\n");
		return;
	}
	m->valoare = val;
	m->unitate = unit;
	m->multiplicator = prefix;
	afisare(m);
}

int main() {
	masurator m;
	citire(&m);

	return 0;
}*/