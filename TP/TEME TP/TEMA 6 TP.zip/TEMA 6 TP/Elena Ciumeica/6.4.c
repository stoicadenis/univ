#include<stdio.h>
#include<stdlib.h>

/*typedef struct {
	unsigned int
		periculos : 1,
		picioare : 11,
		virsta : 11;
	float greutate;
	char abreviere[8];
} animal;

void citire(animal* a) {
	unsigned int value;
	printf("\npicioare (0,1000): ");
	scanf("%u", &value); 
	a->picioare = value;
	printf("\ngreutate: ");
	scanf("%u", &value); 
	a->greutate = value;
	printf("\npericulos(1,0): ");
	scanf("%u", &value); 
	a->periculos = value;
	printf("\nvirsta(0,2000): ");
	scanf("%u", &value); 
	a->virsta = value;
	printf("\abreviere (8 char): ");
	scanf("%s", a->abreviere);
}

void afisare(animal* a) {
	printf("\npicioare: %u\ngreutate: %.2f kg\npericulos: %u\nvirsta:%u\nabreviere: %s", a->picioare, a->greutate, a->periculos, a->virsta, a->abreviere);
}

int main() {
	animal a;
	citire(&a);
	afisare(&a);
	printf("\nDimensiune: %d octeti", sizeof(a));

	return 0;
}*/