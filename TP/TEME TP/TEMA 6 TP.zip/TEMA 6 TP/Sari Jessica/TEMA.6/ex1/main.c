#include <stdio.h>
#include <stdlib.h>

typedef enum{TMBenzina, TMMotorina, TMElectric}TipMotor;
typedef enum{TVPersoane, TVMarfa, TVSpecial}TipVehicul;

typedef struct vehiicul
{
    TipMotor tm;
    char marca[20];
    TipVehicul tv;
    union{
        struct{
            int nrLocuri;
            int nrAirbaguri;
            }p;
        struct{
            double capacitate;
            char frigorific;
            }m;
        char special[20];
        }specific;
    }Vehicul;

void citire(Vehicul *v, int *n)
{
    (*n)++;
    printf("tip motor (0-benzina, 1-motorina, 2-electric): ");
    scanf("%d",&(v+*n)->tm);
    printf("Marca: ");
    scanf("%s",(v+*n)->marca);
    printf("Tipul vechiculului: 0-persoane 1-marfa 2-special ");
    scanf("%d",&(v+*n)->tv);
    switch((v+*n)->tv)
    {
        case 0:
        printf("NrLocuri: ");
        scanf("%d",&(v+*n)->specific.p.nrLocuri);
        printf("NrAirbaguri: ");
        scanf("%d",&(v+*n)->specific.p.nrAirbaguri);
        break;
        case 1:
        printf("Capacitate: ");
        scanf("%d",&(v+*n)->specific.m.capacitate);
        printf("Frigorific? 0- nu, 1-da ");
        scanf("%hhd",&(v+*n)->specific.m.frigorific);
        break;
        case 2:
        printf("Special: ");
        scanf("%s",(v+*n)->specific.special);
        break;
    }
}

void afisare(Vehicul *v, int *n)
{
    int i;
    for(i=0;i<=*n;i++)
    {
        switch((v+i)->tm)
        {
            case 0:
            printf("Motor pe benzina\n");
            break;
            case 1:
            printf("Motor pe motorina\n");
            break;
            case 2:
            printf("Motor electric\n");
        }
        printf("Marca: %s\n",(v+i)->marca);
        switch((v+i)->tv)
        {
            case 0:
            printf("Vehicul cu persoane\n");
            printf("Nr de locuri: %d\nNr de airbaguri: %d\n",(v+i)->specific.p.nrLocuri,(v+i)->specific.p.nrAirbaguri);
            break;
            case 1:
            printf("Vehicul cu marfa\n");
            printf("Capacitatea: %d\n",(v+i)->specific.m.capacitate);
            if((v+i)->specific.m.frigorific==0) printf("Nu este frigorific\n");
            else
            printf("Este frigorific\n");
            break;
            case 2:
            printf("Vehicul special\n");
            printf("Specific special: %s\n",(v+i)->specific.special);

        }
    }
}

int main()
{
    Vehicul v[20];
    int n=-1, opt;
    do
    {
        printf("1.Adaugare vehicul\n");
        printf("2.Afisare\n");
        printf("0.Iesire\n");
        printf("Optiune: ");
        scanf("%d",&opt);
        switch(opt)
        {
            case 1:
            citire(v,&n);
            break;
            case 2:
            afisare(v,&n);
            printf("\n");
            break;
            case 0:
            exit(0);
            break;
            default:
            printf("Optiune gresita\n");
            break;
        }
    } while (1);
    return 0;
}
