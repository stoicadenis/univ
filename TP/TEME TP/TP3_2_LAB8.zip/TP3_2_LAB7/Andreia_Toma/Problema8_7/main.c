#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nr1, nr2;
    short  nr;

    printf("nr1 = ");
    scanf("%d",&nr1);
    printf("nr2 = ");
    scanf("%d", &nr2);

    nr = 0;
    nr+=nr1;
    nr = nr<<8;
    nr+=nr2;

    printf("nr = %d\n", nr);
    printf("nr>>8 = %d\n", nr>>8);
    printf("nr&256 = %d\n", nr&255);

    return 0;
}

