#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nr;
    printf("introduceti numarul de verificat: ");
    scanf("%d", &nr);
    if (( nr & 1 ) == 1)
        printf("Acest numar este impar");
    else
        printf("Acest numar este par");
    return 0;
}
