#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nr;
    printf("Dati numarul: ");
    scanf("%d", &nr);
    printf("Catul este: %d\n",(nr >> 3));
    printf("Restul este: %d", (nr & 7));
    return 0;
}
