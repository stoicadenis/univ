#include <stdio.h>
#include <stdlib.h>

int main()
{
 unsigned int nr, bit;

 printf("nr = ");
 scanf("%d", &nr);
 printf("bit = ");
 scanf("%d",&bit);

 nr = nr | (1<<bit);

 printf("nr = %d", nr);
    return 0;
}
