#include <stdio.h>
#include <stdlib.h>

int main()
{


        int nr, poz;
        printf("dati nr") ;
        scanf("%d", &nr);
        for (poz=15 ; poz >= 0 ; poz--)
        {
            printf("%d",((nr >> poz) & 1)) ;
        }

        return 0;
    }
