#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nr1, nr2,i;
    unsigned short nr;
    printf("nr1=");
    scanf("%d", &nr1);
    printf("nr2=");
    scanf("%d", &nr2);
    nr = nr1 * 256 + nr2;
    for (i = 15; i >= 0; i--)
        printf("%d", (nr >> i) & 1);
    return 0;
}
