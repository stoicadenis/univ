#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nr,bit,i;
    printf("nr="); scanf("%d", &nr);
    printf("Introduceti bitul pe care doriti sa il schimbati:"); scanf("%d", &bit);
    printf("nr in baza 2: ");
        for (i=15; i>=0; i--)
            printf("%d",((nr >> i)&1));
    nr=nr|(1<<bit);
    printf("\nnr modificat: ");
        for (i=15; i>=0; i--)
            printf("%d",((nr>>i)&1));
    return 0;
}
