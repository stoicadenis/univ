#include <stdio.h>
#include <stdlib.h>
int main()
{
    int nr,s=0;
    printf("nr="); scanf("%d",&nr);
    while((nr|0))
    {
        if((nr&1)==1)
            s=s+1;
     nr=nr>>1;
    }
        if(s>1)
            printf("Nr nu este o putere a lui 2");
        else
    printf("Nr este o putere a lui 2");

    return 0;
}
