#include <stdio.h>

int main()
{
    int nr, bit=0, aux, poz;
    printf("Introduceti numarul: ");
    scanf("%d", &nr);
    aux=nr;
    for(poz=15; poz>=0; poz--)
        if(((nr>>poz)&1)==1) {
            bit++;
        }
    if(bit==1)
        printf(" Numarul %d este putere a lui 2.\n", aux);
    else printf(" Numarul %d NU este putere a lui 2.\n", aux);
    return 0;
}
