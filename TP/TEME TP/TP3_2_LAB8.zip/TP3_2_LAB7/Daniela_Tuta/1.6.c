#include <stdio.h>

int conditie(int bit)
{
    if(bit<0||bit>15)
        return 0;
    return 1;
}

int main()
{
    unsigned int nr, bit;
    int poz;
    printf("Introduceti numarul: ");
    scanf("%d", &nr);
    printf(" Decimal: %d -> Binary: ", nr);
    for(poz=15; poz>=0; poz--)
        printf(" %d", ((nr>>poz)&1));
    printf("\n");
    printf("\nIntroduceti pozitia bitului pe care doriti sa il setati: ");
    scanf("%d", &bit);
    if(conditie(bit)==0)
        printf("***Pozitia trebuie sa fie cuprinsa in intervalul [0; 15] ***\n");
    else {
        nr=(nr|(1<<bit));
        printf("Noul numar este %d ->  ", nr);
        for(poz=15; poz>=0; poz--)
            printf(" %d", ((nr>>poz)&1));
    }
    printf("\n\n");
    return 0;
}

