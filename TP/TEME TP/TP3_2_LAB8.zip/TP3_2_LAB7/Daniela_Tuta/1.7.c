#include <stdio.h>

int conditie(int nr)
{
    if(nr<0||nr>255)
        return 0;
    return 1;
}

int main()
{
    int nr, nr1, nr2, poz;
    printf("Introduceti primul numar: ");
    scanf("%d", &nr1);
    if(conditie(nr1)==0)
        printf("\n Numarul %d nu apartine intervalului [0; 255]\n", nr1);
    else {
        printf(" nr1 =");
        for(poz=15; poz>=0; poz--)
            printf(" %d", ((nr1>>poz)&1));
        printf("\n\nIntroduceti al doilea numar: ");
        scanf("%d", &nr2);
        if(conditie(nr2)==0)
            printf("\n Numarul %d nu apartine intervalului [0; 255]\n", nr2);
        else {
            printf(" nr2 =");
            for(poz=15; poz>=0; poz--)
                printf(" %d", ((nr2>>poz)&1));
            nr=nr1*256+nr2;
            printf("\n\n nr = ");
            for(poz=15; poz>=0; poz--)
                printf(" %d", ((nr>>poz)&1));
        }
    }
    printf("\n\n nr1 = %d\n", (nr>>8)); // nr1 = nr/256
    printf("\n nr2 = %d\n", (nr&255)); // nr2 = nr%256
    printf("\n");
    return 0;
}
