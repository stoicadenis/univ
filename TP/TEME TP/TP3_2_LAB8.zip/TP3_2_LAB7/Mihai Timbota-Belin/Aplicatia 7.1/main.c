#include <stdio.h>
#include <stdlib.h>

int *citire(int n)
{
    int *v,i;


    v=(int*)(malloc(n*sizeof(int)));
    if(!v)
    {
        printf("memorie insuficienta\n");
        exit(EXIT_FAILURE);
    }

    for(i=0;i<n;i++)
    {
        printf("v[%d] = ",i);
        scanf("%d",&v[i]);
    }

    return v;
}

int main()
{
    int *v, *p, n, m,i,j;

    printf("m = ");
    scanf("%d",&m);
    v=citire(m);

    printf("n = ");
    scanf("%d",&n);
    p=citire(n);

    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
           if(v[i]==p[j])
           {
               printf("%d ",v[i]);
               break;
           }

    free(v);

    return 0;
}
