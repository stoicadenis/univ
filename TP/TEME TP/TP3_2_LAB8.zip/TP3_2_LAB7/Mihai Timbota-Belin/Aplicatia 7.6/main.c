#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *nume;
    int nr;
} student;

#define SIZE sizeof(student)

typedef student *pstud;

void eroare(void)
{
    puts("\n  **** eroare alocare dinamica de memorie ****");
    exit(1);
}

void citeste(int *n, pstud *tab)
{
    pstud t;
    char sir[40];
    int i;
    printf("\ndati numarul studentilor:");
    scanf("%d", n);
    if(!(t=(pstud)malloc((*n)*SIZE)))  eroare();
    *tab=t;

    for (i=0; i<*n; i++, t++)
    {
        printf("\nnume: ");
        scanf("%s", sir); /* aloca dinamic spatiu pentru numele studentului*/
        if (!(t->nume=(char *) malloc(strlen(sir)+1))) eroare();
        strcpy(t->nume, sir);
        printf("\nnumar matricol: ");
        scanf("%d", &t-> nr);
        getchar();
    }

}

void afiseaza( int n, pstud tab)
{
    int i;
    puts("\n tabelul cu studenti");
    for (i=0; i<n; i++, tab++)
        printf("\n%-30s %4d", tab->nume, tab->nr);
}

void elibereaza(pstud tabel, int n)
{
    int i;
    for (i=0; i<n; i++) free(tabel[ i ].nume);
    free(tabel);
}

void sorteaza_alfabetic(pstud tab, int n)
{

    int i,j;
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
            if(strcmp(tab[i].nume,tab[j].nume)>0)
            {
                student aux;
                aux=tab[i];
                tab[i]=tab[j];
                tab[j]=aux;
            }
}

sorteaza_dupa_nr_matricol(pstud tab, int n)
{
    int i,j;
    for(i=0; i<n-1; i++)
        for(j=i+1; j<n; j++)
            if(tab[i].nr>tab[j].nr)
            {
                student aux;
                aux=tab[i];
                tab[i]=tab[j];
                tab[j]=aux;
            }
}

void cauta_dupa_nume(student s, pstud tab, int n)
{
    int i;
    sorteaza_alfabetic(tab, n);

    for(i=0; i<n; i++)
        if(strcmp(s.nume, tab[i].nume)==0)
            break;
    if(i==n)
        printf("\nstudentul nu exista");
    else
    {
        printf("\n%-30s %4d", tab[i].nume, tab[i].nr);
        printf("\nstudentul se afla pe pozitia %d",i);
    }

}

void  cauta_dupa_nr_matricol(student s, pstud tab, int n)
{
    int i;
    sorteaza_dupa_nr_matricol(tab, n);

    for(i=0; i<n; i++)
        if(s.nr==tab[i].nr)
            break;
    if(i==n)
        printf("\nstudentul nu exista");
    else
    {
        printf("\n%-30s %4d", tab[i].nume, tab[i].nr);
        printf("\nstudentul se afla pe pozitia %d",i);
    }
}




void meniu(void)
{
    puts("\n c, C ---citeste tabel studenti");
    puts("\n a, A ---afiseaza tabel studenti");
    puts("\n n, N ---ordoneaza dupa nume");
    puts("\n r, R ---ordoneaza dupa numar matricol");
    puts("\n f, F ---cauta dupa nume");
    puts("\n l, L ---cauta dupa numar matricol");
    puts("\n x, X ---iesire din program");
}



int main()
{

    char opt;
    int n;   /* numarul de studenti*/
    char nume[30];
    student s;
    pstud tabel=NULL; /* adresa tabloului cu studenti*/
    while (1)
    {
        meniu();
        opt=tolower(getchar());
        getchar();
        switch(opt)
        {
        case 'c':
            if(tabel)/* daca a existat anterior un alt tabl. in mem.*/
                elibereaza(tabel, n);
            citeste(&n, &tabel);
            break;
        case 'a':
            afiseaza(n, tabel);
            break;
        case 'n':
            sorteaza_alfabetic(tabel, n);
            printf("sortarea a fost efectuata\n");
            break;
        case 'r':
            sorteaza_dupa_nr_matricol(tabel, n);
            printf("sortarea a fost efectuata\n");
            break;
        case 'f':
            printf("\ndati numele:");
            scanf("%s", nume);
            getchar();
            if (!(s.nume=(char *)malloc(strlen(nume)+1))) eroare();
            strcpy(s.nume, nume);
            cauta_dupa_nume(s, tabel, n);
            free(s.nume);
            break;
           case 'l':
               printf("\ndati numarul matricol:");
               scanf("%d", &s.nr);
               getchar();
               cauta_dupa_nr_matricol(s, tabel, n);
               break;
        case 'x':
            exit(0);

        default:
            puts("Comanda gresita");
        }
    }



    return 0;
}
