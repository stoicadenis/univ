#include <stdio.h>
#include <stdlib.h>

int *citire(int n)
{
    int i;
    int *v;
    if((v = (int *)malloc(n * sizeof(int)))==NULL)
        {
            printf("memorie insuficienta\n");
            exit(EXIT_FAILURE);
        }

    for(i=0;i<n;i++)
    {

        printf("v[%d] = ",i);
        scanf("%d",&v[i]);
    }


    return v;
}

int main()
{
    int *v, n, i;

    printf("n = ");
    scanf("%d", &n);
    v=citire(n);

    for(i=n-1; i>=0; i--)
        printf("%d ",v[i]);

    free(v);
    return 0;
}
