#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char a[101], b[101], *c;
    int i;

    fgets(a,101,stdin);
    fgets(b,101,stdin);
    a[strcspn(a,"\n")]='\0';
    b[strcspn(b,"\n")]='\0';

    c = (char*)(malloc((strlen(a)+strlen(b)+2)*sizeof(char)));
    if(c == NULL)
    {
        printf("memorie insuficienta\n");
        exit(EXIT_FAILURE);
    }
   for(i=0;i<=strlen(a);i++)
    c[i]=a[i];
    c[strlen(a)]=' ';
    for(i=strlen(a)+1;i<=strlen(a) + 1 + strlen(b);i++)
        c[i]=b[i-(strlen(a)+1)];

    //printf("%s", c);

    free(c);
    return 0;
}
