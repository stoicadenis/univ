#include <stdio.h>
#include <stdlib.h>
#include <string.h>




char *linie()
{
    char *buf = NULL;
    char * buf2;
    char ch;
    size_t n =0;

    for(;;)
    {
        n++;
        buf2 = (char*)(realloc(buf,n));
        if(buf2 == NULL)
        {
            free(buf);
            printf("memorie insuficienta\n");
            exit(EXIT_FAILURE);
        }

        buf = buf2;

        ch = getchar();


        if(ch == '\n' || ch == '\t' || ch == ' ')
            break;
        buf[n-1]=ch;
    }
    buf[n-1]='\0';
    return buf;

}



int main()
{

    char *p, *text, *text2;

    text=(char*)(malloc(1));
    text[0]='\0';



    for(;;)
    {
        p=linie();
        if(strlen(p)==0)
        {
            free(p);
            break;
        }

        if(strcmp(p," ") && strcmp(p,"\t") && strcmp(p, "\n"))
        {


            if(strcmp(text,""))
            {
                if(tolower(text[strlen(text)-1])==tolower(p[1]) && tolower(text[strlen(text)-2])==tolower(p[0]))
                {

                    text2=(char*)(realloc(text, (strlen(text)+strlen(p)+2)*sizeof(char)));
                    if(!text2)
                    {
                        free(text);
                        printf("memorie insuficienta\n");
                        exit(EXIT_FAILURE);
                    }

                    text=text2;

                    strcat(text,"-");
                    strcat(text,p);

                }
            }
            else
            {

                text2=(char*)(realloc(text, (strlen(text)+strlen(p)+2)*sizeof(char)));
                if(!text2)
                {
                    free(text);
                    printf("memorie insuficienta\n");
                    exit(EXIT_FAILURE);
                }

                text=text2;
                strcat(text,p);

            }



        }
    }

    printf("%s\n",text);


    return 0;
}
