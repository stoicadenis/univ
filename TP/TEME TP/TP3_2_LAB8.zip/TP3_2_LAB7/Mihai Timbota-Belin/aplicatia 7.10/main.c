#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=0;
    void *mem=NULL;

    for(;;)
    {printf("%d KB\n",i);
        mem=(realloc(mem,i*1024));
        i+=1000;
        if(mem==NULL)
        {
            printf("%d KB FINAL",i);
            exit(EXIT_FAILURE);
        }
    }
    return 0;
}
