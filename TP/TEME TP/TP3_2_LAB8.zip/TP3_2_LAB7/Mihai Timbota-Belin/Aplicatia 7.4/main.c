#include <stdio.h>
#include <stdlib.h>

int *citire(int *n)
{
    *n=0;
    int *v = NULL;
    int *v2;

    for(;;)
    {
        int k;
        printf("v[%d] = ",*n);
        scanf("%d",&k);

        if(!k)
            break;
        (*n)++;
        if((v2 = (int *)realloc(v,(*n)*sizeof(int)))==NULL)
        {
            printf("memorie insuficienta\n");
            free(v);
            exit(EXIT_FAILURE);
        }
        v=v2;
        v[*n-1]=k;
    }
    return v;
}

int main()
{
    int *v, n, i;
    v=citire(&n);

    for(i=n-1; i>=0; i--)
        printf("%d ",v[i]);

    free(v);
    return 0;
}
