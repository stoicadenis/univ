#include <stdio.h>
#include <stdlib.h>

int doi()
{
    int x = 2;
    return x;
}
int main()
{
    int a;
    {
        int b = 5;
        a = b*doi();
    }
    printf("a = %d\n", a);
    system("pause");
    return 0;
}
