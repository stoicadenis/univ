/*Program care aloca spatiu pentru o variabila intreaga dinamica, dupa citire si tiparire, spatiul fiind eliberat.
Modificati programul astfel incat variabila dinamica sa fie de tip double.*/

#include <stdlib.h>
#include <stdio.h>

int main()
{
    int *pi;
    pi=(int *)malloc(sizeof(int));
    if(pi==NULL)
    {
        puts("*** Memorie insuficienta ***\n");
        return 1;       // revenire din main
    }

    printf("Valoare: ");  //citirea variabilei dinamice, de pe heap, de la adresa din pi!!!
    scanf("%d",pi);
    *pi=*pi*2;        // dublarea valorii
    printf("val=%d,pi(adresa pe heap)=%p,adr_pi=%p\n", *pi, pi, &pi);
    // sizeof aplicat unor expresii:
    printf("%d %d %d\n",sizeof(*pi), sizeof(pi), sizeof(&pi));
    free(pi);         //eliberare spatiu
    printf("pi(dupa elib):%p\n",pi); // nemodificat, dar invalid!

    system("pause");
    return 0;
}
