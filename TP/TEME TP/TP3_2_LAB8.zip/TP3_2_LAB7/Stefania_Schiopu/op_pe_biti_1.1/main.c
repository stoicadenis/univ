/*Se considera un numar natural retinut in variabila nr. Sa se verifice daca nr are valoare para sau impara.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
int nr;
printf("Introduceti nr: \n");
scanf("%d", &nr);
if(( nr & 1 ) == 1) // if (( nr & 1 ))
printf("Numar impar\n");
else
printf("Numar par\n");
system("pause");
return 0;
}
