/*Sa se scrie functii de alocare a memoriei si afisare a elementelor unei
matrice de intregi alocata dinamic.*/
#include <stdio.h>
#include <stdlib.h>

// rezultat adresa matrice sau NULL
int **intmat(int nl,int nc)
{
    int i;
    int **p=(int**)malloc(nl*sizeof(int*));
    if (p!=NULL)
        for (i=0; i<nl ;i++)
            p[i] =(int*)calloc(nc,sizeof (int));
    return p;
}

void printmat(int **a, int nl, int nc)
{
    int i,j;
    for (i=0;i<nl;i++)
    {
        for (j=0;j<nc;j++)
            printf ("%4d", a[i][j]);
        printf("\n");
    }
}

int main()
{
    int **a,nl,nc,i,j;
    printf ("Nr. linii si nr. coloane: \n");
    scanf ("%d %d", &nl, &nc);
    a=intmat(nl,nc);
    for (i=0;i<nl;i++)
        for (j=0;j<nc;j++)
            a[i][j]= nc*i+j+1;

    printmat(a,nl,nc);

    system("pause");
    return 0;
}
