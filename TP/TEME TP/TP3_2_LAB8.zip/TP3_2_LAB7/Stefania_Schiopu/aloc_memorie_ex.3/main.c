/*Un vector alocat dinamic se declara ca variabila pointer care se initializeaza cu rezultatul
functiei de alocare. Tipul variabilei pointer este determinat de tipul componentelor vectorului.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i;
    int *a;     // adresa vector alocat dinamic

    printf ("n=");
    scanf ("%d", &n);   // dimensiune vector
    a=(int*)calloc(n,sizeof(int)); // aloca memorie pentru vector
// sau: a=(int*) malloc (n*sizeof(int));
    // citire component vector:
    printf ("Componente vector: \n");
    for (i=0;i<n;i++)
        scanf ("%d", &a[i]);  // sau   scanf (�%d�, a+i);
    // afisare vector:
    for (i=0;i<n;i++)
        printf ("%d ",a[i]);
    printf("\n");
    system("pause");
    return 0;
}
