/*Se citeste valoarea unui numar natural nr. Sa se scrie reprezentarea lui nr in baza 2.*/

/*Stim ca in memorie nr este deja reprezentat in baza 2, deci ii vom scrie bitii de la stanga la dreapta. Presupunand ca nr este reprezentat pe 16 biti, deci ii numerotam de la dreapta la stanga cu valori de la 0 la 15.
Pentru a obtine bitul de pe pozitia poz (0<=poz<=15), folosim expresia
(nr>>poz)&1.*/


#include <stdio.h>
#include <stdlib.h>

int main()
{
int nr;
printf("Introduceti nr: ");
scanf("%d", &nr);
for(int poz=15;poz>=0;poz--)
{
    printf("%d",((nr>>poz)&1));
}
printf("\n");
system("pause");
return 0;
}
