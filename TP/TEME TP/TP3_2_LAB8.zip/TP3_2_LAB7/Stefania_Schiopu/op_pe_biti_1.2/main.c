/*Se citeste valoarea unui numar natural nr<=15. Sa se afiseze valoarea 2^nr.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
int nr;
printf("Introduceti nr: ");
scanf("%d", &nr);
printf("%d\n", (1 << nr));
system("pause");
return 0;
}
