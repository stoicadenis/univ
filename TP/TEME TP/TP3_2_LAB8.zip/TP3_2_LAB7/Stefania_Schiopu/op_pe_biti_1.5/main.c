/*Se citeste valoarea unui numar natural nr. Sa se verifice si sa se afiseze daca nr este sau nu este o putere a lui 2.*/

/*Daca nr este o putere a lui 2, atunci reprezentarea acestuia in baza 2 va avea un singur bit de 1, restul fiind 0, deci
am putea sa numaram cati biti de 1 are n in baza 2. Exista insa o soluţie mai rapida. Aceasta se bazeaza pe ideea ca daca
nr este o putere a lui 2, deci de forma 0000000000100000, atunci nr -1 are reprezentarea de forma 0000000000011111, adica
bitul 1 s-a transformat in 0, iar bitii de la dreapta sunt acum toti 1, asadar o expresie care are forma nr&(nr -1) va
furniza rezultatul 0 daca si numai daca nr este o putere a lui 2.*/

int main()
{
int nr;
printf("Introduceti nr: ");
scanf("%d", &nr);
if( (nr&(nr-1))==0)
printf("%d este putere a lui 2\n",nr);
else
printf("%d nu este putere a lui 2\n",nr);
system("pause");
return 0;
}
