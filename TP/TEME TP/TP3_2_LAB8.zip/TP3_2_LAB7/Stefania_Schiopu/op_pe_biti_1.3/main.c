/*Se citeste valoarea unui numar natural nr. Sa se determine catul si restul impartirii lui nr la 8.*/

/*Generalizare: sa se determine catul si restul impartirii lui nr la un numar care este putere a lui 2).
Spre a putea determinarea catul vom utiliza deplasarea la dreapta cu 3 biti (adica vom realiza echivalent o impartire prin 23).
Pentru rest vom folosi expresia nr & 7 (valoarea 7 a restului se obtine din 23-1). Dar 7 = 111(2) deci toti bitii lui nr se vor
anula, cu exceptia ultimilor 3 biti, cei mai din dreapta.*/


#include <stdio.h>
#include <stdlib.h>

int main()
{
int nr;
printf("Introduceti nr= ");
scanf("%d", &nr);
printf("Catul este: %d\n",(nr >> 3));
printf("Restul este: %d\n", (nr & 7));
system("pause");
return 0;
}
