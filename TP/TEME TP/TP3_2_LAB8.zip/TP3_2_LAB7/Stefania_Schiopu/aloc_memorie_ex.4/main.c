/*In exemplul urmator se citeste un numar necunoscut de valori intregi intr-un vector
extensibil: Program care citeste numere reale pana la CTRL+Z, le memoreaza intr-un vector
alocat si realocat dinamic in functie de necesitati si le afiseaza.*/

#include <stdio.h>
#include <stdlib.h>

#define INCR 4

int main()
{
    int n,n_crt,i;
    float x,*v;
    n = INCR;       // dimensiune memorie alocata
    n_crt = 0;      // numar curent elemente �n vector
    v = (float*)malloc(n*sizeof(float));  //alocare initiala
    while (scanf("%f",&x)!=EOF)
    {
        if (n_crt == n)
        {
            n = n + INCR;
            v = (float*)realloc(v,n*sizeof(float));  //realocare
        }
        v[n_crt++] = x;
    }
    for (i=0; i<n_crt; i++)
        printf ("%.2f ", v[i]);
    printf("\n");
    system("pause");
    return 0;
}
