#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <ctype.h>

char** str;
char* str2;

void eliberare(char** linii, int nrLin)
{
	int i;
	for (i = 0; i < nrLin; i++) {
		free(linii[i]);
	}
	free(linii);
}

int citire() {
	char c, ** aux, * aux2;
	char* a = NULL;
	int n = 0, nr = 0;
	do {
		n++;
		if ((aux2 = (char*)realloc(a, n)) == NULL) {
			printf("Not enough memory");
			eliberare(str, nr);
			exit(1);
		}
		a = aux2;
		c = getchar();
		if (c == ' ' || c == '\n') {
			nr++;
			if ((aux = (char**)realloc(str, nr*sizeof(char*))) == NULL) {
				printf("Not enough memory");
				eliberare(str, nr);
				free(a);
				exit(1);
			}
			str = aux;
			if ((str[nr - 1] = (char*)malloc(n)) == NULL) {
				printf("Not enough memory");
				eliberare(str, nr);
				free(a);
				exit(1);
			}
			a[n - 1] = '\0';
			strcpy(str[nr - 1], a);
			a = NULL;
			n = 0;
			if (c == '\n')
				break;
			continue;
		}
		a[n - 1] = c;
	} while (1);

	return nr;
}

char* toLower(char* st) {
	int i;
	char* rez = (char*)malloc(strlen(st) * sizeof(char));
	for (i = 0; i < strlen(st); i++) {
		rez[i] = tolower(st[i]);
	}
	rez[i] = 0;
	return rez;
}

void combine(int n) {
	int i;
	char* aux, * rez;
	str2 = (char*)malloc((strlen(str[0])+1) * sizeof(char));
	strcpy(str2, str[0]);
	for (i = 1; i < n; i++) {
		rez = toLower(str[i]);
		if (strstr(rez, str2 + strlen(str2) - 2) != NULL && strstr(rez, str2 + strlen(str2) - 2) == &rez[0]) {
			aux = (char*)realloc(str2, strlen(str2) + strlen(str[i]) + 2);
			str2 = aux;
			strcat(str2, "-");
			strcat(str2, str[i]);
		}
	}
}

void afisare(int n) {
	int i;
	for (i = n - 1; i >= 0; i--) {
		printf("%s\n", str[i]);
	}
}

int main() {
	int n = citire();
	//afisare(n);
	combine(n);
	printf("%s\n", str2);

	eliberare(str, n);
	free(str2);

	return 0;
}