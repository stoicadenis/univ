#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*void eliberare(char* linii, int nrLin)
{
	int i;
	for (i = 0; i < nrLin; i++) {
		free(linii[i]);
	}
	free(linii);
}
char* citire(int* n) {
	char c, *aux;
	char* a = NULL;
	do {
		(*n)++;
		if ((aux = (char*)realloc(a, *n)) == NULL) {
			printf("Not enough memory");
			free(aux);
			eliberare(a, *n);
			exit(1);
		}
		a = aux;
		c = getchar();
		if (c == '\n')
			break;
		a[(*n) - 1] = c;
	} while (1);
	a[(*n) - 1] = '\0';
	return a;
}

char* concat(char* a, char* b, int m, int n) {
	char* c = (char*)malloc((m + n + 1) * sizeof(char));
	strcpy(c, a);
	strcat(strcat(c, " "), b);
	return c;
}

int main() {
	char* s1 = NULL;
	char* s2 = NULL;
	char* s3 = NULL;
	int m = 0, n = 0;
	printf("Citire s1: ");
	s1 = citire(&m);
	printf("Citire s2: ");
	s2 = citire(&n);
	printf("%s\n", s1);
	printf("%s\n", s2);
	s3 = concat(s1, s2, m, n);
	printf("%s\n", s3);
	if (strcmp(concat("ab", "cd", 2, 2), "ab cd") == 0) {
		printf("Corect");
	}

	return 0;
}*/