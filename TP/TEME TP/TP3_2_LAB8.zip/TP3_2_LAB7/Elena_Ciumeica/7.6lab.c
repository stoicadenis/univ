#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*typedef struct {
	char* nume;
	int nr_matr;
} student;

int n;
student* st;

void citire() {
	char buf[80];
	student* aux;
	n++;
	aux = (student*)realloc(st, n * sizeof(student));
	if (!aux) {
		printf("Eroare alocare dinamica de memorie \n");
		exit(1);
	}
	st = aux;
	printf("Introduceti numele studentului %d: ", n);
	scanf("%s", buf);
	if ((st[n - 1].nume = (char*)malloc(strlen(buf) + 1)) == NULL) {
		printf("Eroare alocare dinamica de memorie\n");
		exit(1);
	}
	strcpy(st[n - 1].nume, buf);
	printf("Introduceti nr matricol %d: ", n);
	scanf("%d", &st[n - 1].nr_matr);
}

void afisare() {
	int i;
	for (i = 0; i < n; i++) {
		printf("Nume: %s Nr: %d\n", st[i].nume, st[i].nr_matr);
	}
}

void sortAlf() {
	int i, again;
	student aux;
	do {
		again = 0;
		for (i = 1; i < n; i++) {
			if (strcmp(st[i - 1].nume, st[i].nume) > 0) {
				aux = st[i - 1];
				st[i - 1] = st[i];
				st[i] = aux;
				again = 1;
			}
		}
	} while (again);
}

void sortCresc() {
	int i, again;
	student aux;
	do {
		again = 0;
		for (i = 1; i < n; i++) {
			if (st[i - 1].nr_matr > st[i].nr_matr) {
				aux = st[i - 1];
				st[i - 1] = st[i];
				st[i] = aux;
				again = 1;
			}
		}
	} while (again);
}

void cautareN() {
	int i;
	char x[80];
	printf("Nume cautat: ");
	scanf("%s", x);
	sortAlf();
	for (i = 0; i < n; i++) {
		if (strcmp(st[i].nume, x) == 0) {
			printf("Pozitia %d\n", i);
			return;
		}
	}
	printf("Nu a fost gasit\n");
}

void cautareNr() {
	int i;
	int x;
	printf("Nr cautat: ");
	scanf("%d", &x);
	sortCresc();
	for (i = 0; i < n; i++) {
		if (st[i].nr_matr == x) {
			printf("Pozitia %d\n", i);
			return;
		}
	}
	printf("Nu a fost gasit\n");
}

int main() {
	int opt;
	do {
		printf("\n1.Citire\n2.Afisare\n3.Sortare alfabetic\n4.Sortare crescator\n5.Cautare nume\n6.Cautare nr\n0.Iesire\nOptiune: ");
		scanf("%d", &opt);
		switch (opt)
		{
		case 0:
			exit(0);
			break;
		case 1:
			citire();
			break;
		case 2:
			afisare();
			break;
		case 3:
			sortAlf();
			break;
		case 4:
			sortCresc();
			break;
		case 5:
			cautareN();
			break;
		case 6:
			cautareNr();
			break;
		default:
			break;
		}
	} while (1);

	return 0;
}*/