#include<stdio.h>

/*void showBinary(int nr, int size) {
	int i;
	for (int i = size; i >= 0; i--) {
		printf("%d", ((nr >> i) & 1));
	}
	printf("\n");
}

int main() {
	int nr, bit;
	printf("Dati nr si bit: ");
	scanf("%d%d", &nr, &bit);
	showBinary(nr, 7);
	printf("Nr %d cu bitul %d marcat 1 devine: %d", nr, bit, nr | (1 << bit));
	showBinary(nr | (1 << bit), 15);

	return 0;
}*/