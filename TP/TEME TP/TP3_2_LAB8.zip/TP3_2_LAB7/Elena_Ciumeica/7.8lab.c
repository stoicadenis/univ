#include<stdio.h>
#include<stdlib.h>

/*int* citire(int* n) {
	int* aux = NULL;
	int* v = NULL;
	int t;
	do {
		scanf("%d", &t);
		if (!t) break;
		(*n)++;
		if ((aux = (int*)realloc(v, (*n) * sizeof(int))) == NULL) {
			printf("No memory");
			free(aux);
			free(v);
			exit(1);
		}
		v = aux;
		v[(*n) - 1] = t;
	} while (1);

	return v;
}

void afisare(int* v, int n) {
	int i;
	for (i = n - 1; i >= 0; i--) {
		printf("%5d", v[i]);
	}
}

int main() {
	int* v, n = 0;
	v = citire(&n);
	afisare(v, n);
	free(v);
	return 0;
}*/