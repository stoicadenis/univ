#include<stdlib.h>
#include<stdio.h>

/*void citire(int* a, int b) {
	int i;
	for (i = 0; i < b; i++) {
		scanf("%d", &a[i]);
	}
}

void afisare(int* a, int* b, int m, int n) {
	int i, j;
	for (i = 0; i < m; i++) {
		for (j = 0; j < n; j++) {
			if (a[i] == b[j]) {
				printf("%d ", a[i]);
			}
		}
	}
	printf("\n");
}

int main() {
	int* a, * b, m, n;
	printf("m si n: ");
	scanf("%d%d", &m, &n);
	if((a = (int*)malloc(m * sizeof(int))) == NULL || (b = (int*)malloc(n * sizeof(int))) == NULL){
����	printf("memorie insuficienta\n");
����	exit(EXIT_FAILURE);
����}
	printf("citire v1:\n");
	citire(a, m);
	printf("citire v2:\n");
	citire(b, n);
	afisare(a, b, m, n);
	free(a);
	free(b);

	return 0;
}*/