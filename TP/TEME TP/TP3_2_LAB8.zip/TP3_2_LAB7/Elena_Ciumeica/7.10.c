#include<stdlib.h>
#include<stdio.h>

/*int main() {
	int blocuri = 0;

	while (malloc(10240) != NULL) 
		blocuri++;
	printf("Aproximativ: %d KB", blocuri);

	return 0;
}*/