#include<stdio.h>
#include<stdlib.h>

/*void citire(int* v, int n) {
	int i;
	for (i = 0; i < n; i++) {
		scanf("%d", &v[i]);
	}
}

void afisare(int* v, int n) {
	int i;
	for (i = n - 1; i >= 0; i--) {
		printf("%5d", v[i]);
	}
}

int main() {
	int* v, n;
	printf("Cite nr: ");
	scanf("%d", &n);

	if ((v = (int*)malloc(n * sizeof(int))) == NULL) {
		printf("No memory");
		exit(1);
	}

	citire(v, n);
	afisare(v, n);
	free(v);

	return 0;
}*/