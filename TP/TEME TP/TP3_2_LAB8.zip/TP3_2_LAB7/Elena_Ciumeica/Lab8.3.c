#include<stdio.h>

/*int main() {
	int nr;
	printf("dati nr ");
	scanf("%d", &nr);
	printf("Catul impartirii la 8 este: %d\n", (nr >> 3));
	printf("Restul impartirii la 8 este: %d", (nr & 7));
	return 0;
}*/