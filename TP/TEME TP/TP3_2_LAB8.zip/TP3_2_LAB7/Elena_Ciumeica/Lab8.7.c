#include<stdio.h>

/*void showBinary(int nr, int size) {
	int i;
	for (int i = size; i >= 0; i--) {
		printf("%d", ((nr >> i) & 1));
	}
	printf("\n");
}

int main() {
	int nr1, nr2;
	unsigned short nr;
	
	printf("Introduceti 2 nr cuprinse intre 0 si 255: ");
	scanf("%d%d", &nr1, &nr2);
	showBinary(nr1, 7);
	showBinary(nr2, 7);
	nr = (nr1 << 8) + nr2;
	showBinary(nr, 16);

	return 0;
}*/