#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*typedef struct {
	char* nume;
	int varsta;
} persoana;

int n;
persoana* tab;

int citire(void) {
	int i, n;
	char buf[80];
	printf("Introduceti numarul de persoane: ");
	scanf("%d", &n);
	tab = (persoana*)malloc(n * sizeof(persoana));
	if (!tab) {
		printf("Eroare alocare dinamica de memorie \n");
		exit(1);
	}
	for (i = 0; i < n; i++) {
		printf("Introduceti numele persoanei %d: ", i + 1);
		scanf("%s", buf);
		if ((tab[i].nume = (char*)malloc(strlen(buf) + 1)) == NULL) {
			printf("Eroare alocare dinamica de memorie\n");
			exit(1);
		}
		strcpy(tab[i].nume, buf);
		printf("Introduceti varsta persoanei %d: ", i + 1);
		scanf("%d", &tab[i].varsta);
	}
	return i;
}
void afisare(persoana* p, int nr) {
	int i;
	for (i = 0; i < nr; i++) {
		printf("\n%10s %d", p[nr].nume, p[nr].varsta);
	}	
}

int main() {
	int n;
	n = citire();
	afisare(tab, n);
	return 0;
}*/