#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/*char** linii = NULL;
int nrLin = 0;

void eliberare()
{
	int i;
	for (i = 0; i < nrLin; i++) {
		free(linii[i]);
	}
	free(linii);
}

char* linie() {
	char* buf = NULL;
	char* buf2;
	char ch;
	size_t n = 0;
	for (;;) {
		n++;
		if ((buf2 = (char*)realloc(buf, n)) == NULL) {
			free(buf);
			eliberare();
			printf("memorie insuficienta\n");
			exit(EXIT_FAILURE);
		}
		buf = buf2;
		ch = getchar();
		if (ch == '\n')break;
		buf[n - 1] = ch;
	}
	buf[n - 1] = '\0';
	return buf;
}

void sortare() {
	int i, again = 0;
	char* aux = NULL;
	do {
		again = 0;
		for (i = 1; i < nrLin; i++) {
			if (strcmp(linii[i - 1], linii[i]) > 0) {
				aux = linii[i - 1];
				linii[i - 1] = linii[i];
				linii[i] = aux;
				again = 1;
			}
		}
	} while (again);
}

void afisare() {
	int i;
	for (i = 0; i < nrLin; i++) {
		printf("%s\n", linii[i]);
	}
}

int main() {
	char** linii2;
	char* p;
	int i;
	for (;;) {
		p = linie();
		if (strlen(p) == 0) {
			free(p);
			break;
		}
		nrLin++;
		if ((linii2 = (char**)realloc(linii, nrLin * sizeof(char*))) == NULL) {
			eliberare();
			printf("memorie insuficienta\n");
			exit(EXIT_FAILURE);
		}
		linii = linii2;
		linii[nrLin - 1] = p;
	}

	sortare();
	afisare();

	eliberare();

	return 0;
}*/