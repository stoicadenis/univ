#include <stdio.h>
#include <stdlib.h>

int main()
{
 int nr, i, c=0;

 printf("nr = ");
 scanf("%d", &nr);

 for(i=0;i<16;i++)
    if( (nr>>i) & 1 )
        c++;

 if(c==1)
    printf("numarul %d este o putere a lui 2", nr);
 else printf("numarul %d nu este o putere a lui 2", nr);


    return 0;
}
