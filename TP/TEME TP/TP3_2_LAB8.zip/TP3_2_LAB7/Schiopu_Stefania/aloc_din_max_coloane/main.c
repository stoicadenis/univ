/*Se citesc m și n. Folosind doar cantitatea necesara de memorie, se citesc elementele unei matrici a[m][n].
Se cere sa se afișeze maximul fiecarei coloane.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int m,n,i,j;
    int *a;              // matricea este implementata ca un vector ce contine toate elementele
    printf("m=");
    scanf("%d",&m);
    printf("n=");
    scanf("%d",&n);
    // alocare matrice
    if((a=(int*)malloc(m*n*sizeof(int)))==NULL)
    {
        printf("memorie insuficienta\n");
        exit(EXIT_FAILURE);
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            printf("a[%d][%d]=",i,j);
            scanf("%d",&a[i*n+j]);
        }
    }
    // cauta maximul fiecarei coloane
    // parcurgea se face in ordinea coloanelor
    for(j=0;j<n;j++)
    {
        int max=a[j];                 // primul element de pe coloana j, din linia 0, adica: 0*n+j
        // parcurge fiecare element din coloana j, incepand cu a doua linie
        for(i=1;i<m;i++)
        {
            int k=a[i*n+j];
            if(k>max)
                max=k;
        }
        printf("maximul coloanei %d este: %d\n",j,max);
    }
    // elibereaza memoria alocata pentru matrice
    free(a);

    system("pause");
    return 0;
}
