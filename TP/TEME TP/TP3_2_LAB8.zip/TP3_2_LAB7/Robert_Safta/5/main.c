#include <stdlib.h>
#include<stdio.h>

int main()
{

    int nr,r1=0;
    scanf("%d",&nr);
    while((nr|0)!=0)
    {
    if((nr&1)==1)
    r1=r1+1;
    nr=nr>>1;
    }
    if(r1>1)
    printf("Nu e putere ");
    else
    printf(" putere ");
    return 0;
}
