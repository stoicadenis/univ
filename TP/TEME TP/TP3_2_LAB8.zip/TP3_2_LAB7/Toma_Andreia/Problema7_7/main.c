#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main()
{
	int n, i;
	int *v;
	printf("n=");
	scanf("%d", &n);
	if ((v = (int*)malloc(n * sizeof(int))) == NULL)
	{
		printf("Eroare alocare memorie\n");
		exit(0);
	}
	for (i = 0; i < n; i++)
	{
		printf("v[%d]=", i);
		scanf("%d", &v[i]);
	}

	for (i = n - 1; i >= 0; i--)
		printf("%d", v[i]);
	free(v);
	_getch();
	return 0;
}

