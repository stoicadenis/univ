#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int *citire(int n)
{
	int *v;
	int i;

	if ((v = (int*)malloc(n * sizeof(int))) == NULL)
	{
		printf("Eroare alocare memorie");
		exit(0);
	}

	for (i = 0; i < n; i++)\
	{
		printf("v[%d]=", i);
		scanf("%d", &v[i]);
	}
	return v;
}

int main()
{
	int m, n, i, j, *v, *t;
	printf("Dati m:");
	scanf("%d", &m);
	v = citire(m);

	printf("Dati n:");
	scanf("%d", &n);
	t = citire(n);

	for(i=0;i<m;i++)
		for (j = 0; j < n; j++)
		{
			if (v[i] == t[i])
			{
				printf("%d", v[i]);
				break;
			}
		}
	free(v);
	_getch();
	return 0;
}
