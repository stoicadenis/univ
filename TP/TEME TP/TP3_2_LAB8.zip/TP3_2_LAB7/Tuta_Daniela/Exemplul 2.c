#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char *a, *aux;
    int c, n;
    /* Initial, textul este un sir vid ("") */
    a=(char*)malloc(1);
    if(!a) {
        printf("Alocarea dinamica a esuat!\n");
        exit(EXIT_FAILURE);
    }
    a[0]=0;
    /* Lungimea initiala a sirului este 0 */
    n=0;
    /* Se citeste cate un caracter de la tastatura, pana la EOF */
    while((c=getchar())!=EOF) {
        /* Dimensiunea curenta a blocului este n+1, deoarece
        se ia in considerare si "\0"
        Se redimensioneaza blocul la n+2, pentru a face loc unui caracter nou citit*/
        aux=(char*)realloc(a, n+2);
        if(!aux) {
            printf("Eroare alocare memorie!\n");
            free(a);
            exit(EXIT_FAILURE);
        }
        else a=aux;
        /* Se concateneaza ultimul caracter la sirul initial */
        a[n]=c;
        /* Terminatorul de sir este mutat cu p pozitie mai la dreapta */
        a[n+1]=0;
        /* Lungimea sirului se incrementeaza */
        n++;
    }
    /* Afisarea sirului citit */
    printf("\n %s\n", a);
    /* Eliberarea memoriei alocate dinamic */
    free(a);
    return 0;
}
