#include <stdio.h>
#include <stdlib.h>

void main(void)
{
    int i, x, n=0;
    int *nr, *aux, *v;
    nr=(int*)malloc(1);
    printf("Introduceti numerele:\n");
    scanf("%d", &x);
    while(x!=0) {
        aux=(int*)realloc(nr, n+1);
        if(!aux) {
            printf("Eroare alocare memorie!\n");
            free(nr);
            exit(1);
        }
        else nr=aux;
        nr[n]=x;
        n++;
        scanf("%d", &x);
    }
    printf("\n\nAfisarea numerelor citite:\n");
    for(i=0; i<n; i++)
        printf(" %4d", *(nr+i));
    printf("\nAfisarea numerelor in ordine inversa:\n");
    for(i=n-1; i>=0; i--)
        printf(" %4d", nr[i]);
    free(nr);
    free(v);
}
