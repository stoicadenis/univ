#include <stdio.h>
#include <stdlib.h>

void main(void)
{
    int n, i, j;
    int *numar;
    printf("Cate numere doriti sa introduceti? - ");
    scanf("%d", &n);
    if(!(numar=(int*)malloc(n*sizeof(int)))) {
        printf("Eroare alocare memorie dinamica!\n");
        exit(1);
    }
    printf("Introduceti cele %d numere: \n", n);
    for(i=0; i<n; i++)
        scanf("%d", numar+i);
    for(i=0; i<n; i++)
        printf("%4d", *(numar+i));
    printf("\nAfisarea numerelor in ordine inversa: \n");
    for(i=n-1; i>=0; i--)
        printf("%4d", numar[i]);
    printf("\n");
    free(numar);
}
