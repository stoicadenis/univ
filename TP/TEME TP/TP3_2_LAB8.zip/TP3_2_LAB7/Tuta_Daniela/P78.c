#include <stdio.h>
#include <stdlib.h>
#define INCR 5 // cu cat va creste N la fiecare realocare

int main()
{
    int n, i;
    int aux, *numar;
    n=INCR;
    i=0;
    numar=(int*)malloc(n*sizeof(int)); // alocarea initiala
    if(!(numar=(int*)malloc(n*sizeof(int)))) {
        printf("Eroare alocare memorie!\n");
        exit(1);
    }
    printf("Introduceti numerele:\n");
    do {
        scanf("%d", &aux);
        if(++i==n) {
            n+=INCR;
            numar=(int*)realloc(numar, n*sizeof(int));
        }
        numar[i]=aux;
    } while(aux!=0);
    n=i;
    printf("\nAfisarea celor %d numere:\n", i-1);
    for(i=1; i<n; i++)
        printf("%4d", numar[i]);
    printf("\nAfisarea numerelor in ordine inversa:\n");
    for(i=n-1; i>=1; i--)
        printf("%4d", *(numar+i));
    free(numar);
}
