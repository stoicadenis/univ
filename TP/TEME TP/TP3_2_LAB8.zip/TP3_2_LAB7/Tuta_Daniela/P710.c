#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h>

void main()
{
    int dim, bloc; //variabila dim determina dimensiunea blocurilor memorie care se vor aloca
    int *p;
    printf("Introduceti dimensiunea blocurilor: ");
    scanf("%d", &dim);
    for(bloc=1; ; bloc++) {
        p=(int*)malloc(dim*sizeof(int));
        if(p==NULL) {
            printf("Memorie insuficienta!\n");
            break;
        }
        else
            printf("%u\n", p);
    }
    printf("%d blocuri au fost alocate cu succes!\n");
}

