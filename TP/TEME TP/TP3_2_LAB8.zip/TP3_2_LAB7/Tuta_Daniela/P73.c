#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *concatenare(char *sir1, char *sir2)
{
    char *rezultat;
    rezultat=(char*)malloc(sizeof(char));
    if(!rezultat) {
        printf("Eroare alocare dinamica memorie!\n");
        exit(1);
    }
    strcpy(rezultat, strcat(sir1, " "));
    strcat(rezultat, sir2);
}

void main(void)
{
   char sir1[100], sir2[100];
   puts("Introduceti primul sir: ");
   getchar();
   scanf("%s", sir1);
   puts("Introduceti al doilea sir: ");
   scanf("%s", sir2);
   puts(concatenare(sir1, sir2));
}


