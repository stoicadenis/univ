#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *a, *aux;
    /* Se aloca memorie pentru 100 valori intregi */
    a=(int*)malloc(100*sizeof(int));
    if(!a) {
        printf("Eroare alocare memorie!\n");
        exit(EXIT_FAILURE);
    }
    /* Se redimensioneaza blocul alocat la 200 valori intregi.
    Adresa returnata de realloc este pastrata intr-un pointer auxiliar,
    pentru a nu-l suprascrie pe a */
    aux=(int*)realloc(a, 200*sizeof(int));
    /* Daca redimensionarea a esuat, blocul alocat initial este eliberat,
    iar apoi programul se incheie cu mesaj de eroare */
    if(!a) {
        printf("Nu se poate redimensiona blocul!\n");
        free(a);
        exit(EXIT_FAILURE);
    }
    /* Daca alocarea a reusit, adresa din aux este copiata in a
    si se continua executia */
    else a=aux;
    /* Eliberare bloc la final */
    free(a);
    return 0;
}
