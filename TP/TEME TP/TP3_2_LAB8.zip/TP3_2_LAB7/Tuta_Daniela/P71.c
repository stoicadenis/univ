#include <stdio.h>
#include <stdlib.h>

int citire(int n)
{
    int i=0;
    int *v;
    v=(int*)malloc(n*sizeof(int));
    if(!v) {
        printf("Eroare alocare dinamica memorie!\n");
        exit(1);
    }
    printf("\nIntroduceti valorile vectorului:\n");
    for(i=0; i<n; i++) {
        printf("v[%d]=", i);
        scanf("%d", v+i);
    }
    printf("\nValorile vectorului sunt:\n", n);
    for(i=0; i<n; i++)
        printf(" %4d", *(v+i));
    printf("\n");
}

void main(void)
{
    int m, n, i, j;
    int *v1, *v2;
    printf("Cate valori doriti sa introduceti in primul vector? - ");
    scanf("%d", &m);
    v1=(int*)malloc(m*sizeof(int));
    v1=citire(m);
    if(!v1) {
        printf("Eroare!\n");
        exit(EXIT_FAILURE);
    }
    printf("Cate valori doriti sa introduceti in al doilea vector? - ");
    scanf("%d", &n);
    v2=(int*)malloc(sizeof(n*sizeof(int)));
    if(!v2) {
        printf("Eroare!\n");
        exit(EXIT_FAILURE);
    }
    citire(n);
}
