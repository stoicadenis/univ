#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *nume;
    int nr_matricol;
} student;

/* Functie pentru afisarea erorii in caz de esuare a alocarii de memorie */
void eroare(void)
{
    puts("Eroare alocare dinamica memorie!\n");
    exit(1);
}
/* Functie pentru eliberare memorie alocata dinamic */
void eliberare(student *p, int n)
{
    int i;
    for(i=0; i<n; i++)
        free(p[i].nume);
    free(p);
}
/* Functie pentru citirea datelor despre studenti */
void citire(student **p, int *n)
{
    student *tab;
    char buf[30];
    int i;
    printf("Cati studenti doriti sa introduceti? - ");
    scanf("%d", n);
    if(!(tab=(student*)malloc((*n)*sizeof(student))))
        eroare();
    *p=tab;
    for(i=0; i<*n; i++, tab++) {
        printf("\nNume student: ");
        getchar();
        fgets(buf, 30, stdin);
        /* Alocare dinamica memorie pentru nume student */
        if(!(tab->nume=(char*)malloc(strlen(buf)+1)))
            eroare();
        /* Daca alocarea a reusit, se copiaza numele din buf in nume
        si se continua executia */
        strcpy(tab->nume, buf);
        printf("Numar matricol: ");
        scanf("%d", &tab->nr_matricol);
    }
}
void afisare(student *p, int n)
{
    int i;
    printf("***TABEL STUDENTI***\n");
    for(i=0; i<n; i++, p++)
        printf("\n%-30s %4d\n", p->nume, p->nr_matricol);
}

typedef int (*fct_cmp)(student, student);

int nume(student s1, student s2) {
    return strcmp(s1.nume, s2.nume);
    }
int matricol(student s1, student s2) {
    return s1.nr_matricol-s2.nr_matricol;
    }

void sortare(student *p, int n, fct_cmp f)
{
    int i, j;
    student tab;
    for(i=0; i<n-1; i++)
    for(j=i+1; j<n; j++)
        if((*f)(p[i], p[j])>0) {
            tab=p[i];
            p[i]=p[j];
            p[j]=tab;
        }
}

void cautare_nume(student *p, int n)
{
    int i;
    char nume_cautat[30];
    printf("Introduceti numele studentului cautat: ");
    getchar();
    fgets(nume_cautat, 30, stdin);
    sortare(p, n, nume);
    afisare(p, n);
    for(i=0; i<n; i++)
        if(strcmp(p[i].nume, nume_cautat)==0) {
            printf("Studentul %s se afla pe pozitia %d, in lista ordonata alfabetic.\n\n", nume_cautat, i);
            break;
        }
}
void cautare_matricol(student *p, int n)
{
    int i, nr;
    printf("Introduceti numarul matricol al studentului cautat: ");
    scanf("%d", &nr);
    sortare(p, n, matricol);
    afisare(p, n);
    for(i=0; i<n; i++)
        if(p[i].nr_matricol==nr)
            printf("Studentul cu numarul matricol %d se afla pe pozitia %d, in lista ordonata crescator dupa numarul matricol.\n", nr, i);
}
void meniu(void)
{
    puts("\n1. Citire tabel studenti");
    puts("2. Afisare tabel studenti");
    puts("3. Sortare dupa nume");
    puts("4. Sortare dupa numar matricol");
    puts("5. Cautare dupa nume");
    puts("6. Cautare dupa numar matricol");
    puts("0. Iesire din program\n");
}

void main(void)
{
    int n;
    int opt;
    student *p=NULL; /* Adresa tabloului */
    do {
        meniu();
        printf("Optiunea dumneavoastra: ");
        scanf("%d", &opt);
        switch(opt) {
            case 1: citire(&p, &n);
                break;
            case 2: afisare(p, n);
                break;
            case 3: sortare(p, n, nume);
                afisare(p, n);
                break;
            case 4: sortare(p, n, matricol);
                afisare(p, n);
                break;
            case 5: cautare_nume(p, n);
                break;
            case 6: cautare_matricol(p, n);
                break;
            case 0: exit(0);
                break;
            default: printf("Optiune gresita!\n");
                break;
        }
    } while(1);
}
