#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int n, i;
    float x;
    float *a;
    /* Citirea de la tastatura */
    printf("Cate numere doriti sa introduceti? - ");
    scanf("%d", &n);
    /*�Dupa�ce�il�stim�pe�n,�alocam�din�zona�dinamica�un�bloc�de�memorie�
    in�care�sa�putem�pastra�n�float-uri. */
    a=(float*)malloc(sizeof(float));
    /*�Daca�alocarea�de�memorie�a�esuat,�
    incheiem�executia�cu�mesaj�de�eroare.�*/
    if(!a) {
        printf("Eroare alocare memorie!\n");
        exit(EXIT_FAILURE);
    }
    /*�Daca�am�ajuns�aici�inseamna�ca�alocarea�de�memorie�a�reusit.�
    Citim�cele�n�numere�reale.�*/
    for(i=0; i<n; i++) {
        printf("a[%d]=", i);
        scanf("%f", &a[i]);
    }
    /* Citim x */
    printf("Introduceti x: ");
    scanf("%f", &x);
    /* Afisarea numerelor din intervalul (x-1, x+1) */
    printf("Numerele din intervalul (%.2f, %.2f) sunt: ", x-1, x+1);
    for(i=0; i<n; i++)
        if(fabs(x-a[i])<1)
            printf("%.2f  ", a[i]);
    printf("\n");
    free(a);
    return 0;
}
