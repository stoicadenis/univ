#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    char *nume;
    int varsta;
} persoana;

int n;
persoana *tab;

int main()
{
    int i;
    char buf[80];
    printf("Introduceti numarul de persoane: ");
    scanf("%d", &n);
    if(!(tab=(persoana*)malloc(n*sizeof(persoana)))){
        printf("Eroare alocare dinamica memorie!\n");
        exit(1);
    }
    for(i=0; i<n; i++) {
        printf("\nIntroduceti numele persoanei: ");
        getchar();
        fgets(buf, 80, stdin);
        if(!(tab[i].nume=(char*)malloc(strlen(buf)+1))) {
        printf("Eroare alocare dinamica memorie!\n");
        exit(1);
        }
        strcpy(tab[i].nume, buf);
        printf("Introduceti varsta persoanei: ");
        scanf("%d", &tab[i].varsta);
    }
    for(i=0; i<n; i++)
        printf(" %s  %d\n", tab[i].nume, tab[i].varsta);
    printf("\n");
    return 0;
}
