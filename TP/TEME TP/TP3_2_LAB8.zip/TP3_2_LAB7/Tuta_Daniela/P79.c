#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int n=0, cuv, i, l;
    // n=-1, deoarece la numararea caracterelor, nu se ia in considerare si "\0"
    char *cuvant, *aux;
    char *sir, *token;
    // Textul initial este sirul vid ("")
    cuvant=(char*)malloc(1);
    if(!cuvant) {
        printf("Eroare alocare memorie dinamica!\n");
        exit(EXIT_FAILURE);
    }
    cuvant[0]=0; // Lungimea initiala a sirului este 0
    while((cuv=getchar())!=EOF) {
        aux=(char*)realloc(cuvant, n+2);
        if(!aux) {
            free(cuvant);
            printf("Redimensionare bloc esuata!\n");
            exit(EXIT_FAILURE);
        }
        else cuvant=aux;
        // Cuvantul se va termina cu noul caracter
        cuvant[n]=cuv;
        // Terminatorul va fi plasat cu o pozitie mai la dreapta
        cuvant[n+1]=0;
        n++;
    }
    sir=(char*)malloc(n*sizeof(char));
    if(!sir) {
        printf("Eroare alocare memorie!\n");
        exit(EXIT_FAILURE);
    }
    token=strtok(cuvant, " \t\n");
    strcpy(sir, token);
    while(token!=NULL) {
        if((sir[strlen(sir)-2]==(tolower(token[0])))&&(sir[strlen(sir)-1]==(tolower(token[1]))))
            strcat(strcat(sir, " - "), token);
        token=strtok(NULL, " \t\n");
    }
    puts("\nSirul de caractere nou - format:");
    puts(sir);
    free(cuvant);
    free(sir);
    return 0;
}

