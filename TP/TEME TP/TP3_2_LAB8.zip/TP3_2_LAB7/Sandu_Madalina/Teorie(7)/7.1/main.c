#include <stdio.h>
#include <stdlib.h>
int *citire(int n)
{
    int i;
    int *v;
    v=(int*)malloc(n*sizeof(int));
      if(!v)
     {
        printf("Eroare alocare de memorie!\n");
        exit(EXIT_FAILURE);
    }
    for(i=0;i<n;i++)
    {
        printf("v[%d]=",i);
        scanf("%d",v+i);
    }
    return v;
}
void afisare(int n)
{
    int i,*v;
    for(i=0;i<n;i++)
    printf("%d ",*(v+i));
    printf("\n");
}
void elemente(int a[], int b[], int n, int m)
{
    int i,j;
    for(i=0;i<n;i++)
    for(j=0;j<m;j++)
    if(*(a+i)==*(b+j))
        printf("%d ",*(a+i));
    printf("\n");
}

int main()
{
    int n,m,*a,*b;
    printf("n="); scanf("%d",&n);
    a=citire(n);
    afisare(n);
    printf("m="); scanf("%d",&m);
    b=citire(m);
    afisare(m);
    printf("Elementele din primul vector ce se regasesc in al doilea vector sunt: ");
    elemente(a,b,n,m);
    free(a);
    free(b);
    return 0;
}
