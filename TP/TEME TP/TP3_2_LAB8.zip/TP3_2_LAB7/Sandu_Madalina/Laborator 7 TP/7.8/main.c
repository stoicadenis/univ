#include <stdio.h>
#include <stdlib.h>
int main()
{
    int *a,n,i,*aux,x;
    a=(int*)malloc(sizeof(int));
    n=0;
        while(1)
     {
        scanf("%d",&x);
        if(!x)
            break;
         n=n+1;
        aux=(int*)realloc(a,n*sizeof(int));
                if(!aux)
            {
                free(a);
                printf("Nu se poate redimensiona blocul!\n");
                exit(EXIT_FAILURE);
            }
            else
               a=aux;
            a[n-1]=x;
    }

    printf("Numerele introduse sunt: ");
    for(i=n-1;i>=0;i--)
        printf("%d ",a[i]);
    free(a);

    return 0;
}
