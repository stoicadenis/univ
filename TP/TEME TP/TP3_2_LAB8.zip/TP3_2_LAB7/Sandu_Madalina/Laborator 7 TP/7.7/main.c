#include <stdio.h>
#include <stdlib.h>
int main()
{
    int *a,n,i;
    printf("Introduceti n: ");
    scanf("%d",&n);
    a=(int*)malloc(n*sizeof(int));
        if(!a)
    {
        printf("Nu exista spatiu suficient!");
        exit(EXIT_FAILURE);
    }
    for(i=0;i<n;i++)
    {
        printf("a[%d]=",i);
        scanf("%d",&a[i]);
    }
    printf("Afisarea numerelor in ordine inversa \n");
    for(i=n-1;i>=0;i--)
        printf("%d ",a[i]);
    free(a);

    return 0;
}

